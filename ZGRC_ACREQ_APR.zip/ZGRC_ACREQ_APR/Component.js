jQuery.sap.declare("fcg.grc.accessrequest.approve.ZGRC_ACREQ_APR.Component");
// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "fcg.grc.accessrequest.approve",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/sap/GRC_ACREQ_APR" // we use a URL relative to our own component
	// extension application is deployed with customer namespace
});
this.fcg.grc.accessrequest.approve.Component.extend("fcg.grc.accessrequest.approve.ZGRC_ACREQ_APR.Component", {
	metadata: {
		version: "1.0",
		config: {},
		customizing: {
			"sap.ui.viewReplacements": {
				"fcg.grc.accessrequest.approve.view.RequestDetail": {
					"viewName": "fcg.grc.accessrequest.approve.ZGRC_ACREQ_APR.view.RequestDetailCustom",
					"type": "XML"
				}
			},
			"sap.ui.controllerExtensions": {
				"fcg.grc.accessrequest.approve.view.RequestDetail": {
					"controllerName": "fcg.grc.accessrequest.approve.ZGRC_ACREQ_APR.view.RequestDetailCustom"
				}
			}
		}
	}
});