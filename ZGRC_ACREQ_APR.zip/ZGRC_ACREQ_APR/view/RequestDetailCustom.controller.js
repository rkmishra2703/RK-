jQuery.sap.require("sap.ushell.services.CrossApplicationNavigation");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("fcg.grc.accessrequest.approve.ZGRC_ACREQ_APR.view.RequestDetailCustom", {
	//    oCrossAppNavigator: null,
	//    resBundle: null,
	//    gSelectDialog: null,
	//    gSelectDialogApprove: null,
	//    oCurrentView: null,
	//    oCurrentModel: null,
	//    s_approver: "",
	//    s_comments: "",
	//    s_rejectComments: "",
	//    s_forwardUser: "",
	//    s_requestNumber: "",
	//    s_wiGroup: "",
	//    s_approvedCount: 0,
	//    s_rejectedCount: 0,
	//    g_rejectionList: [],
	//    g_rejectionCommentsList: [],
	//    gRejectDialog: null,
	//    gs_approvedCount: 0,
	//    s_delimit_key: "`:`",
	//    g_tlock: false,
	//    getResBundle: function () {
	//        if (this.resBundle === null) {
	//            this.resBundle = this.getView().getModel("i18n").getResourceBundle();
	//        }
	//        return this.resBundle;
	//    },
	//    onInit: function () {
	//        sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
	//        var l = this;
	//        var o = {
	//            sI18NDetailTitle: "ACCESS_REQUEST_LBL",
	//            oPositiveAction: {
	//                sId: "Submit",
	//                sI18nBtnTxt: "SUBMIT_BTN",
	//                onBtnPressed: function (e) {
	//                    l.doSubmit();
	//                }
	//            },
	//            oNegativeAction: {
	//                sId: "Forward",
	//                sI18nBtnTxt: "FORWARD_TEXT",
	//                onBtnPressed: function (e) {
	//                    l.handleForward(e);
	//                }
	//            },
	//            onBack: jQuery.proxy(function () {
	//                this.oRouter.navTo("master", {}, false);
	//            }, this),
	//            oJamOptions: {
	//                oLineItem: this.byId("requestHeader"),
	//                fGetShareSettings: function () {
	//                    var O = new sap.m.ObjectListItem({
	//                        title: this.oLineItem.getTitle(),
	//                        number: this.oLineItem.getNumber(),
	//                        numberUnit: this.oLineItem.getNumberUnit(),
	//                        selected: true
	//                    });
	//                    return {
	//                        object: {
	//                            id: window.location.href.substring(0, window.location.href.indexOf("&/detail/Requests")),
	//                            display: O,
	//                            share: " "
	//                        }
	//                    };
	//                }
	//            },
	//            oAddBookmarkSettings: {
	//                title: this.resBundle.getText("APPROVER_LBL"),
	//                subTitle: this.resBundle.getText("ACCESS_REQUEST_LBL"),
	//                info: this.resBundle.getText("ACCESS_DETAILS_TEXT"),
	//                icon: "sap-icon://approvals"
	//            }
	//        };
	//        this.setHeaderFooterOptions(o);
	//        this.oCurrentView = this.getView();
	//        this.oCurrentModel = new sap.ui.model.json.JSONModel();
	//        this.getView().getModel().attachRequestCompleted(function () {
	//            this.requestCompleted(this);
	//        }, this);
	//        this.oRouter.attachRouteMatched(function (e) {
	//            if (e.getParameter("name") === "detail") {
	//                this.g_eventContextPath = e.getParameter("arguments").contextPath;
	//                this.s_requestNumber = "";
	//                this.g_tlock = true;
	//                this.s_approvedCount = 0;
	//                this.s_rejectedCount = 0;
	//                this.g_rejectionList = [];
	//                this.g_rejectionCommentsList = [];
	//                this.byId("requestHeader").setVisible(true);
	//                this.byId("TABCONT_ROLE_INFO").setVisible(true);
	//                var r = this.getRejectionDataModel();
	//                if (r) {
	//                    var a = r.getData();
	//                    if (a) {
	//                        this.s_approvedCount = a.approvedCount;
	//                        this.s_rejectedCount = a.rejectedCount;
	//                        this.g_rejectionList = a.rejectionList;
	//                        this.g_rejectionCommentsList = a.rejectionCommentsList;
	//                    }
	//                }
	//                this.getView().bindElement("/" + this.g_eventContextPath);
	//            }
	//        }, this);
	//    },
	//    getCheckBoxName: function (p) {
	//        if (this.s_requestNumber == null || this.s_requestNumber == "") {
	//            var c = this.getView().getBindingContext();
	//            this.s_requestNumber = c.getObject().RequestNumber;
	//        }
	//        return p + this.s_delimit_key + this.s_requestNumber;
	//    },
	//    isCheckBoxSelected: function (p) {
	//        if (this.g_rejectionList && this.g_rejectionList.indexOf(p) != -1) {
	//            return false;
	//        }
	//        return true;
	//    },
	//    getRejectionDataModel: function () {
	//        var l = this.getView().getModel("AccessRejectionData/" + this.g_eventContextPath);
	//        if (l == undefined || l == null) {
	//            var a = {};
	//            a.approvedCount = 0;
	//            a.rejectedCount = 0;
	//            a.rejectionList = [];
	//            a.rejectionCommentsList = [];
	//            var l = new sap.ui.model.json.JSONModel();
	//            l.setData(a);
	//            this.getView().setModel(l, "AccessRejectionData/" + this.g_eventContextPath);
	//            l = this.getView().getModel("AccessRejectionData/" + this.g_eventContextPath);
	//        }
	//        return l;
	//    },
	//    updateRejectionDataModel: function () {
	//        var l = {};
	//        l.approvedCount = this.s_approvedCount;
	//        l.rejectedCount = this.s_rejectedCount;
	//        l.rejectionList = this.g_rejectionList;
	//        l.rejectionCommentsList = this.g_rejectionCommentsList;
	//        this.getRejectionDataModel().setData(l);
	//    },
	//    handleSelect: function (e) {
	//        this.handleItemPress(e);
	//    },
	//    handleItemPress: function (e) {
	//        var c = e.getSource().getBindingContext();
	//        this.updateRejectionDataModel();
	//        this.oRouter.navTo("roleDetails", {
	//            contextPath: this.getView().getBindingContext().sPath.substr(1),
	//            key: c.sPath.substr(1)
	//        }, false);
	//    },
	//    navigateToDetail: function (i) {
	//        var l = this.getRoleList().indexOfItem(i) + 1;
	//        var a = this.getRoleList().getItems().length;
	//        var c = i.getBindingContext();
	//        this.oRouter.navTo("roleDetails", {
	//            RoleID: c.getModel().getProperty(c.getPath() + "/RoleID"),
	//            RoleType: c.getModel().getProperty(c.getPath() + "/RoleType"),
	//            RoleSystem: c.getModel().getProperty(c.getPath() + "/System"),
	//            SelectedIndex: l,
	//            TotalCount: a
	//        });
	//    },
	//    handleLineItemPress: function (e) {
	//        this.navigateToDetail(e.getSource());
	//    },
	//    handleForward: function (e) {
	//        this.gSelectDialog = this.initSelectDialog("Forward");
	//        this.gSelectDialog.open();
	//    },
	//    doSearch: function (e) {
	//        var f = [];
	//        var v = e.getParameter("value");
	//        if (v !== undefined) {
	//            var i = e.getParameter("itemsBinding");
	//            var s = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.Contains, v);
	//            f.push(s);
	//            i.filter(f);
	//        }
	//    },
	//    doLiveChange: function (e) {
	//        var f = e.getParameters().value.toLowerCase();
	//        var l = e.getSource().getItems();
	//        var v;
	//        if (l) {
	//            for (var i = 0; i < l.length; i++) {
	//                var I = l[i];
	//                v = I.getProperty("title").toLowerCase().indexOf(f) != -1 || I.getProperty("description").toLowerCase().indexOf(f) != -1;
	//                l[i].setVisible(v);
	//            }
	//        }
	//    },
	//    doNothing: function () {
	//    },
	//    showToastMessage: function (p) {
	//        var l = this.getResBundle().getText("REQ_FORWARD_SUCCESS_MSG", [
	//            this.s_requestNumber,
	//            this.s_forwardUserName
	//        ]);
	//        if (p === "Approve") {
	//            l = this.getResBundle().getText("REQ_SUBMIT_SUCCESS_MSG", [
	//                this.s_approvedCount,
	//                this.s_rejectedCount,
	//                this.s_requestNumber
	//            ]);
	//        }
	//        var a = this;
	//        var b = "25em";
	//        sap.m.MessageToast.show(l, {
	//            width: b,
	//            duration: 1000,
	//            onClose: function () {
	//                a.onToastClose();
	//            }
	//        });
	//    },
	//    onToastClose: function () {
	//        this.clearScreenElements();
	//        this.oRouter.navTo("masterUpdate", { contextPath: "deleteSelected" }, false);
	//    },
	//    clearScreenElements: function () {
	//        this.byId("requestHeader").setVisible(false);
	//        this.byId("TABCONT_ROLE_INFO").setVisible(false);
	//    },
	//    showErrorDialog: function (p) {
	//        var l = "25em";
	//        sap.m.MessageBox.alert(p, this.doNothing, this.getResBundle().getText("ERROR_TEXT"), "");
	//    },
	//    getStr: function (s) {
	//        return "'" + s + "'";
	//    },
	//    getRejectDialog: function (p) {
	//        this.gRejectDialog = this.initRejectDialog(p);
	//        this.gRejectDialog.attachAfterClose(this.rejectLineItem, this);
	//        this.gRejectDialog.open();
	//    },
	//    rejectLineItem: function (e) {
	//        var t = this;
	//        t.gRejectDialog.detachAfterClose(t.rejectLineItem, t);
	//        t.g_rejectionCommentsList.push(t.s_rejectComments);
	//        t.updateRejectionDataModel();
	//    },
	//    approveLineItemSelect: function (e) {
	//        var l = e.getSource().getName();
	//        if (l.indexOf(this.s_delimit_key) != -1) {
	//            l = l.split(this.s_delimit_key)[0];
	//        }
	//        if (e.getSource().getSelected()) {
	//            this.s_approvedCount++;
	//            if (this.s_rejectedCount > 0) {
	//                this.s_rejectedCount--;
	//                var p = this.g_rejectionList.indexOf(l);
	//                if (p >= 0) {
	//                    this.g_rejectionList[p] = " ";
	//                    this.g_rejectionCommentsList[p] = " ";
	//                }
	//            }
	//            this.updateRejectionDataModel();
	//        } else {
	//            if (this.s_approvedCount > 0) {
	//                this.s_approvedCount--;
	//                this.g_rejectionList.push(l);
	//                this.s_rejectedCount++;
	//                var a = e.getSource().getBindingContext().getObject().Description;
	//                this.getRejectDialog(a);
	//            }
	//        }
	//    },
	//    forwardRequestCreate: function (p, a) {
	//        var t = this;
	//        t.s_comments1 = t.s_comments;
	//        t.s_forwardUser1 = t.s_forwardUser;
	//        var A = {
	//            SubmitType: p,
	//            Approver: t.s_approver1,
	//            RequestNumber: t.s_requestNumber1,
	//            Comments: t.s_comments1,
	//            WorkItemGroup: t.s_wiGroup1,
	//            ForwardUser: t.s_forwardUser1
	//        };
	//        var l = {};
	//        l.Access = " ";
	//        l.Action = "RE";
	//        l.Comments = " ";
	//        A.Rejections = [];
	//        A.Rejections[0] = l;
	//        var d = t.byId("accessRequestedList").getItems();
	//        for (var i = 0; i < d.length; i++) {
	//            l = {};
	//            l.Access = d[i].getBindingContext().getObject().AccessName;
	//            l.Action = "AP";
	//            l.Comments = " ";
	//            var b = this.g_rejectionList.indexOf(l.Access);
	//            if (b != -1) {
	//                l.Action = "RE";
	//                l.Comments = this.g_rejectionCommentsList[b];
	//            }
	//            A.Rejections[i] = l;
	//        }
	//        var c = this.getView();
	//        c.setBusy(true);
	//        var s = t.getView().getModel().sServiceUrl;
	//        t.oARCCartModel = new sap.ui.model.odata.ODataModel(s, true);
	//        t.oARCCartModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
	//        t.oARCCartModel.setHeaders({ DataServiceVersion: "2.0" });
	//        t.oARCCartModel.create("/Submits", A, null, function (D, r) {
	//            t.showToastMessage(p);
	//            c.setBusy(false);
	//            this.g_rejectionList = [];
	//        }, function (E) {
	//            c.setBusy(false);
	//            t.gRequestNumber = "";
	//            a.close();
	//            if (E && E.response && E.response.body) {
	//                var B = E.response.body;
	//                var f = "";
	//                var o = "";
	//                try {
	//                    o = jQuery.parseXML(B);
	//                    if (o) {
	//                        f = o.getElementsByTagName("message")[0].childNodes[0].nodeValue;
	//                    }
	//                } catch (e) {
	//                    o = jQuery.parseJSON(B);
	//                    if (o) {
	//                        f = o.error.message.value;
	//                    }
	//                }
	//                t.showErrorDialog(f);
	//            }
	//        });
	//    },
	//    getDialog: function (p, a) {
	//        var t = this;
	//        var l = new sap.m.Text({
	//            text: a,
	//            design: "Bold"
	//        });
	//        var b = this.getResBundle().getText(p);
	//        var h = new sap.m.HBox({ height: "6em" });
	//        h.setJustifyContent(sap.m.FlexJustifyContent.Center);
	//        var v = new sap.m.VBox({ width: "85%" });
	//        v.setJustifyContent(sap.m.FlexJustifyContent.SpaceAround);
	//        v.addItem(l);
	//        h.addItem(v);
	//        var d = "";
	//        d = new sap.m.Dialog({
	//            title: b,
	//            content: [h],
	//            beginButton: new sap.m.Button({
	//                text: this.getResBundle().getText("OK_BTN"),
	//                press: function () {
	//                    d.close();
	//                }
	//            }),
	//            endButton: new sap.m.Button({
	//                text: this.getResBundle().getText("CANCEL_BTN"),
	//                press: function () {
	//                    d.close();
	//                }
	//            })
	//        });
	//        return d;
	//    },
	//    initRejectDialog: function (p) {
	//        var t = this;
	//        var l = this.getResBundle().getText("REJECT_ACCESS_TEXT", [p]);
	//        var a = new sap.m.Text({
	//            text: l,
	//            design: "Bold"
	//        });
	//        var b = new sap.m.Input({
	//            type: "Text",
	//            valueStateText: this.getResBundle().getText("ADD_COMMENTS_TEXT")
	//        });
	//        var c = this.getResBundle().getText("REJECT_COMMENTS_TEXT");
	//        var h = new sap.m.HBox({ height: "6em" });
	//        h.setJustifyContent(sap.m.FlexJustifyContent.Center);
	//        var v = new sap.m.VBox({ width: "85%" });
	//        v.setJustifyContent(sap.m.FlexJustifyContent.SpaceAround);
	//        v.addItem(a);
	//        v.addItem(b);
	//        h.addItem(v);
	//        var r = "";
	//        r = new sap.m.Dialog({
	//            title: c,
	//            content: [h],
	//            beginButton: new sap.m.Button({
	//                text: this.getResBundle().getText("OK_BTN"),
	//                press: function () {
	//                    t.s_rejectComments = b.getValue();
	//                    r.close();
	//                }
	//            }),
	//            endButton: new sap.m.Button({
	//                text: this.getResBundle().getText("CANCEL_BTN"),
	//                press: function () {
	//                    r.close();
	//                }
	//            })
	//        });
	//        return r;
	//    },
	//    initSelectDialog: function (p) {
	//        var t = this;
	//        var l = this.getView().getModel("i18n");
	//        var c = this.getView().getBindingContext();
	//        this.s_wiGroup = c.getObject().WorkItemGroup;
	//        this.s_requestNumber = c.getObject().RequestNumber;
	//        this.s_approver = c.getObject().Approver;
	//        t.s_approver1 = t.s_approver;
	//        t.s_requestNumber1 = t.s_requestNumber;
	//        t.s_wiGroup1 = t.s_wiGroup;
	//        var a = l.getProperty("TO_TEXT");
	//        var b = new sap.m.Text({
	//            text: a,
	//            design: "Bold"
	//        });
	//        var d = new sap.m.Input({
	//            type: "Text",
	//            valueStateText: l.getProperty("ADD_COMMENTS_TEXT"),
	//            value: l.getProperty("THANKS_TEXT")
	//        });
	//        var h = new sap.m.HBox({ height: "6em" });
	//        h.setJustifyContent(sap.m.FlexJustifyContent.Center);
	//        var v = new sap.m.VBox({ width: "85%" });
	//        v.setJustifyContent(sap.m.FlexJustifyContent.SpaceAround);
	//        v.addItem(b);
	//        v.addItem(d);
	//        h.addItem(v);
	//        var e = p;
	//        if (p === "Approve") {
	//            var f = this.getResBundle().getText("APPROVE_REJECT_ITEMS_TEXT", [
	//                t.s_approvedCount,
	//                t.s_rejectedCount,
	//                t.s_requestNumber1,
	//                c.getObject().UserName
	//            ]);
	//            b.setText(f);
	//            e = this.getResBundle().getText("SUBMIT_BTN");
	//            d.setValue("");
	//            d.setValueStateText(this.getResBundle().getText("ADD_COMMENTS_MSG"));
	//        } else {
	//            e = this.getResBundle().getText("FORWARD_TEXT");
	//        }
	//        var D = "";
	//        D = new sap.m.Dialog({
	//            title: e,
	//            content: [h],
	//            beginButton: new sap.m.Button({
	//                text: l.getProperty("OK_BTN"),
	//                press: function () {
	//                    t.s_comments = d.getValue();
	//                    if (t.s_forwardUserName && t.s_forwardUserName != "") {
	//                        var g = t.s_forwardUserName.lastIndexOf("(");
	//                        var j = t.s_forwardUserName.lastIndexOf(")");
	//                        t.s_forwardUser = t.s_forwardUserName.substring(g + 1, j);
	//                    }
	//                    t.forwardRequestCreate(p, D);
	//                    D.close();
	//                }
	//            }),
	//            endButton: new sap.m.Button({
	//                text: l.getProperty("CANCEL_BTN"),
	//                press: function () {
	//                    D.close();
	//                }
	//            })
	//        });
	//        if (p === "Forward") {
	//            var s = t.gSelectDialog;
	//            if (!s) {
	//                var i = new sap.m.StandardListItem({
	//                    title: "{UserName} ({UserID})",
	//                    description: "{Email}",
	//                    icon: "sap-icon://employee"
	//                });
	//                s = new sap.m.SelectDialog("SelectDialog1", {
	//                    title: l.getProperty("FORWARD_TEXT"),
	//                    noDataText: l.getProperty("NO_FORWARD_USERS_FOUND_TEXT"),
	//                    search: this.doSearch
	//                });
	//                s.setModel(this.getView().getModel());
	//                s.bindAggregation("items", "/ForwardUsers", i);
	//                s.attachConfirm(function (g) {
	//                    var j = g.getParameter("selectedItem");
	//                    if (j) {
	//                        t.s_forwardUserName = j.getTitle();
	//                        b.setText(a + " " + j.getTitle() + ":");
	//                        D.open();
	//                    }
	//                });
	//            }
	//            return s;
	//        } else {
	//            return D;
	//        }
	//    },
	//    formatUserNameDisplay: function (u, r) {
	//        var a = this.getResBundle();
	//        return a.getText("USER_LBL", [u]);
	//    },
	//    formatAuthorizedMessage: function (i) {
	//        var r = this.getResBundle();
	//        if (i === false) {
	//            return r.getText("NOT_AUTHORIZED_TO_TAKE_ACTION");
	//        } else {
	//            return "";
	//        }
	//    },
	    customFieldsDisplay: function () {
	       var l = this.byId("INFO_FORM");
	        var d = this.byId("customFieldsDataList").getItems();
	        for (var i = 0; i < d.length; i++) {
	            var a = d[i].getBindingContext().getObject().FieldName;
	            var b = d[i].getBindingContext().getObject().FieldValue;
	            var c = new sap.m.Label({
	                text: a,
	                design: "Bold"
	            });
	            var e = new sap.m.Text({ text: b });
	            l.addContent(c);
	            l.addContent(e);
	        }
	    },
	    requestCompleted: function (c) {
	        if (this.g_tlock == false) {
	            return;
	        }
	        this.g_tlock = false;
	        this.getView().getModel().detachRequestCompleted(this.requestCompleted, this);
	        var d = {};
	        var C = this.byId("INFO_FORM").getContent();
	        for (var i = 0; i < C.length; i++) {
	            var o = C[i];
	            var k = o.getId();
	            if (o.getMetadata()._sClassName === "sap.m.Text") {
	                k = k.replace("_txt", "_lbl");
	                d[k] = o.getText();
	                if (k.indexOf("_txt") == -1 && k.indexOf("_lbl") == -1) {
	                    this.byId("INFO_FORM").removeContent(o).destroy();
	                    continue;
	                }
	                o.setVisible(this.isVisible(o.getText()));
	            }
	        }
	        for (var i = 0; i < C.length; i++) {
	            var o = C[i];
	            var k = o.getId();
	            if (o.getMetadata()._sClassName === "sap.m.Label") {
	                if (k.indexOf("_txt") == -1 && k.indexOf("_lbl") == -1) {
	                    this.byId("INFO_FORM").removeContent(o).destroy();
	                    continue;
	                }
	                o.setVisible(this.isVisible(d[k]));
	            }
	        }
	        this.customFieldsDisplay();
	        this.gs_approvedCount = this.byId("AccessTab").getCount();
	        this.s_approvedCount = this.gs_approvedCount - this.s_rejectedCount;
	        this.getView().setBusy(false);
	        var l = "";
	        try {
	            var a = this.byId("accessRequestedList").getItems();
	            for (var i = 0; i < a.length; i++) {
	                l = a[i].getBindingContext().getObject().ErrorMessage;
	                if (l != "") {
	                    break;
	                }
	            }
	        } catch (e) {
	        }
	        if (l != "") {
	            this.byId("Forward").setEnabled(false);
	            this.byId("Submit").setEnabled(false);
	            l = l.replace(/&/g, "");
	            this.showErrorDialog(l);
	        }
	    }
	//    isVisible: function (p) {
	//        if (p && p != null && p != "") {
	//            return true;
	//        }
	//        return false;
	//    },
	//    formatDaysNumberDisplay: function (v) {
	//        if (v === 0) {
	//            return ".";
	//        } else {
	//            return v;
	//        }
	//    },
	//    formatDaysDisplay: function (v) {
	//        var r = this.getView().getModel("i18n").getResourceBundle();
	//        if (v === 0) {
	//            return r.getText("TODAY_TEXT");
	//        } else {
	//            return r.getText("NUMBER_UNIT_TEXT");
	//        }
	//    },
	//    formatRiskIconDisplay: function (p) {
	//        if (p > 0) {
	//            return true;
	//        } else {
	//            return false;
	//        }
	//    },
	//    formatRiskDisplay: function (p) {
	//        var r = this.getView().getModel("i18n").getResourceBundle();
	//        if (p > 1) {
	//            return r.getText("RISKS_LBL", [p]);
	//        } else if (p === 1) {
	//            return r.getText("RISK_LBL", [p]);
	//        } else {
	//            return "";
	//        }
	//    },
	//    doSubmit: function () {
	//        this.gSelectDialogApprove = this.initSelectDialog("Approve");
	//        this.gSelectDialogApprove.open();
	//    }
});