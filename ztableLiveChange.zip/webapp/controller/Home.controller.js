sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/FilterType",
	"com/ctliztableLiveChange/util/formatter",
	"sap/ui/model/json/JSONModel"
], function(Controller, Filter, FilterOperator, FilterType, formatter, JSONModel) {
	"use strict";

	return Controller.extend("com.ctliztableLiveChange.controller.Home", {
		formatter: formatter,

		onInit: function() {
			var that = this;
			//var oModel = new JSONModel();
			// oModel.loadData("tabLayout/Mydata.json"); 
			// this.getView().setModel(oModel);

			if (sap.ui.Device.system.desktop === true) {

				that.getView().byId("idTable").setWidth("100%");
			} else if (sap.ui.Device.system.phone === true) {

				that.getView().byId("idTable").setWidth("100%");
				// that.getView().byId("appmob").setWidth("25%");
				// that.getView().byId("appmob1").setWidth("25%");
				// that.getView().byId("summary").setWidth("25%");
				// that.getView().byId("sum").setWidth("25%");

			}
		},
		onRefresh: function() {
			//window.location.reload();
			//location.href = location.href;
			window.location.href = window.location.href;
		},
		onSearch: function(oEvent) {
			var that=this;
		var sQuery = oEvent.getSource().getValue();
			//var sQuery = oEvent.getParameter("newValue");
			var oList = that.getView().byId("idTable");
			var oBinding = oList.getBinding("items");
			
			if (sQuery) {
				var aFilter = [];

				aFilter.push(new Filter("MAN_USER_ID", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("USER_ID", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("EMP_FIRST_NAME", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("T_CODE", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("T_CODE_DSCRIPTN", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("TEAMLEAD_FUNAREA", FilterOperator.Contains, sQuery));
				aFilter.push(new Filter("MAN_APPROVE", FilterOperator.EQ, sQuery));
				aFilter.push(new Filter("TEAMLEAD_APPR", FilterOperator.EQ, sQuery));
                aFilter.push(new Filter("TEAMLEAD_APPR_ID", FilterOperator.Contains, sQuery));
               
				oBinding.filter(new Filter({
					filters: aFilter,
					and: false
				}));
			//	that.updateColor(oEvent);
			} else {
				// Use empty filter to show all list items
				// oBinding.filter(new Filter([])); does not work
				oBinding.filter([]);
			}

		},
		// onSearch: function (oEvent) {

		// 	var sQuery = oEvent.getSource().getValue();

		// 	// filter container
		// 	var oFilter = new Filter({

		// 		// two filters
		// 		filters: [

		// 			// filter for value 1
		// 			new Filter("MAN_USER_ID", FilterOperator.Contains, sQuery),
		// 			new Filter("USER_ID", FilterOperator.Contains, sQuery),
		// 			new Filter("EMP_FIRST_NAME", FilterOperator.Contains, sQuery),
		// 			new Filter("T_CODE", FilterOperator.Contains, sQuery),
		// 			new Filter("T_CODE_DSCRIPTN", FilterOperator.Contains, sQuery),
		// 			new Filter("TEAMLEAD_FUNAREA", FilterOperator.Contains, sQuery),
		// 			new Filter("MAN_APPROVE", FilterOperator.Contains, sQuery),
		// 			new Filter("TEAMLEAD_APPR", FilterOperator.Contains, sQuery),
		// 			new Filter("TEAMLEAD_APPR_ID", FilterOperator.Contains, sQuery)
		// 		]

		// 	});

		// 	var oBinding = this.byId("idTable").getBinding("items");

		// 	// apply filters
		// 	oBinding.filter(oFilter, FilterType.Application);

		// },
		updateColor: function(oEvent) {
			if (oEvent.getSource().getId().search("idStatus") !== -1) {
				if (oEvent.getSource().getBindingInfo("text").binding) {
					var aParam = oEvent.getSource().getBindingInfo("text").binding.getValue();

					if (aParam[0] === "" && aParam[1] === "Y") {
                        
						oEvent.getSource().addStyleClass("yellow");

					} else if (aParam[0] === "Y" && aParam[1] === "Y") {
                        oEvent.getSource().addStyleClass("");
					} else if (aParam[0] === "N" && aParam[1] === "Y") {
						oEvent.getSource().addStyleClass("yellow");

					} else if (aParam[0] === "Y" && aParam[1] === "") {
                        oEvent.getSource().addStyleClass("");
					} else if (aParam[0] === "" && aParam[1] === "") {
                        oEvent.getSource().addStyleClass("");
					} else if (aParam[0] === "" && aParam[1] === "N") {
						oEvent.getSource().addStyleClass("yellow");

					} else if (aParam[0] === "N" && aParam[1] === "N") {
                       oEvent.getSource().addStyleClass("");
					} else if (aParam[0] === "Y" && aParam[1] === "N") {
						oEvent.getSource().addStyleClass("yellow");

					} else {
                        oEvent.getSource().addStyleClass("");
					}
				}
			}
		}

		//	}
		// onUpdateFinished: function() {
		// 		var oDataTable = this.getView().byId("idTable");
		// 		var oTableLines = oDataTable.getItems();
		// 		for (var line = 0; line < oTableLines.length; line++) {
		// 			var cells = oTableLines[line].getCells();

		// 			if (cells[0].getValue() === "changeClass") {
		// 				cells[2].addStyleClass("yellow");
		// 			}

		// 		}
		// 	}
		// onSearch: function (oEvent) {
		// 	var that = this;
		// 	var sQuery = oEvent.getSource().getValue();
		// 	var aFilter=[];
		// 	if(sQuery && sQuery.length>0){
		// 		aFilter.push(new sap.ui.model.Filter("T_CODE",sap.ui.model.FilterOperator.Contains,sQuery));
		// 		aFilter.push(new sap.ui.model.Filter("MAN_APPROVE",sap.ui.model.FilterOperator.Contains,sQuery));
		// 	}else{
		// 		return;

		// 	}
		// 	that.byId("idTable").getBinding("items").filter(aFilter);
		// }

	});

});