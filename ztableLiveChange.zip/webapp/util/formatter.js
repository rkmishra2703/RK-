sap.ui.define([
		"sap/ui/model/json/JSONModel"
	]

	,
	function(JSONModel) {

		return {

			// availableColor: function(available, available1) {
			// 	if (available === "" && available1 === "Y") {

			// 		return "Keep";
			// 	} else if (available === "Y" && available1 === "Y") {
			// 		return "Keep";

			// 	} else if (available === "N" && available1 === "Y") {

			// 		return "Keep";
			// 	} else if (available === "Y" && available1 === "") {
			// 		return "Keep";
			// 	} else if (available === "" && available1 === "") {
			// 		return "";
			// 	} else if (available === "" && available1 === "N") {

			// 		return "Remove";
			// 	} else if (available === "N" && available1 === "N") {

			// 		return "Remove";
			// 	} else if (available === "Y" && available1 === "N") {

			// 		return "Remove";
			// 	} else {
			// 		return "Remove";
			// 	}

			// }
			availableColor: function(available, available1) {
				if (available !== available1) {
					//idText.addStyleClass("yellow");
					if (available === "" && available1 === "Y") {
						return "Keep";
					} else if (available === "N" && available1 === "Y") {
						return "Keep";
					} else if (available === "Y" && available1 === "") {
						return "Keep";
					} else if (available === "" && available1 === "N") {
						return "Remove";
					} else if (available === "Y" && available1 === "N") {
						return "Remove";
					}else if (available === "N" && available1 === "") {
						return "Remove";
					}
				} else if (available === available1) {
					if (available === "Y" && available1 === "Y") {
						return "Keep";
					} else if (available === "N" && available1 === "N") {
						return "Remove";
					} else if (available === "" && available1 === "") {
						return "";
					}
				}
			}

		};

	});