sap.ui.define([
	"com/table/tabledemo/test/unit/controller/View1.controller"
], function () {
	"use strict";
});