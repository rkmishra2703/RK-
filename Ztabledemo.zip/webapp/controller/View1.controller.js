sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";
 
	return Controller.extend("com.table.tabledemo.controller.View1", {
		onInit: function () {
		
		var oModel_VendorInbox = new sap.ui.model.json.JSONModel();
        $.ajax({
            url: "https://api.myjson.com/bins/ijyy2",
            async: false,
            type: 'Get',
            dataType: 'json',
            success: function(response) {
                var data = response;
                oModel_VendorInbox.setData(data);
                console.log("VendorList", data);
            }
        });
        this.getView().setModel(oModel_VendorInbox, "VendorList");

		}
		
	
	
	
	
});

});