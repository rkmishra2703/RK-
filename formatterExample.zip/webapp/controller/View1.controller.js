sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/FilterType",
	"com/formatterformatterExample/util/formatter",
	"sap/ui/model/json/JSONModel"
], function(Controller, Filter, FilterOperator, FilterType, formatter, JSONModel) {
	"use strict";

	return Controller.extend("com.formatterformatterExample.controller.View1", {
		formatter: formatter,
		onInit: function() {
			var that = this;
			//var oModel = new JSONModel();
			// oModel.loadData("tabLayout/Mydata.json"); 
			// this.getView().setModel(oModel);

			if (sap.ui.Device.system.desktop === true) {

				that.getView().byId("idTable").setWidth("100%");
			} else if (sap.ui.Device.system.phone === true) {

				that.getView().byId("idTable").setWidth("100%");
				// that.getView().byId("appmob").setWidth("25%");
				// that.getView().byId("appmob1").setWidth("25%");
				// that.getView().byId("summary").setWidth("25%");
				// that.getView().byId("sum").setWidth("25%");

			}
		},
		
			onSearch: function(oEvent) {
			var that=this;
		var sQuery = oEvent.getSource().getValue();
			//var sQuery = oEvent.getParameter("newValue");
			var oList = this.getView().byId("idTable");
			var oBinding = oList.getBinding("items");
			
			if (sQuery && sQuery.length > 0) {
				var aFilter = [];

				aFilter.push(new Filter("MAN_USER_ID", FilterOperator.EQ, sQuery));
				aFilter.push(new Filter("USER_ID", FilterOperator.EQ, sQuery));
				aFilter.push(new Filter("EMP_FIRST_NAME", FilterOperator.EQ, sQuery));
				aFilter.push(new Filter("T_CODE", FilterOperator.EQ, sQuery));
				aFilter.push(new Filter("T_CODE_DSCRIPTN", FilterOperator.EQ, sQuery));
				aFilter.push(new Filter("TEAMLEAD_FUNAREA", FilterOperator.EQ, sQuery));
				aFilter.push(new Filter("MAN_APPROVE", FilterOperator.EQ, sQuery));
				aFilter.push(new Filter("TEAMLEAD_APPR", FilterOperator.EQ, sQuery));
                aFilter.push(new Filter("TEAMLEAD_APPR_ID", FilterOperator.EQ, sQuery));

				oBinding.filter(new Filter({
					filters: aFilter,
					and: false
				}));
			//	that.updateColor(oEvent);
			} else {
				// Use empty filter to show all list items
				// oBinding.filter(new Filter([])); does not work
				oBinding.filter([]);
			}

		}

	});
});