jQuery.sap.declare("ui.s2p.mm.requisition.approve.MM_PR_APVExtension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "ui.s2p.mm.requisition.approve",  
	url: jQuery.sap.getModulePath("ui.s2p.mm.requisition.approve.MM_PR_APVExtension") + "/../MM_PR_APV" // provide parent project url
	// we use a URL relative to our own component; might be different if
	// extension app is deployed with customer namespace
});


ui.s2p.mm.requisition.approve.Component.extend("ui.s2p.mm.requisition.approve.MM_PR_APVExtension.Component", {
	metadata: {
		version : "1.0",
		config : {
			"sap.ca.i18Nconfigs": {
				"bundleName":"ui.s2p.mm.requisition.approve.MM_PR_APVExtension.i18n.i18n"
			},
			
			"sap.ca.serviceConfigs": {
				useBatch:false,
			},
		},
		
		customizing: {
		"sap.ui.viewExtensions": {
			"ui.s2p.mm.requisition.approve.view.S3": {
				"extInformation": {
					className: "sap.ui.core.Fragment",
					fragmentName: "ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.extInformationCustom",
					type: "XML",
				},
			},
		},

			"sap.ui.controllerExtensions": {
				"ui.s2p.mm.requisition.approve.view.S3_header": {
					controllerName: "ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom",
				},

				"ui.s2p.mm.requisition.approve.view.S3": {
					controllerName: "ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3Custom",
				},
			},

			"sap.ui.viewReplacements": {
			
				"ui.s2p.mm.requisition.approve.view.S3_header": {
					viewName: "ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom",
					type: "XML",
				},

				"ui.s2p.mm.requisition.approve.view.S2": {
					viewName: "ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S2Custom",
					type: "XML",
				},
			},

			"sap.ui.viewModifications": {
				"ui.s2p.mm.requisition.approve.view.AccountAssignmentTable": {
					"AccountAssignmentTableColumnPercentage": {
						"visible": false
					},
				},
			},

		}			
	}
});