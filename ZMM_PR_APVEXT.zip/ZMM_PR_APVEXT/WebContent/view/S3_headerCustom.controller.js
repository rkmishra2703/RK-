sap.ui.controller("ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onInit: function() {
//
//  },

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onBeforeRendering: function() {
//
//  },

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
 /* onAfterRendering: function() {
    var tb = this.getView().byId("tabBar"),
      tbi = tb.getItems(),
      cnt = 1;
    for(var i=1; i<tbi.length; i++){
      if (!tbi[i].getVisible()){
        cnt++;
      }else
        break;
    }
    if(cnt == tbi.length)
      tb.addStyleClass('removeHover');
  }*/

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onExit: function() {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  refreshScreen : function(d) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onDataLoaded : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  navToItemDetails : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  openApproveRejectDialog : function(a) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  press : function() {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  press : function() {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  afterClose : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  handleApproveRejectExecute : function(r, d) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  _handleApproveRejectSuccess : function(s) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  _handleApproveRejectForwardFail : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  handleForward : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onNamePress : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onForwardedPress : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onSubstitutingPress : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onNoteSenderPress : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  openEmployeeLaunch : function(e, r) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onSupplierPress : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onCompanyLaunch : function(e, r) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  handleServiceLineItemPress : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  handleLimitLineItemPress : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
/*         onAttachment : function(e) {
          var c = e.getSource().getBindingContext();
          var m = c.getProperty().__metadata.media_src;
          if (m.indexOf('http:') > -1) {
                  m = m.replace('http:', 'https:');
                  
              }
          sap.m.URLHelper.redirect(m, false);
         }*/
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  handleNavBack : function() {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  onRequestFailed : function(e) {
//
//  },
 
/**
* @memberOf ui.s2p.mm.requisition.approve.MM_PR_APVExtension.view.S3_headerCustom
*/
//  isMainScreen : function() {
//
//  }

});