/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(J,D){"use strict";var d=null;var b=null;var c=null;var r=null;return{createDeviceModel:function(){var m=new J(D);m.setDefaultBindingMode("OneWay");return m;},createFLPModel:function(){var g=jQuery.sap.getObject("sap.ushell.Container.getUser"),i=g?g().isJamActive():false,m=new J({isShareInJamActive:i});m.setDefaultBindingMode("OneWay");return m;},initoDataModel:function(o){d=o;},initoBundle:function(t){b=t;},initComponent:function(a){c=a;},initoRouter:function(a){r=a;},getoRouter:function(){return r;},getoComponent:function(){return c;},getoDataModel:function(){return d;},getoBundle:function(){return b;}};});
