/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["hcm/fab/mytimesheet/controller/BaseController"],function(B){"use strict";return B.extend("hcm.fab.mytimesheet.controller.NotFound",{onLinkPressed:function(){this.getRouter().navTo("worklist");}});});
