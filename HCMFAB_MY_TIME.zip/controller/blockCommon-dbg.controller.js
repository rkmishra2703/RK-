/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
 "hcm/fab/mytimesheet/controller/BaseController",
 "sap/ui/model/json/JSONModel",
 "hcm/fab/mytimesheet/model/formatter",
 'sap/m/MessagePopover',
 'sap/m/MessagePopoverItem',
 "sap/ui/core/routing/History",
 "sap/m/Dialog",
 "sap/m/Text",
 'hcm/fab/mytimesheet/model/models',
 "sap/ui/model/Filter",
 "sap/ui/model/FilterOperator",

], function (BaseController, JSONModel, formatter, MessagePopover, History, Dialog, Text, models, Filter, FilterOperator) {
 "use strict";
 return BaseController.extend("hcm.fab.mytimesheet.controller.blockCommon", {
  formatter: formatter,
  onInit: function () {
   var iOriginalBusyDelay,
    oViewModel = new JSONModel({
     busy: true,
     delay: 0
    });
   this._nCounter = 0;
   // this.oComponent = models.getoComponent();
   // this.oBundle = this.getResourceBundle();
   // var oModel = this.getGlobalModel("ProfileFields");
   // var oControl = this.getGlobalModel("controls");
   // this.oControl = oControl;
   this.busyDialog = new sap.m.BusyDialog();
   // this.oFormatYyyymmdd = sap.ui.core.format.DateFormat.getInstance({
   //  pattern: "yyyy-MM-dd",
   //  calendarType: sap.ui.core.CalendarType.Gregorian
   // });
   // // var oEditModel = this.getGlobalModel("EditedTask");
   // // this.setModel(oControl, "controls");
   // // this.setModel(oEditModel, "EditedTask");
   // this.oRouter = models.getoRouter();
   // var oModel = this.getModel("createGroup");
   // this.setModel(oModel, "createGroup");
   var oPernr = this.getInitPernr();
   if (oPernr) {
    this.empID = oPernr;
    this.oDataModel = this.getoDataModel();
    // this.oBundle = this.getResourceBundle();
    this.oBundle = this.getoBundle();
   }
   // this.oDataModel = this.getOwnerComponent().getModel();

  },
  init: function (oData, oText) {
   // oDataModel = oData;
   // oBundle = oText;
   // this.oDataModel = oDataModel;
   // this.oBundle = oText;
  },
  onAfterRendering: function () {
   // this.oDataModel = this.getOwnerComponent().getModel();
   // this.oBundle = this.getResourceBundle();
   // var oPernr = this.getPernr();
   // this.oRouter = this.getRouter();
   // this.oDataModel = models.getoDataModel();
   // this.oBundle = this.getResourceBundle();
   // this.oBundle = models.getoBundle();
   this.oDataModel = this.getoDataModel();
   this.oBundle = this.getoBundle();
   var oPernr = this.getInitPernr();
   this.empID = oPernr;
   // var oModel = this.getModel("createGroup");
   // this.setModel(oModel, "createGroup");

  },
  showBusy: function () {
   this._nCounter++;
   if (this._nCounter === 1) {
    this.busyDialog.open();
   }
  },
  hideBusy: function (forceHide) {
   if (this._nCounter === 0) {
    return;
   }
   this._nCounter = forceHide ? 0 : Math.max(0,
    this._nCounter - 1);
   if (this._nCounter > 0) {
    return;
   }
   this.busyDialog.close();
  },
  onValueHelp: function (oEvent) {
   var that = this;
   var FieldName = oEvent.getSource().getCustomData('FieldName')[0].getValue();
   that.FieldName = FieldName;
   var FieldLabel = oEvent.getSource().getCustomData('FieldLabel')[2].getValue();
   var oControl = this.getModel("controls");
   oControl.setProperty("/fieldLabel", FieldLabel);
   this.setModel(oControl, "controls");
   new Promise(
    function (fnResolve, fnReject) {
     that.getValueHelpCollection(FieldName, oEvent.getSource());
     fnResolve(
      // that.valueHelpFragment(oEvent.getSource())
     );
     fnReject();
    }
   );
  },
  valueHelpFragment: function (oSource) {
   var that = this;
   var oView = this.getView();
   this.oValueHelpSource = oSource;
   // create dialog lazily
   var oDialog;
   // if (!oDialog) {
   var oDialogController = {
    handleConfirm: that.handleClick.bind(this),
    handleCancel: function (oEvent) {
     oDialog.close();
     // oDialog.destroy();
     var data = [];
     var oModel = new JSONModel(data);
     that.setModel(oModel, "ValueHelp");
    }.bind(that),
    handleBeforeOpen: function (oEvent) {
     // // var oTable = oEvent.getSource().getTable();
     // var oModel = new JSONModel();
     // var data = that.getModel("ValueHelp").getData();
     // var columns = [];
     // // for(var i=0;i<data.length;i++){
     // columns.push({
     //  label: data[0].DispField1Header,
     //  template: data[0].DispField1Header
     // });
     // // var oColumn = new sap.m.Column({text:"Awart"});
     // if(data[0].DispField2Header !== ""){
     // columns.push({label:data[0].DispField2Header,template:data[0].DispField2Header});
     // }
     // if(data[0].DispField3Header !== ""){
     // columns.push({label:data[0].DispField3Header,template:data[0].DispField3Header});
     // }
     // if(data[0].DispField4Header !== ""){
     // columns.push({label:data[0].DispField4Header,template:data[0].DispField4Header});
     // }
     // // }
     // var cols = {cols:columns};
     // oModel.setData(cols);
     // oEvent.getSource().getTable().setModel(oModel,"columns");
     // var oRowsModel = new sap.ui.model.json.JSONModel();
     // oRowsModel.setData(this.oTableItems);
     // oEvent.getSource().getTable().setModel(oRowsModel);
     // if (oEvent.getSource().getTable().bindRows) {
     //  oEvent.getSource().getTable().bindRows("/");
     // }
     // if (oEvent.getSource().getTable().bindItems) {
     //  var oTable = oEvent.getSource().getTable();

     //  oTable.bindAggregation("items", "/", function(sId, oContext) {
     //   var aCols = oTable.getModel("columns").getData().cols;

     //   return new sap.m.ColumnListItem({
     //    cells: aCols.map(function(column) {
     //     var colname = column.template;
     //     return new sap.m.Label({
     //      text: "{" + colname + "}"
     //     });
     //    })
     //   });
     //  });
     // }
    },
    handleAfterOpen: function (oEvent) {
     // var oTable = oEvent.getSource().getTable();
     var oModel = new JSONModel();
     if (that.getModel("ValueHelpHits") && that.getModel("ValueHelp")) {
      var data = that.getModel("ValueHelpHits").getData();
      var seldata = that.getModel("ValueHelp").getData();
      var columns = [];
      that.oValueTable = oEvent.getSource().getTable();
      // for(var i=0;i<data.length;i++){
      if (seldata.FieldName === "APPROVER") {
       data[0].DispField2Header = that.oBundle.getText('approverName');
       // data[0].DispField1Header = that.oBundle.getText('approverName');
       columns.push({
        label: that.oBundle.getText("key"),
        template: "DispField1Val"
       });
      } else {
       columns.push({
        label: that.oBundle.getText("key"),
        template: "DispField1Id"
       });
      }
      if (data[0].DispField1Header && data[0].DispField1Header !== "") {
       that.DispField1Header = data[0].DispField1Header;
       columns.push({
        label: data[0].DispField1Header,
        template: "DispField1Val"
       });
      }
      if (data[0].DispField2Header && data[0].DispField2Header !== "") {
       columns.push({
        label: data[0].DispField2Header,
        template: "DispField2Val"
       });
      }
      if (data[0].DispField3Header && data[0].DispField3Header !== "") {
       columns.push({
        label: data[0].DispField3Header,
        template: "DispField3Val"
       });
      }
      if (data[0].DispField4Header && data[0].DispField4Header !== "") {
       columns.push({
        label: data[0].DispField4Header,
        template: "DispField4Val"
       });
      }
      if (seldata.FieldName === "APPROVER") {
       data[0].DispField1Header = that.oBundle.getText('approverName');
       that.DispField1Header = data[0].DispField1Header;
      }
      // }
      var cols = {
       cols: columns
      };
      oModel.setData(cols);
      oEvent.getSource().getTable().setModel(oModel, "columns");
      if (seldata.FieldName === "APPROVER") {
       oEvent.getSource().setKey("DispField1Val");
       oEvent.getSource().setDescriptionKey("DispField2Val");
      } else {
       oEvent.getSource().setKey("DispField1Id");
       oEvent.getSource().setDescriptionKey("DispField1Val");
      }
      var oRowsModel = new sap.ui.model.json.JSONModel();
      oRowsModel.setData(data);
      oEvent.getSource().getTable().setModel(oRowsModel);
      if (oEvent.getSource().getTable().bindRows) {
       oEvent.getSource().getTable().bindRows("/");
      }
      if (oEvent.getSource().getTable().bindItems) {
       var oTable = oEvent.getSource().getTable();

       oTable.bindAggregation("items", "/", function (sId, oContext) {
        var aCols = oTable.getModel("columns").getData().cols;

        return new sap.m.ColumnListItem({
         cells: aCols.map(function (column) {
          var colname = column.template;
          return new sap.m.Label({
           text: "{" + colname + "}"
          });
         })
        });
       });
      }
      // oEvent.getSource().setTokens(this.oMultiInput.getTokens());
      var filter = [];
      if (seldata.SelField1Text && seldata.SelField1Text !== "") {
       filter.push(new sap.ui.comp.filterbar.FilterGroupItem({
        groupTitle: "searchFields",
        groupName: "Assignment",
        name: seldata.SelField1Name,
        label: seldata.SelField1Text,
        control: new sap.m.Input()
       }));
      }
      if (seldata.SelField2Text && seldata.SelField2Text !== "") {
       filter.push(new sap.ui.comp.filterbar.FilterGroupItem({
        groupTitle: "searchFields",
        groupName: "Assignment",
        name: seldata.SelField2Name,
        label: seldata.SelField2Text,
        control: new sap.m.Input()
       }));
      }
      if (seldata.SelField3Text && seldata.SelField3Text !== "") {
       filter.push(new sap.ui.comp.filterbar.FilterGroupItem({
        groupTitle: "searchFields",
        groupName: "Assignment",
        name: seldata.SelField3Name,
        label: seldata.SelField3Text,
        control: new sap.m.Input()
       }));
      }
      if (seldata.SelField4Text && seldata.SelField4Text !== "") {
       filter.push(new sap.ui.comp.filterbar.FilterGroupItem({
        groupTitle: "searchFields",
        groupName: "Assignment",
        name: seldata.SelField4Name,
        label: seldata.SelField4Text,
        control: new sap.m.Input()
       }));
      }

      var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
       advancedMode: true,
       filterBarExpanded: false,
       showGoOnFB: !sap.ui.Device.system.phone,
       filterGroupItems: filter,
       search: function (event) {
        var oFilter = [];
        if (event.getParameters().selectionSet[0]) {
         var selectedKey = event.getParameters().selectionSet[0].getValue();
         var FilterOperator = sap.ui.model.FilterOperator.Contains;
         oFilter.push(new sap.ui.model.Filter("DispField1Val", FilterOperator, selectedKey));
        }
        if (event.getParameters().selectionSet[1]) {
         var selectedKey = event.getParameters().selectionSet[1].getValue();
         var FilterOperator = sap.ui.model.FilterOperator.Contains;
         oFilter.push(new sap.ui.model.Filter("DispField2Val", FilterOperator, selectedKey));
        }
        if (event.getParameters().selectionSet[2]) {
         var selectedKey = event.getParameters().selectionSet[2].getValue();
         var FilterOperator = sap.ui.model.FilterOperator.Contains;
         oFilter.push(new sap.ui.model.Filter("DispField3Val", FilterOperator, selectedKey));
        }
        if (event.getParameters().selectionSet[3]) {
         var selectedKey = event.getParameters().selectionSet[3].getValue();
         var FilterOperator = sap.ui.model.FilterOperator.Contains;
         oFilter.push(new sap.ui.model.Filter("DispField4Val", FilterOperator, selectedKey));
        }
        that.oValueTable.getBinding('rows').filter(oFilter);
       }
      });

      if (oFilterBar.setBasicSearch) {
       if (that.DispField1Header && that.DispField1Header !== "") {
        oFilterBar.setBasicSearch(new sap.m.SearchField({
         showSearchButton: sap.ui.Device.system.phone,
         placeholder: that.oBundle.getText('searchWithField', [that.DispField1Header]),
         search: function (event) {
          var oFilter = [];
          var selectedKey = event.getParameter('query');
          var FilterOperator = sap.ui.model.FilterOperator.Contains;
          oFilter.push(new sap.ui.model.Filter("DispField1Val", FilterOperator, selectedKey));
          if (that.FieldName === 'APPROVER') {
           // oDialog.destroy();
           that.getValueHelpCollection(that.FieldName, that.SourceField, {
            fieldName: "FieldValue",
            operation: sap.ui.model.FilterOperator.EQ,
            value: selectedKey
           });
          } else {
           that.oValueTable.getBinding('rows').filter(oFilter);
          }

         }
        }));

       } else {
        oFilterBar.setBasicSearch(new sap.m.SearchField({
         showSearchButton: sap.ui.Device.system.phone,
         placeholder: that.oBundle.getText('searchWithKey'),
         search: function (event) {
          var oFilter = [];
          var selectedKey = event.getParameter('query');
          var FilterOperator = sap.ui.model.FilterOperator.Contains;
          oFilter.push(new sap.ui.model.Filter("DispField1Id", FilterOperator, selectedKey));
          that.oValueTable.getBinding('rows').filter(oFilter);
         }
        }));
       }

      }

      oEvent.getSource().setFilterBar(oFilterBar);
      oEvent.getSource().update();
     }
    },
    handleAfterClose: function (oEvent) {
     oDialog.destroy();
    },
    handleClickValueHelp: that.handleClick.bind(that)
   };
   // create dialog via fragment factory
   oDialog = sap.ui.xmlfragment(oView.getId(), "hcm.fab.mytimesheet.view.fragments.ValueHelpDialog", oDialogController);
   // connect dialog to view (models, lifecycle)
   oView.addDependent(oDialog);
   // }
   jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);

   jQuery.sap.delayedCall(0, this, function () {
    oDialog.open();
   });
  },

  getValueHelpCollection: function (FieldName, oSource, search) {
   var that = this;
   this.SourceField = oSource;
   this.showBusy();
   var oModel = new JSONModel();
   var orgModel = new JSONModel();
   var f = [];
   // var a = new sap.ui.model.Filter({
   //  path: "StartDate",
   //  operator: sap.ui.model.FilterOperator.EQ,
   //  value1: this.oFormatYyyymmdd.format(that.startDate)
   // });
   // var b = new sap.ui.model.Filter({
   //  path: "EndDate",
   //  operator: sap.ui.model.FilterOperator.EQ,
   //  value1: this.oFormatYyyymmdd.format(that.endDate)
   // });
   var c = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   var d = new sap.ui.model.Filter({
    path: "FieldName",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: FieldName
   });
   if (search) {
    if (FieldName === "APPROVER") {
     var e = new sap.ui.model.Filter({
      path: search.fieldName,
      operator: search.operation,
      value1: search.value
     });
     f.push(e);
    }
   } else {
    if (FieldName === "APPROVER") {
     var e = new sap.ui.model.Filter({
      path: "FieldValue",
      operator: sap.ui.model.FilterOperator.EQ,
      value1: "A"
     });
     f.push(e);
    }
   }

   f.push(c);
   f.push(d);
   var mParameters = {
    urlParameters: '$expand=ValueHelpHits',
    filters: f,
    success: function (oData, oResponse) {
     if (oData.results.length >= 1) {
      if (search) {
       that.results = oData.results[0].ValueHelpHits.results;
       oModel.setData(that.results);
       that.oValueTable.setModel(oModel);
       // orgModel.setData(oData.results[0]);
       // that.oValueTable.setModel(orgModel, "ValueHelp").updateBindings();
      } else {
       that.results = oData.results[0].ValueHelpHits.results;
       oModel.setData(that.results);
       that.setModel(oModel, "ValueHelpHits").updateBindings();
       orgModel.setData(oData.results[0]);
       that.setModel(orgModel, "ValueHelp").updateBindings();

      }

     }
     if (search) {
      // that.oValueTable.updateAggregation();

     } else {
      that.valueHelpFragment(oSource);
     }
     that.hideBusy(true);

    },
    error: function (oError) {
     that.hideBusy(true);
    }
   };
   this.oDataModel.read('/ValueHelpCollection', mParameters);
  },
  handleClick: function (oEvent) {
   var value = oEvent.getParameter('tokens');
   // this.oValueHelpSource.setTokens(value);
   this.oValueHelpSource.setValue(value[0].getKey());
   if (this.FieldName === "APPROVER") {
    this.getModel("EditedTask").getData().ApproverName = value[0].getText();
   }
   oEvent.getSource().close();
  },
  onAddToGroup: function (oEvent) {
   var that = this;
   // create popover
   var that = this;
   var oDialogController = {
    handleClose: function (event) {
     // that._oPopover.close();
     // that._oPopover.destroy();
    },
    handleOk: function (event) {

     // var index = oEvent.getSource().getBindingContext('Assignments').getPath().split('/')[1];
     var oCreateGroup = that.getModel("createGroup").getData();
     var oAssignments = that.getModel("Assignments").getData();
     var addData = that.getModel("AddAssignments").getData();
     var addAssignments = {
      "groupId": oCreateGroup.groupId === null ? "" : oCreateGroup.groupId,
      "groupName": oCreateGroup.groupName,
      "Assignments": []
     };
     for (var i = 0; i < event.getParameter("selectedContexts").length; i++) {
      var index = event.getParameter("selectedContexts")[i].getPath().split('/')[1];

      if (oCreateGroup.Assignments.length === 0) {
       oCreateGroup.Assignments.push({
        "AssignmentId": oAssignments[index].AssignmentId,
        "AssignmentName": oAssignments[index].AssignmentName,
        "ValidityStartDate": oAssignments[index].ValidityStartDate,
        "ValidityEndDate": oAssignments[index].ValidityEndDate,
       });
       addAssignments.Assignments.push({
        "AssignmentId": oAssignments[index].AssignmentId,
        "AssignmentName": oAssignments[index].AssignmentName,
        "ValidityStartDate": oAssignments[index].ValidityStartDate,
        "ValidityEndDate": oAssignments[index].ValidityEndDate,
       });
      } else {
       var oAssignmentFound = $.grep(oCreateGroup.Assignments, function (element, ind) {
        if (element) {
         return element.AssignmentId === oAssignments[index].AssignmentId;
        }

       });
       if (oAssignmentFound.length === 0) {
        oCreateGroup.Assignments.push({
         "AssignmentId": oAssignments[index].AssignmentId,
         "AssignmentName": oAssignments[index].AssignmentName,
         "ValidityStartDate": oAssignments[index].ValidityStartDate,
         "ValidityEndDate": oAssignments[index].ValidityEndDate,
        });
        addAssignments.Assignments.push({
         "AssignmentId": oAssignments[index].AssignmentId,
         "AssignmentName": oAssignments[index].AssignmentName,
         "ValidityStartDate": oAssignments[index].ValidityStartDate,
         "ValidityEndDate": oAssignments[index].ValidityEndDate,
        });
       }

      }

     }
     // that.setModel(new JSONModel(oCreateGroup), "createGroup");
     that.getModel("createGroup").setData(oCreateGroup);
     if (!addData.Assignments) {
      that.getModel("AddAssignments").setData(addAssignments);
     } else {
      // addData.Assignments.push(addAssignments.Assignments[0]);
      that.getModel("AddAssignments").setData(addData);
     }

     // that._oPopover.close();
     // that._oPopover.destroy();
    },
    handleChange: function (oEvent) {},
   };
   var data = $.extend(true, [], this.getModel('Assignments').getData());
   // var oModel = new JSONModel(data);
   // this.setModel(oModel, "oldModel");
   if (!this._oPopover) {
    this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.AddAssignmentsInGroup",
     oDialogController);
    // this._oPopover.bindElement('TimeData>' + oEvent.getSource().getBindingContext('TimeData').getPath());
    this.getView().addDependent(this._oPopover);

   }

   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   jQuery.sap.delayedCall(0, this, function () {
    this._oPopover.open(oEvent.getSource());
   });
  },
  onRemoveAssignment: function (oEvent) {
   var that = this;
   var oTable = this.byId('idCreateGroup');
   var oSelectedGroup = this.getModel("createGroup").getData();
   var deleteData = this.getModel("DeleteAssignments").getData();
   var deleteAssignments = {
    "groupId": oSelectedGroup.groupId,
    "groupName": oSelectedGroup.groupName,
    "Assignments": []
   };
   var index = oEvent.getSource().getParent().getBindingContext('createGroup').getPath().split('/')[2];

   deleteAssignments.Assignments.push($.extend(true, {}, oSelectedGroup.Assignments[index]));
   oSelectedGroup.Assignments.splice(index, 1);
   // this.setModel(new JSONModel(oSelectedGroup), "createGroup");
   this.getModel("createGroup").setData(oSelectedGroup);
   if (!deleteData.Assignments) {
    this.getModel("DeleteAssignments").setData(deleteAssignments);
   } else {
    deleteData.Assignments.push(deleteAssignments.Assignments[0]);
    this.getModel("DeleteAssignments").setData(deleteData);
   }

  },
  handleSubmitInput: function (oEvent) {
   // var that = this;
   // var oAssignment = this.getModel("createGroup").getData();
   // var addAssignments = {
   //  "groupId": oAssignment.groupId,
   //  "groupName": oAssignment.groupName,
   //  "Assignments": oAssignment.Assignments
   // };
   // if (!oAssignment.Assignments) {
   //  that.getModel("AddAssignments").setData(addAssignments);
   // } else {
   //  oAssignment.Assignments.push(addAssignments.Assignments[0]);
   //  that.getModel("AddAssignments").setData(oAssignment);
   // }
   // this.getModel("AddAssignments").setData(addAssignments);
  }

 });
});