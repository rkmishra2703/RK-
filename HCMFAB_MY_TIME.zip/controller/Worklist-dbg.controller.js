/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
 "hcm/fab/mytimesheet/controller/BaseController",
 "sap/ui/model/json/JSONModel",
 "sap/ui/core/routing/History",
 "hcm/fab/mytimesheet/model/formatter",
 "sap/ui/model/Filter",
 "sap/ui/model/FilterOperator",
 'sap/m/MessagePopover',
 'sap/m/MessagePopoverItem',
 'sap/m/TablePersoController',
 'sap/m/GroupHeaderListItem',
 'sap/ui/core/Fragment',
 'sap/m/Dialog',
 'sap/m/Text',
], function (BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessagePopover, MessagePopoverItem,
 TablePersoController, GroupHeaderListItem, Fragment, Dialog, Text) {
 "use strict";
 /**
  * Sets the error state of controls that use a data type.
  *
  * @param {object} oEvent
  *   the event raised by UI5 when validation occurs.    
  */
 function controlErrorHandler(oEvent) {
  var oControl = oEvent.getParameter("element");
  var sErrorMessage = oEvent.getParameter("message");

  if (oControl && oControl.setValueStateText && sErrorMessage) {
   oControl.setValueStateText(sErrorMessage);
  }
  if (oControl && oControl.setValueState) {
   oControl.setValueState("Error");
  }
 }
 /**
  * Sets the normal state of controls that passed a validation.
  *
  * @param {object} oEvent
  *   the event raised by UI5 when validation occurs.
  */
 function controlNoErrorHandler(oEvent) {
  var oControl = oEvent.getParameter("element");
  if (oControl && oControl.setValueState) {
   oControl.setValueState("None");
  }
 }

 return BaseController.extend("hcm.fab.mytimesheet.controller.Worklist", {

  formatter: formatter,

  /* =========================================================== */
  /* lifecycle methods                                           */
  /* =========================================================== */

  /**
   * Called when the worklist controller is instantiated.
   * @public
   */
  onInit: function () {
   this.oDataModel = this.getOwnerComponent().getModel();
   this.oCEModel = this.getOwnerComponent().getModel("ce");
   this.oBundle = this.getResourceBundle();
   this.oErrorHandler = this.getOwnerComponent()._oErrorHandler;
   this.initoDataModel(this.oDataModel);
   this.initoBundle(this.oBundle);
   this.initRouter(this.getRouter());
   this.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");
   this.empId = null;
   this._nCounter = 0;
   this.oFormatYyyymmdd = sap.ui.core.format.DateFormat.getInstance({
    pattern: "yyyy-MM-dd",
    calendarType: sap.ui.core.CalendarType.Gregorian
   });
   this.oFormatyyyymmdd = sap.ui.core.format.DateFormat.getInstance({
    pattern: "yyyyMMdd",
    calendarType: sap.ui.core.CalendarType.Gregorian
   });
   this.oFormatDate = sap.ui.core.format.DateFormat.getInstance({
    style: "full",
    calendarType: sap.ui.core.CalendarType.Gregorian
   });
   // Handle validation
   sap.ui.getCore().attachParseError(controlErrorHandler);
   sap.ui.getCore().attachValidationSuccess(controlNoErrorHandler);
   this.busyDialog = new sap.m.BusyDialog();
   this.oRouter = this.getOwnerComponent().getRouter();
   this.calendar = this.byId('idCalendar');
   this.mCalendar = this.byId('mCalendar');
   this.oTable = this.byId('idOverviewTable');
   this.oTaskTable = this.byId('idTasks');
   this.oToDoTable = this.byId('idToDoList');
   this.oRouter.getRoute("worklist").attachMatched(this.worklistRouteMatched.bind(this), this);
   var data = [];
   var oModel = new JSONModel();
   oModel.setData(data);
   this.setModel(oModel, 'deleteRecords');
   this.setModel(oModel, 'changedRecords');
   this.setModel(oModel, 'newRecords');
   this.updatedRecords = [];
   this.originalTimedata = [];
   this.newRecords = [];
   this.deleteRecords = [];
   var curDate = new Date();
   var firstdate = this.byId('idCalendar').getStartDate();
   firstdate.setMonth(curDate.getMonth() - 1, 1);
   this.dateFrom = this.getFirstDayOfWeek(new Date(firstdate), 'Sunday');
   curDate = new Date();
   curDate.setMonth(curDate.getMonth() + 3, 0);
   this.dateTo = curDate;
   this.calendar.destroySelectedDates();
   this.startdate = this.getFirstDayOfWeek(new Date(), 'Sunday');
   this.enddate = this.getLastDayOfWeek(new Date(), 'Sunday');
   var selectedDates = new sap.ui.unified.DateRange();
   selectedDates.setStartDate(this.startdate);
   selectedDates.setEndDate(this.enddate);
   var controlModel = new JSONModel({
    showFooter: false,
    submitDraft: false,
    sendForApproval: false,
    clockEntry: false,
    overviewCancel: false,
    todoCancel: false,
    todoDone: false,
    taskEdit: false,
    taskDelete: false,
    taskCopy: false,
    duplicateVisibility: false,
    duplicateWeekVisibility: false,
    onEdit: "None",
    duplicateTaskEnable: false,
    duplicateWeekEnable: true,
    editLongTextEnabled: false,
    feedListVisibility: false,
    firstDayOfWeek: 0,
    isGroup: false,
    startDate: selectedDates,
    createAssignment: false,
    copyAssignment: false,
    displayAssignment: false,
    displayAssignmentCancel: false,
    editAssignment: false,
    assignmentTitle: null,
    tasksActiveLength: null,
    tasksInactiveLength: null,
    clockTimeVisible: false,
    editTodoVisibility: true,
    numberOfRecords: 0,
    overviewEditEnabled: true,
    importAssignment: true,
    showFooterAssignment: false,
    importWorklist: false,
    approverAllowed: false,
    displayGroup: false,
    groupReload: false,
    createGroup: false,
    EditGroup: false,
    DeleteGroup: false,
    isOverviewChanged: false,
    isToDoChanged: false,
    overviewDataChanged: false,
    todoDataChanged: false,
    showOverviewMessage: true,
    showAssignmentsMessage: true,
    showGroupMessage: true,
    duplicateTaskButtonEnable: false,
    duplicateWeekButtonEnable: false
   });
   if (sap.ui.Device.system.phone === true) {
    controlModel.isGroup = true;
   }
   this.setModel(controlModel, "controls");
   this.calendar.addSelectedDate(selectedDates);
   // Handle validation
   sap.ui.getCore().attachParseError(controlErrorHandler);
   sap.ui.getCore().attachValidationSuccess(controlNoErrorHandler);
   sap.ui.getCore().getMessageManager().registerObject(this.getView(), true);
   this.filterAppliedFlag = "";
  },
  onCheckboxSelection: function (oEvent) {
   var that = this;
   var index = oEvent.getParameter('selectedItem').getBindingContext('TimeData').getPath().split("/")[1];
   this.getModel('TimeData').getData()[index].SetDraft = true;
   this.getModel('controls').setProperty('isOverviewChanged', true);
  },

  getTimeEntries: function (dateFrom, dateTo) {
   var that = this;
   var oModel = new sap.ui.model.json.JSONModel();
   // this.byId("idEventsTable").setBusy(true);
   var a = new sap.ui.model.Filter({
    path: "StartDate",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.oFormatYyyymmdd.format(dateFrom)
   });
   var b = new sap.ui.model.Filter({
    path: "EndDate",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.oFormatYyyymmdd.format(dateTo)
   });
   var c = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   var f = [];
   f.push(a);
   f.push(b);
   f.push(c);
   var mParameters = {
    filters: f, // your Filter Array
    urlParameters: '$expand=TimeEntries',
    success: function (oData, oResponse) {
     that.timeEntries = oData.results;
     that.minDate = oData.results[0].CaleNavMinDate;
     that.maxDate = oData.results[0].CaleNavMaxDate;
     oModel.setData(that.timeEntries);
     that.setModel(oModel, "TimeEntries");
     if (that.firstDayOfWeek == undefined) {
      that.firstDayOfWeek = formatter.dayOfWeek(that.timeEntries[0].FirstDayOfWeek);
      var curDate = new Date();
      var firstdate = that.byId('idCalendar').getStartDate();
      firstdate.setMonth(curDate.getMonth() - 1, 1);
      that.dateFrom = that.getFirstDayOfWeek(new Date(firstdate), that.firstDayOfWeek);
      curDate = new Date();
      curDate.setMonth(curDate.getMonth() + 3, 0);
      that.dateTo = curDate;
      that.calendar.destroySelectedDates();
      if (sap.ui.Device.system.phone === true) {
       var dateStartDate = that.getFirstDayOfWeek(new Date(), that.firstDayOfWeek);
       that.mCalendar.setStartDate(dateStartDate);
       that.startdate = new Date();
       that.enddate = new Date();
      } else {
       that.startdate = that.getFirstDayOfWeek(new Date(), that.firstDayOfWeek);
       that.enddate = that.getLastDayOfWeek(new Date(), that.firstDayOfWeek);
      }

     }
     that.bindTable(new Date(that.startdate), new Date(that.enddate));
     if (that.oReadOnlyTemplate) {
      that.rebindTableWithTemplate(that.oTable, "TimeData>/", that.oReadOnlyTemplate, "Navigation");
     }
     if (sap.ui.Device.system.phone === true) {
      var dateStartDate = that.getFirstDayOfWeek(that.startdate, that.firstDayOfWeek);
      that.mCalendar.setStartDate(dateStartDate);
      that.calendarSelection(that.mCalendar, that.startdate, that.enddate);
     } else {
      that.calendarSelection(that.calendar, that.startdate, that.enddate);
     }

     var missingDates = $.grep(that.timeEntries, function (element, index) {
      return element.Status == "MISSING";
     });
     var approvedDates = $.grep(that.timeEntries, function (element, index) {
      return element.Status == "DONE";
     });
     var rejectedDates = $.grep(that.timeEntries, function (element, index) {
      return element.Status == "REJECTED";
     });
     var sentDates = $.grep(that.timeEntries, function (element, index) {
      return element.Status == "FORAPPROVAL";
     });
     var draftDates = $.grep(that.timeEntries, function (element, index) {
      return element.Status == "DRAFT";
     });

     for (var i = 0; i < draftDates.length; i++) {
      if (sap.ui.Device.system.phone === true) {
       that.mCalendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(draftDates[i].CaleDate.substring(0, 4) + "-" + draftDates[i].CaleDate.substring(4, 6) + "-" +
         draftDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type01,
        tooltip: that.oBundle.getText("timeMissing")
       }));
      } else {
       that.calendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(draftDates[i].CaleDate.substring(0, 4) + "-" + draftDates[i].CaleDate.substring(4, 6) + "-" +
         draftDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type01,
        tooltip: that.oBundle.getText("timeMissing")
       }));
      }

     }
     if (sap.ui.Device.system.phone === true) {
      for (var i = 0; i < missingDates.length; i++) {
       that.mCalendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(missingDates[i].CaleDate.substring(0, 4) + "-" + missingDates[i].CaleDate.substring(4, 6) + "-" +
         missingDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type01,
        tooltip: that.oBundle.getText("timeMissing")
       }));
      }
     } else {
      for (var i = 0; i < missingDates.length; i++) {
       that.calendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(missingDates[i].CaleDate.substring(0, 4) + "-" + missingDates[i].CaleDate.substring(4, 6) + "-" +
         missingDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type01,
        tooltip: that.oBundle.getText("timeMissing")
       }));
      }
     }
     if (sap.ui.Device.system.phone === true) {
      for (var i = 0; i < sentDates.length; i++) {
       that.mCalendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(sentDates[i].CaleDate.substring(0, 4) + "-" + sentDates[i].CaleDate.substring(4, 6) + "-" +
         sentDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type01,
        tooltip: that.oBundle.getText("timeMissing")
       }));
      }
     } else {
      for (var i = 0; i < sentDates.length; i++) {
       that.calendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(sentDates[i].CaleDate.substring(0, 4) + "-" + sentDates[i].CaleDate.substring(4, 6) + "-" +
         sentDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type01,
        tooltip: that.oBundle.getText("timeMissing")
       }));
      }
     }
     if (sap.ui.Device.system.phone === true) {
      for (var i = 0; i < approvedDates.length; i++) {
       that.mCalendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(approvedDates[i].CaleDate.substring(0, 4) + "-" + approvedDates[i].CaleDate.substring(4, 6) + "-" +
         approvedDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type08,
        tooltip: that.oBundle.getText("timeCompleted")
       }));
      }
     } else {
      for (var i = 0; i < approvedDates.length; i++) {
       that.calendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(approvedDates[i].CaleDate.substring(0, 4) + "-" + approvedDates[i].CaleDate.substring(4, 6) + "-" +
         approvedDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type08,
        tooltip: that.oBundle.getText("timeCompleted")
       }));
      }
     }
     if (sap.ui.Device.system.phone === true) {
      for (var i = 0; i < rejectedDates.length; i++) {
       that.mCalendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(rejectedDates[i].CaleDate.substring(0, 4) + "-" + rejectedDates[i].CaleDate.substring(4, 6) + "-" +
         rejectedDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type03,
        tooltip: that.oBundle.getText("timeRejected")
       }));
      }
     } else {
      for (var i = 0; i < rejectedDates.length; i++) {
       that.calendar.addSpecialDate(new sap.ui.unified.DateTypeRange({
        startDate: new Date(rejectedDates[i].CaleDate.substring(0, 4) + "-" + rejectedDates[i].CaleDate.substring(4, 6) + "-" +
         rejectedDates[i].CaleDate.substring(6, 8)),
        type: sap.ui.unified.CalendarDayType.Type03,
        tooltip: that.oBundle.getText("timeRejected")
       }));
      }
     }
     that.calculateChangeCount();
     that.hideBusy(true);
    },
    error: function (oError) {
     that.hideBusy(true);
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/WorkCalendarCollection', mParameters);
  },
  initPersonalization: function () {
   var that = this;
   if (sap.ushell.Container) {
    var oPersonalizationService = sap.ushell.Container.getService("Personalization");
    var oPersonalizer = oPersonalizationService.getPersonalizer({
     container: "hcm.fab.mytimesheet", // This key must be globally unique (use a key to identify the app) -> only 40 characters are allowed
     item: "idOverviewTable" // Maximum of 40 characters applies to this key as well
    });
    var oTodoPersonalizer = oPersonalizationService.getPersonalizer({
     container: "hcm.fab.mytimesheet", // This key must be globally unique (use a key to identify the app) -> only 40 characters are allowed
     item: "idToDoList" // Maximum of 40 characters applies to this key as well
    });
    var oTaskPersonalizer = oPersonalizationService.getPersonalizer({
     container: "hcm.fab.mytimesheet", // This key must be globally unique (use a key to identify the app) -> only 40 characters are allowed
     item: "idTasks" // Maximum of 40 characters applies to this key as well
    });

    this.oTableTodoPersoController = new TablePersoController({
     table: this.oToDoTable,
     componentName: "MyTimesheet",
     persoService: oTodoPersonalizer
    }).activate();
    this.oTableTodoPersoController.getPersoService().getPersData().done(function (data) {
     if (data) {
      var startTime = $.grep(data.aColumns, function (element, ind) {
       return element.id.split('-')[element.id.split('-').length - 1] === "todoStartTime";
      });
      var endTime = $.grep(data.aColumns, function (element, ind) {
       return element.id.split('-')[element.id.split('-').length - 1] === "todoEndTime";
      });
      if (that.clockTimeVisible) {
       startTime[0].visible = true;
       endTime[0].visible = true;
      } else {
       startTime[0].visible = false;
       endTime[0].visible = false;
      }
      that.oTableTodoPersoController.getPersoService().setPersData(data).done(function () {

      });
     }

    });
    this.oTableTaskPersoController = new TablePersoController({
     table: this.oTaskTable,
     componentName: "MyTimesheet",
     persoService: oTaskPersonalizer
    }).activate();
    this.oTablePersoController = new TablePersoController({
     table: this.oTable,
     componentName: "MyTimesheet",
     persoService: oPersonalizer
    }).activate();
    if (sap.ui.Device.system.phone === true) {
     this.oTableTaskPersoController.getPersoService().getPersData().done(function (data) {
      if (data) {
       var columns = $.grep(data.aColumns, function (element, ind) {
        return (element.id.split('-')[element.id.split('-').length - 1] !== "AssignmentName") && (element.id.split('-')[element.id
         .split(
          '-').length - 1] !== "AssignmentStatus");
       });
       for (var i = 0; i < columns.length; i++) {
        columns[i].visible = false;
       }
       that.oTableTaskPersoController.getPersoService().setPersData(data).done(function () {

       });
      }

     });

    }
    this.oTablePersoController.getPersoService().getPersData().done(function (data) {
     if (data) {
      var startTime = $.grep(data.aColumns, function (element, ind) {
       return element.id.split('-')[element.id.split('-').length - 1] === "startTime";
      });
      var endTime = $.grep(data.aColumns, function (element, ind) {
       return element.id.split('-')[element.id.split('-').length - 1] === "endTime";
      });
      var draft = $.grep(data.aColumns, function (element, ind) {
       return element.id.split('-')[element.id.split('-').length - 1] === "draft";
      });
      var entered = $.grep(data.aColumns, function (element, ind) {
       return element.id.split('-')[element.id.split('-').length - 1] === "entered";
      });
      if (that.clockTimeVisible) {
       startTime[0].visible = true;
       endTime[0].visible = true;
      } else {
       startTime[0].visible = false;
       endTime[0].visible = false;
      }
      if (that.draftStatus) {
       draft[0].visible = true;
      } else {
       draft[0].visible = false;
      }
      if (sap.ui.Device.system.phone === true) {
       entered[0].visible = false;
      } else {
       entered[0].visible = true;
      }
      that.oTablePersoController.getPersoService().setPersData(data).done(function () {

      });
     }

    });
    // }
   }
  },
  onPersButtonPressed: function (oEvent) {
   this.oTablePersoController.openDialog();
  },
  onPersTodoButtonPressed: function (oEvent) {
   this.oTableTodoPersoController.openDialog();
  },
  onPersTaskButtonPressed: function (oEvent) {
   this.oTableTaskPersoController.openDialog();
  },
  getTasks: function (initLoad, startDate, endDate) {
   this.oTaskTable.setBusy(true);
   var that = this;
   var oModel = new sap.ui.model.json.JSONModel();
   var TaskModel = new sap.ui.model.json.JSONModel();
   var oControl;
   var obj;
   var TaskFields = [];
   var task = {};
   if (startDate === undefined && endDate === undefined) {
    startDate = new Date();
    endDate = new Date();
   }
   var assignment = {
    "AssignmentId": null,
    "AssignmentName": null
   };
   var groups = [];
   var a = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   var b = new sap.ui.model.Filter({
    path: "ValidityStartDate",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: startDate
   });
   var c = new sap.ui.model.Filter({
    path: "ValidityEndDate",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: endDate
   });
   var f = [];
   f.push(b);
   f.push(c);
   f.push(a);
   var mParameters = {
    filters: f,
    urlParameters: '$expand=ToGrps',
    success: function (oData, oResponse) {
     that.tasks = oData.results;
     for (var i = 0; i < that.tasks.length; i++) {
      that.tasks[i].ValidityStartDate = that.tasks[i].ValidityStartDate;
      that.tasks[i].ValidityEndDate = that.tasks[i].ValidityEndDate;
     }
     oModel.setData(that.tasks);
     if (that.tasks.length === 0 && initLoad) {
      that.noAssignmentsDialog();
     }
     oControl = that.getModel("controls");
     that.setModel(oModel, "Tasks");
     that.setGlobalModel(oModel, "Tasks");
     for (var j = 0; j < that.tasks.length; j++) {
      task["AssignmentName"] = that.tasks[j].AssignmentName;
      for (var k = 0; k < that.tasks[j].ToGrps.results.length; k++) {
       var groupObj = $.grep(groups, function (element, ind) {
        return element.groupId == that.tasks[j].ToGrps.results[k].GrpId;
       });
       if (groupObj.length > 0) {

        var AssignmentObj = $.grep(groupObj[0].Assignments, function (element, ind) {
         return element.AssignmentId == that.tasks[j].AssignmentId;
        });
        if (AssignmentObj.length == 0) {
         var assignment = {
          "AssignmentId": that.tasks[j].AssignmentId,
          "AssignmentName": that.tasks[j].AssignmentName,
          "ValidityStartDate": that.tasks[j].ValidityStartDate,
          "ValidityEndDate": that.tasks[j].ValidityEndDate,
          "Status": that.tasks[j].AssignmentStatus
         };
         groupObj[0].Assignments.push(assignment);
         groupObj[0].count = parseInt(groupObj[0].count) + 1;
        }

       } else if (that.tasks[j].ToGrps.results[k].GrpId && that.tasks[j].ToGrps.results[k].GrpId !== undefined && that.tasks[j].ToGrps
        .results[
         k].GrpId !== "") {
        var group = {
         "groupId": that.tasks[j].ToGrps.results[k].GrpId,
         "groupName": that.tasks[j].ToGrps.results[k].GrpName,
         "count": 1,
         "Assignments": [{
          "AssignmentId": that.tasks[j].AssignmentId,
          "AssignmentName": that.tasks[j].AssignmentName,
          "ValidityStartDate": that.tasks[j].ValidityStartDate,
          "ValidityEndDate": that.tasks[j].ValidityEndDate,
          "Status": that.tasks[j].AssignmentStatus
         }],
        };

        groups.push(group);
       }
      }

      for (var i = 0; i < that.profileFields.length; i++) {
       if (that.profileFields[i].FieldName === "APPROVER" || that.profileFields[i].FieldName === "AssignmentStatus" || that.profileFields[
         i].FieldName === "AssignmentName" || that.profileFields[i].FieldName === "ValidityStartDate" || that.profileFields[i].FieldName ===
        "ValidityEndDate") {
        if (that.profileFields[i].FieldName === "AssignmentStatus") {
         task[that.profileFields[i].FieldName] = that.tasks[j][that.profileFields[i].FieldName] === "1" ? true : false;
        } else if (that.profileFields[i].FieldName === "ValidityStartDate") {
         task[that.profileFields[i].FieldName] = that.formatter.dateStringFormat2(that.tasks[j][that.profileFields[i].FieldName]);
        } else if (that.profileFields[i].FieldName === "ValidityEndDate") {
         task[that.profileFields[i].FieldName] = that.formatter.dateStringFormat2(that.tasks[j][that.profileFields[i].FieldName]);
        } else if (that.profileFields[i].FieldName === "APPROVER") {
         task["APPROVER"] = that.tasks[j].ApproverId;
        } else {
         task[that.profileFields[i].FieldName] = that.tasks[j][that.profileFields[i].FieldName];
        }
       } else {
        task[that.profileFields[i].FieldName] = that.tasks[j].AssignmentFields[that.profileFields[i].FieldName];
        that.getFieldTexts(that.profileFields[i].FieldName);
       }

      }
      var finaltask = $.extend(true, {}, task);
      TaskFields.push(finaltask);
     }
     obj = $.grep(TaskFields, function (element, ind) {
      return element.AssignmentStatus === true;
     });
     oControl.setProperty('/tasksActiveLength', obj.length);
     obj = $.grep(TaskFields, function (element, ind) {
      return element.AssignmentStatus === false;
     });
     oControl.setProperty('/tasksInactiveLength', obj.length);
     oControl.setProperty('/taskEdit', false);
     oControl.setProperty('/taskDelete', false);
     oControl.setProperty('/taskCopy', false);
     TaskModel.setData(TaskFields);
     that.setModel(TaskModel, "TaskFields");
     that.setModel(new JSONModel(groups), "AssignmentGroups");
     var oTasksWithGroups = $.extend(true, [], groups);
     for (var i = 0; i < oTasksWithGroups.length; i++) {
      oTasksWithGroups[i].AssignmentName = oTasksWithGroups[i].groupName;
      oTasksWithGroups[i].AssignmentId = oTasksWithGroups[i].groupId;
      oTasksWithGroups[i].AssignmentType = that.oBundle.getText("group");
      oTasksWithGroups[i].Type = "group";
      oTasksWithGroups[i].AssignmentStatus = "1";
     }
     var oTasks = $.extend(true, [], that.tasks);
     for (var i = 0; i < oTasks.length; i++) {
      oTasks[i].AssignmentType = "";
     }
     // oTasksWithGroups.concat(oTasks);
     that.setModel(new JSONModel(oTasksWithGroups.concat(oTasks)), "TasksWithGroups");
     if (initLoad) {
      that.initPersonalization();
     }
     that.oTaskTable.setBusy(false);
    },
    error: function (oError) {
     that.oTaskTable.setBusy(false);
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/AssignmentCollection', mParameters);
  },
  getToDoList: function () {
   var that = this;
   this.oToDoTable.setBusy(true);
   var oModel = new sap.ui.model.json.JSONModel();
   var a = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   var f = [];
   f.push(a);
   var mParameters = {
    filters: f,
    urlParameters: '$expand=TimeEntries',
    success: function (oData, oResponse) {
     that.todolist = [];
     var recordTemplate = that.recordTemplate();
     for (var i = 0; i < oData.results.length; i++) {
      oData.results[i].CaleDate = new Date(oData.results[i].CaleDate.substring(0, 4) + "-" + oData.results[i].CaleDate.substring(4,
        6) + "-" +
       oData.results[i].CaleDate.substring(6, 8));
      oData.results[i].Status = that.oBundle.getText("timeMissing");
      var recordTemplate = that.recordTemplate();
      recordTemplate.AssignmentId = oData.results[i].AssignmentId;
      recordTemplate.AssignmentName = oData.results[i].AssignmentName;
      recordTemplate.Pernr = that.empID;
      recordTemplate.target = parseFloat(oData.results[i].TargetHours).toFixed(2);
      recordTemplate.missing = parseFloat(oData.results[i].MissingHours).toFixed(2);
      recordTemplate.currentMissing = recordTemplate.missing;
      recordTemplate.total = parseFloat(recordTemplate.target - recordTemplate.missing).toFixed(2);
      recordTemplate.sendButton = false;
      recordTemplate.addButton = true;
      recordTemplate.addButtonEnable = false;
      recordTemplate.deleteButtonEnable = false;
      recordTemplate.TimeEntryDataFields.WORKDATE = oData.results[i].CaleDate;
      if (oData.results[i].TimeEntries.results) {
       for (var j = 0; j < oData.results[i].TimeEntries.results.length; j++) {
        var rejectedRecord = oData.results[i].TimeEntries.results[j];
        rejectedRecord.missing = parseFloat(rejectedRecord.TimeEntryDataFields.CATSHOURS).toFixed(2);
        rejectedRecord.target = parseFloat(oData.results[i].TargetHours).toFixed(2);
        rejectedRecord.total = parseFloat(rejectedRecord.target - rejectedRecord.missing).toFixed(2);
        rejectedRecord.currentMissing = rejectedRecord.missing;
        rejectedRecord.sendButton = false;
        rejectedRecord.addButton = true;
        rejectedRecord.addButtonEnable = false;
        rejectedRecord.deleteButtonEnable = false;
        rejectedRecord.TimeEntryDataFields.CATSHOURS = parseFloat(rejectedRecord.TimeEntryDataFields.CATSHOURS).toFixed(2);
        that.todolist.push(rejectedRecord);
       }
      }
      if (oData.results[i].TimeEntries.results.length === 0) {
       that.todolist.push(recordTemplate);
      }

     }
     oModel.setData($.extend(true, [], that.todolist));
     oModel.attachPropertyChange(that.onToDoDataChanged.bind(that));
     that.setModel(oModel, "TodoList");
     that.setModel(new JSONModel($.extend(true, [], that.todolist)), "OriginalTodo");
     that.oToDoTable.setBusy(false);
    },
    error: function (oError) {
     that.oToDoTable.setBusy(false);
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/ActionItemCollection', mParameters);
  },
  onToDoDataChanged: function () {
   var that = this;
   var oControls = this.getModel("controls");
   oControls.setProperty('todoDataChanged', true);
  },
  getProfileFields: function (empId) {
   var that = this;
   var oModel = new sap.ui.model.json.JSONModel();
   var a = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   var f = [];
   f.push(a);
   var mParameters = {
    filters: f,
    urlParameters: '$expand=ProfileFields',
    success: function (oData, oResponse) {
     that.profileInfo = $.extend(true, [], oData.results[0]);
     var oControl = that.getModel("controls");
     oControl.setProperty('/submitDraft', oData.results[0].AllowRelease === "TRUE" ? false : true);
     oControl.setProperty('/clockTimeVisible', oData.results[0].AllowClockEntry === "TRUE" ? true : false);
     that.draftStatus = oData.results[0].AllowRelease === "TRUE" ? false : true;
     that.clockTimeVisible = oData.results[0].AllowClockEntry === "TRUE" ? true : false;
     that.profileFields = $.extend(true, [], oData.results[0].ProfileFields.results);
     var profileFields = $.extend(true, [], oData.results[0].ProfileFields.results);
     oControl.setProperty('/importWorklist', oData.results[0].DisplayWorklist === "TRUE" ? true : false);
     oControl.setProperty('/approverAllowed', oData.results[0].ApproverEntryAllowed === "TRUE" ? true : false);
     that.readOnlyTemplate();
     var AssignmentNameField = {
      "DefaultValue": "",
      "FieldLabel": that.oBundle.getText("name"),
      "FieldName": "AssignmentName",
      "FieldLength": "00064",
      "HasF4": "X",
      "IsReadOnly": "FALSE",
      "FieldType": "C",
      "Pernr": that.empID,
      "ProfileId": ""
     };
     profileFields.unshift(AssignmentNameField);
     if (oControl.getProperty('/approverAllowed')) {
      var AssignmentNameField = {
       "DefaultValue": "",
       "FieldLabel": that.oBundle.getText("approver"),
       "FieldName": "APPROVER",
       "FieldLength": "00008",
       "FieldType": "C",
       "HasF4": "",
       "IsReadOnly": "FALSE",
       "Pernr": that.empID,
       "ProfileId": ""
      };
      profileFields.push(AssignmentNameField);
     }
     var AssignmentNameField = {
      "DefaultValue": "",
      "FieldLabel": that.oBundle.getText("status"),
      "FieldName": "AssignmentStatus",
      "FieldLength": "00000",
      "HasF4": "",
      "IsReadOnly": "FALSE",
      "Pernr": that.empID,
      "ProfileId": "HR-ONLY",
      "Switch": "true"
     };
     profileFields.push(AssignmentNameField);
     var ValidFromField = {
      "DefaultValue": "",
      "FieldLabel": that.oBundle.getText("validFrom"),
      "FieldName": "ValidityStartDate",
      "HasF4": "X",
      "IsReadOnly": "FALSE",
      "Pernr": that.empID,
     };
     profileFields.push(ValidFromField);
     var ValidToField = {
      "DefaultValue": "",
      "FieldLabel": that.oBundle.getText("validTo"),
      "FieldName": "ValidityEndDate",
      "HasF4": "X",
      "IsReadOnly": "FALSE",
      "Pernr": that.empID,
     };
     profileFields.push(ValidToField);
     oModel.setData(profileFields);
     that.profileFields = profileFields;
     that.setModel(oModel, "ProfileFields");
     that.setGlobalModel(oModel, "ProfileFields");
     // var oColumn = new sap.ui.table.Column();
     //               that.oTaskTable.bindAggregartion("columns","/",oColumn);
    },
    error: function (oError) {
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/ProfileInfoCollection', mParameters);
  },
  longtextPopover: function (oEvent) {
   // create popover
   var that = this;
   var oDialogController = {
    handleClose: function (event) {
     var data = $.extend(true, [], this.getModel('oldModel').getData());
     var oModel = new JSONModel(data);
     this.setModel(oModel, 'TimeData');
     that.dialog.close();
     that.dialog.destroy();
    }.bind(this),
    onLongTextEdit: this.onTextEdit.bind(this),
    onLongTextDelete: this.onTextDelete.bind(this),
    onPost: this.onLongTextPost.bind(this),
    formatter: this.formatter.visibility.bind(this),
    formatText: function (oText) {
     return oText;
    },
    handleOk: function (oEvent) {
     that.getModel("controls").setProperty("/isOverviewChanged", true);
     that.getModel("controls").setProperty("/overviewDataChanged", true);
     that.dialog.close();
     that.dialog.destroy();
    }.bind(this)
   };
   var data = $.extend(true, [], this.getModel('TimeData').getData());
   var oModel = new JSONModel(data);
   this.setModel(oModel, "oldModel");
   // if (!this.dialog) {
   this.dialog = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.EditLongTextPopOver",
    oDialogController);
   this.getView().addDependent(this.dialog);
   this.dialog.bindElement('TimeData>' + oEvent.getSource().getBindingContext('TimeData').getPath());
   // this.dialog.bindElement('Edit>EditText');

   var index = oEvent.getSource().getBindingContext('TimeData').getPath().split('/')[1];
   var selectModel = new JSONModel(data);
   this.setModel(selectModel, "TimeEntry");
   // var data = $.extend(true, [], this.getModel('TimeData').getData());
   // var oModel = new JSONModel(data);
   // this.setModel(oModel, "oldModel");
   var oControl = this.getModel('controls');
   if (this.formatter.visibility(data[index].TimeEntryDataFields.LONGTEXT)) {
    // var oControl = this.getModel('controls');
    oControl.setProperty('editLongTextEnabled', false);
    oControl.setProperty('feedListVisibility', true);
   }
   this.setModel(oControl, "controls");
   var oButton = oEvent.getSource();
   jQuery.sap.delayedCall(0, this, function () {
    this.dialog.open(oButton);
   });
   // }

   // delay because addDependent will do a async rerendering and the popover will immediately close without it

  },

  onTextEdit: function (oEvent) {
   // var data = {
   //  EditText: oEvent.getSource().getParent().getParent().getAggregation('items')[0].getText()
   // };
   // var oModel = new JSONModel();
   // oModel.setData(data);
   // this.setModel(oModel, "Edit");
   if (oEvent.getSource().getParent().getParent().getAggregation('items')[0].getText()) {
    this.byId('feedInput').setValue(oEvent.getSource().getParent().getParent().getAggregation('items')[0].getText());
    this.byId('feedInput').setEnabled(true);
   }
  },
  onTextDelete: function (oEvent) {
   if (oEvent.getSource().getParent().getParent().getAggregation('items')[0].getText()) {
    var index = oEvent.getSource().getParent().getParent().getBindingContext('TimeData').getPath().split('/')[1];
    oEvent.getSource().getParent().getParent().getAggregation('items')[0].setText("");
    var okButton = oEvent.getSource().getParent().getParent().getParent().getAggregation('beginButton');
    var data = this.getModel('TimeData').getData();
    // data[index].TimeEntryDataFields.LTXA1 = oEvent.getParameter('value');
    data[index].TimeEntryDataFields.LONGTEXT_DATA = "";
    data[index].TimeEntryDataFields.LONGTEXT = '';
    if (data[index].Counter !== "") {
     data[index].TimeEntryOperation = 'U';
    } else {
     data[index].TimeEntryOperation = 'C';
    }
    var oModel = new JSONModel(data);
    this.setModel(oModel, "TimeData");
    okButton.setEnabled(true);
   }
  },
  getGroupHeader: function (oGroup, count) {
   // oGroup.key = this.getModel("i18n").getResourceBundle().getText('targetTotal', [formatter.dateStringFormat(oGroup.date), parseFloat(
   //   oGroup.target).toFixed(2),
   //  parseFloat(oGroup.sum).toFixed(2)
   // ]);
   // oGroup.key = formatter.dateStringFormat(oGroup.date);
   oGroup.key = this.oFormatDate.format(new Date(this.oFormatYyyymmdd.format(oGroup.date) + "T00:00:00"));
   return new GroupHeaderListItem({
    title: oGroup.key,
    upperCase: false
   });
  },
  onStatusChange: function (oEvent) {
   var selectedKey = oEvent.getParameter('selectedItem').getKey();
   var oFilter = [];
   var oControl = this.getModel("controls");
   if (selectedKey !== '100') {
    oFilter.push(new Filter("Status", FilterOperator.Contains, selectedKey));
   }

   var oRef = this.oTable.getBinding('items').filter(oFilter);
   if (oRef.getLength() === 0) {
    oControl.setProperty('/overviewEditEnabled', false);
    // this.setModel(oControl,"controls");
   } else {
    if (oControl.getProperty('/onEdit') === "None") {
     oControl.setProperty('/overviewEditEnabled', true);
    }
   }
  },
  handleDupTaskCalendarSelect: function (oEvent) {
   var oCalendar = oEvent.getSource();
   var aSelectedDates = oCalendar.getSelectedDates();
   var oDate;
   var oData = {
    selectedDates: []
   };
   var oModel = new JSONModel();
   if (aSelectedDates.length > 0) {
    for (var i = 0; i < aSelectedDates.length; i++) {
     oDate = aSelectedDates[i].getStartDate();
     oData.selectedDates.push({
      Date: oDate
     });
    }
    oModel.setData(oData);
    this.setModel(oModel, 'selectedDatesDup').updateBindings();
   } else {
    // this._clearModel();
   }
   if (this.getModel("TimeDataDuplicateTask").getData().length >= 1) {
    this.getModel("controls").setProperty("/duplicateTaskButtonEnable", true);
   }
  },
  EditTodoLongTextPopover: function (oEvent) {
   // create popover
   var that = this;
   var oDialogController = {
    handleClose: function (event) {
     that.dialog.close();
     that.dialog.destroy();
    },
    onLongTextEdit: this.onTextEdit.bind(this),
    onLongTextDelete: this.onTextDelete.bind(this),
    onPost: this.onTodoLongTextPost.bind(this),
    formatter: this.formatter.visibility.bind(this),
    handleOk: function (oEvent) {
     that.getModel("controls").setProperty("/isToDoChanged", true);
     that.getModel("controls").setProperty("/todoDataChanged", true);
     that.dialog.close();
     that.dialog.destroy();
    }.bind(this)
   };
   var data = $.extend(true, [], this.getModel('TodoList').getData());
   var oModel = new JSONModel(data);
   this.setModel(oModel, "oldModel");
   // if (!this.dialog) {
   this.dialog = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.EditToDoLongTextPopOver",
    oDialogController);
   this.getView().addDependent(this.dialog);
   this.dialog.bindElement('TodoList>' + oEvent.getSource().getBindingContext('TodoList').getPath());
   var index = oEvent.getSource().getBindingContext('TodoList').getPath().split('/')[1];
   var selectModel = new JSONModel(data);
   this.setModel(selectModel, "TimeEntry");
   // var data = $.extend(true, [], this.getModel('TimeData').getData());
   // var oModel = new JSONModel(data);
   // this.setModel(oModel, "oldModel");
   var oControl = this.getModel('controls');
   if (this.formatter.visibility(data[index].TimeEntryDataFields.LONGTEXT)) {
    // var oControl = this.getModel('controls');
    oControl.setProperty('editLongTextEnabled', false);
    oControl.setProperty('feedListVisibility', true);
   }
   this.setModel(oControl, "controls");
   var oButton = oEvent.getSource();
   jQuery.sap.delayedCall(0, this, function () {
    this.dialog.open(oButton);
   });
  },
  displaylongtextPopover: function (oEvent) {
   // create popover
   var that = this;
   var oDialogController = {
    handleClose: function (event) {
     that._oPopover.close();
    }
   };
   // if (!this._oPopover) {
   this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.LongTextPopOver",
    oDialogController);
   this.getView().addDependent(this._oPopover);
   this._oPopover.bindElement('TimeData>' + oEvent.getSource().getBindingContext('TimeData').getPath());
   // }

   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   var oButton = oEvent.getSource();
   jQuery.sap.delayedCall(0, this, function () {
    this._oPopover.openBy(oButton);
   });
  },

  displayTodoLongtextPopover: function (oEvent) {
   // create popover
   var that = this;
   // if (this._oPopover) {
   //  this._oPopover.close();
   // }
   var oDialogController = {
    handleClose: function (event) {
     that._oPopover.close();
    },
    onChange: this.onLongTextChange.bind(this)
   };
   // if (!this._oPopover) {
   this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.LongTextPopOver",
    oDialogController);
   this.getView().addDependent(this._oPopover);
   this._oPopover.bindElement('TodoList>' + oEvent.getSource().getBindingContext('TodoList').getPath());
   // }

   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   var oButton = oEvent.getSource();
   jQuery.sap.delayedCall(0, this, function () {
    this._oPopover.openBy(oButton);
   });
  },

  dynamicBindingRows: function (index, context) {
   var obj = context.getObject();
   if (this.getModel('Tasks').getData()) {

   } else {
    return;
   }
   var data = this.getModel('Tasks').getData();
   var index = context.getPath().split('/')[1];
   var row = new sap.m.ColumnListItem({
    type: "Navigation",
    press: this.onAssignmentPress.bind(this)
   });
   for (var k in obj) {
    if (k === "AssignmentStatus") {
     row.addCell(
      //  new sap.m.Switch({
      //  type: "AcceptReject",
      //  state: obj[k],
      //  enabled: false,
      //  customData: [new sap.ui.core.CustomData({
      //   "key": "FieldName",
      //   "value": k
      //  }), new sap.ui.core.CustomData({
      //   "key": "AssignmentId",
      //   "value": data[index].AssignmentId
      //  })]
      // })
      new sap.m.ObjectStatus({
       text: obj[k] === true ? this.oBundle.getText('activeStatus') : this.oBundle.getText('inactiveStatus'),
       state: obj[k] === true ? sap.ui.core.ValueState.Success : sap.ui.core.ValueState.Error,
       customData: [new sap.ui.core.CustomData({
         "key": "FieldName",
         "value": k
        }), new sap.ui.core.CustomData({
         "key": "AssignmentId",
         "value": data[index].AssignmentId
        }),
        new sap.ui.core.CustomData({
         "key": "FieldValue",
         "value": obj[k]
        })

       ]
      })
     );
    } else if (k === "ValidityStartDate" || k === "ValidityEndDate") {
     row.addCell(new sap.m.Text({
      text: this.oFormatDate.format(new Date(obj[k])),
      customData: [new sap.ui.core.CustomData({
       "key": "FieldName",
       "value": k
      }), new sap.ui.core.CustomData({
       "key": "AssignmentId",
       "value": data[index].AssignmentId
      })]
     }));
    } else if (k === "PEDD") {
     if (obj[k]) {
      row.addCell(new sap.m.Text({
       text: this.oFormatDate.format(obj[k]),
       customData: [new sap.ui.core.CustomData({
        "key": "FieldName",
        "value": k
       }), new sap.ui.core.CustomData({
        "key": "AssignmentId",
        "value": data[index].AssignmentId
       })]
      }));
     } else {
      row.addCell(new sap.m.Text({
       text: "",
       customData: [new sap.ui.core.CustomData({
        "key": "FieldName",
        "value": k
       }), new sap.ui.core.CustomData({
        "key": "AssignmentId",
        "value": data[index].AssignmentId
       })]
      }));
     }

    }
    // else if (k === "APPROVER") {
    //  row.addCell(new sap.m.Text({
    //   text: obj[k].ApproverName,
    //   customData: [new sap.ui.core.CustomData({
    //    "key": "FieldName",
    //    "value": k
    //   }), new sap.ui.core.CustomData({
    //    "key": "AssignmentId",
    //    "value": data[index].AssignmentId
    //   })]
    //  }));
    // } 
    else {
     var oModel = this.getModel(k);
     if (oModel) {
      var text = oModel.getData();
      if (text) {
       var textFound = $.grep(text, function (element, index) {
        return element.DispField1Id === obj[k];
       });
       if (textFound.length > 0) {
        row.addCell(new sap.m.Text({
         text: textFound[0].DispField1Val,
         customData: [new sap.ui.core.CustomData({
          "key": "FieldName",
          "value": k
         }), new sap.ui.core.CustomData({
          "key": "AssignmentId",
          "value": data[index].AssignmentId
         })]
        }));
       } else {
        row.addCell(new sap.m.Text({
         text: obj[k],
         customData: [new sap.ui.core.CustomData({
          "key": "FieldName",
          "value": k
         }), new sap.ui.core.CustomData({
          "key": "AssignmentId",
          "value": data[index].AssignmentId
         })]
        }));
       }
      } else {
       row.addCell(new sap.m.Text({
        text: obj[k],
        customData: [new sap.ui.core.CustomData({
         "key": "FieldName",
         "value": k
        }), new sap.ui.core.CustomData({
         "key": "AssignmentId",
         "value": data[index].AssignmentId
        })]
       }));
      }
     } else {
      row.addCell(new sap.m.Text({
       text: obj[k],
       customData: [new sap.ui.core.CustomData({
        "key": "FieldName",
        "value": k
       }), new sap.ui.core.CustomData({
        "key": "AssignmentId",
        "value": data[index].AssignmentId
       })]
      }));
     }
     // row.addCell(new sap.m.Text({
     //  text: obj[k],
     //  customData: [new sap.ui.core.CustomData({
     //   "key": "FieldName",
     //   "value": k
     //  }), new sap.ui.core.CustomData({
     //   "key": "AssignmentId",
     //   "value": data[index].AssignmentId
     //  })]
     // }));
    }
   }

   return row;
  },
  dynamicBindingRowsWorklist: function (index, context) {
   //Need to handle date range
   var obj = context.getObject();
   // var data = this.getModel('Worklist').getData();
   var index = context.getPath().split('/')[1];
   var row = new sap.m.ColumnListItem({
    // type: "Navigation",
    // press: this.onAssignmentWorklistPress.bind(this)
   });
   for (var k in obj) {
    if (k === "RANGE") {
     row.addCell(new sap.m.DateRangeSelection({
      dateValue: new Date(new Date().getFullYear(), 0, 1),
      secondDateValue: new Date(new Date().getFullYear(), 11, 31),
      maxLength: 30,
      // change: this.handleChange().bind(this),
      customData: [new sap.ui.core.CustomData({
       "key": "FieldName",
       "value": "RANGE"
      }), new sap.ui.core.CustomData({
       "key": "Index",
       "value": index
      })]
     }));

    } else if (k === "NAME") {
     row.addCell(new sap.m.Input({
      type: sap.m.InputType.Text,
      value: obj[k],
      required: true,
      // liveChange: this.handleUserInput().bind(this),
      maxLength: 30,
      placeholder: this.getResourceBundle().getText("worklistNamePlaceholder"),
      customData: [new sap.ui.core.CustomData({
       "key": "FieldName",
       "value": "NAME"
      }), new sap.ui.core.CustomData({
       "key": "Index",
       "value": index
      })]
     }));

    } else {
     row.addCell(new sap.m.Text({
      text: obj[k],
      customData: [new sap.ui.core.CustomData({
       "key": "FieldName",
       "value": k
      }), new sap.ui.core.CustomData({
       "key": "Index",
       "value": index
      })]
     }));
    }
   }

   return row;
  },
  dynamicBindingRowsAdminlist: function (index, context) {
   var obj = context.getObject();
   if (this.getModel('AdminTasks').getData()) {

   } else {
    return;
   }
   var data = this.getModel('AdminTasks').getData();
   var index = context.getPath().split('/')[1];
   var row = new sap.m.ColumnListItem({
    // type: "Navigation",
    // press: this.onAssignmentPress.bind(this)
   });
   for (var k in obj) {
    if (k === "AssignmentStatus") {
     row.addCell(
      new sap.m.ObjectStatus({
       text: obj[k] === true ? this.oBundle.getText('activeStatus') : this.oBundle.getText('inactiveStatus'),
       state: obj[k] === true ? sap.ui.core.ValueState.Success : sap.ui.core.ValueState.Error,
       customData: [new sap.ui.core.CustomData({
         "key": "FieldName",
         "value": k
        }), new sap.ui.core.CustomData({
         "key": "AssignmentId",
         "value": data[index].AssignmentId
        }),
        new sap.ui.core.CustomData({
         "key": "FieldValue",
         "value": obj[k]
        })

       ]
      })
     );
    } else {
     var oModel = this.getModel(k);
     if (oModel) {
      var text = oModel.getData();
      if (text) {
       var textFound = $.grep(text, function (element, index) {
        return element.DispField1Id === obj[k];
       });
       if (textFound.length > 0) {
        row.addCell(new sap.m.Text({
         text: textFound[0].DispField1Val,
         customData: [new sap.ui.core.CustomData({
          "key": "FieldName",
          "value": k
         }), new sap.ui.core.CustomData({
          "key": "AssignmentId",
          "value": data[index].AssignmentId
         }), new sap.ui.core.CustomData({
          "key": "FieldCode",
          "value": obj[k]
         })]
        }));
       } else {
        row.addCell(new sap.m.Text({
         text: obj[k],
         customData: [new sap.ui.core.CustomData({
          "key": "FieldName",
          "value": k
         }), new sap.ui.core.CustomData({
          "key": "AssignmentId",
          "value": data[index].AssignmentId
         })]
        }));
       }
      } else {
       row.addCell(new sap.m.Text({
        text: obj[k],
        customData: [new sap.ui.core.CustomData({
         "key": "FieldName",
         "value": k
        }), new sap.ui.core.CustomData({
         "key": "AssignmentId",
         "value": data[index].AssignmentId
        })]
       }));
      }
     } else {
      row.addCell(new sap.m.Text({
       text: obj[k],
       customData: [new sap.ui.core.CustomData({
        "key": "FieldName",
        "value": k
       }), new sap.ui.core.CustomData({
        "key": "AssignmentId",
        "value": data[index].AssignmentId
       })]
      }));
     }
    }
   }

   return row;
  },
  dynamicBindingColumns: function (index, context) {
   var obj = context.getObject();
   var data = this.getModel('ProfileFields').getData();
   var index = context.getPath().split('/')[1];
   var column;
   if (sap.ui.Device.system.phone === true) {
    if (data[index].FieldName === "AssignmentStatus") {
     column = new sap.m.Column(data[index].FieldName, {
      // text: data[index].FieldName,
      demandPopin: true,
      hAlign: 'End'
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else if (data[index].FieldName === "AssignmentName") {
     column = new sap.m.Column(data[index].FieldName, {
      // text: data[index].FieldName,
      demandPopin: true,
      hAlign: 'Begin'
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else if (data[index].FieldName === "ValidityStartDate") {
     column = new sap.m.Column(data[index].FieldName, {
      // text: data[index].FieldName,
      demandPopin: true,
      hAlign: 'End',
      visible: false,
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else if (data[index].FieldName === "ValidityEndDate") {
     column = new sap.m.Column(data[index].FieldName, {
      // text: data[index].FieldName,
      demandPopin: true,
      hAlign: 'End',
      visible: false,
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else {
     column = new sap.m.Column(data[index].FieldName, {
      // text: data[index].FieldName,
      minScreenWidth: sap.m.ScreenSize.Small,
      demandPopin: true,
      hAlign: 'Begin',
      visible: false
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    }

   } else {
    if (index > 5 && data[index].FieldName !== "AssignmentName" && data[index].FieldName !== "AssignmentStatus" && data[index].FieldName !==
     "APPROVER" && data[index].FieldName !== "ValidityStartDate" && data[index].FieldName !== "ValidityEndDate") {
     column = new sap.m.Column(data[index].FieldName, {
      // text: data[index].FieldName,
      minScreenWidth: "2800px",
      demandPopin: true,
      // popinDisplay: "Inline"
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else {
     if (data[index].FieldName !== "ValidityStartDate" && data[index].FieldName !== "ValidityEndDate") {
      column = new sap.m.Column(data[index].FieldName, {
       // text: data[index].FieldName,
       minScreenWidth: "Tablet",
       demandPopin: true,
       // popinDisplay: "Inline"
      }).setHeader(new sap.m.Text({
       text: data[index].FieldLabel
      }));
     } else {
      column = new sap.m.Column(data[index].FieldName, {
       // text: data[index].FieldName,
       minScreenWidth: "Tablet",
       demandPopin: true,
       hAlign: 'End',
       // popinDisplay: "Inline"
      }).setHeader(new sap.m.Text({
       text: data[index].FieldLabel
      }));
     }

    }

   }

   return column;
  },
  dynamicBindingColumnsWorklist: function (index, context) {
   var obj = context.getObject();
   var data = this.getModel('WorklistProfileFields').getData();
   var index = context.getPath().split('/')[1];
   if (sap.ui.Device.system.phone === true) {
    var column = new sap.m.Column({
     minScreenWidth: "2800px",
     demandPopin: true
    }).setHeader(new sap.m.Text({
     text: data[index].FieldLabel
    }));
    return column;
   } else {
    if (index > 5) {
     var column = new sap.m.Column({
      minScreenWidth: "2800px",
      demandPopin: true
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else {
     var column = new sap.m.Column({
      minScreenWidth: "Tablet",
      demandPopin: true
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    }

    return column;
   }

  },
  dynamicBindingColumnsAdminlist: function (index, context) {
   var obj = context.getObject();
   var data = this.getModel('ProfileFields').getData();
   var index = context.getPath().split('/')[1];
   var column;
   if (sap.ui.Device.system.phone === true) {
    if (data[index].FieldName === "AssignmentStatus") {
     column = new sap.m.Column("Admin" + data[index].FieldName, {
      // text: data[index].FieldName,
      demandPopin: true,
      hAlign: 'End'
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else if (data[index].FieldName === "AssignmentName") {
     column = new sap.m.Column("Admin" + data[index].FieldName, {
      // text: data[index].FieldName,
      demandPopin: true,
      hAlign: 'Begin'
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else if (data[index].FieldName === "ValidityStartDate") {
     column = new sap.m.Column("Admin" + data[index].FieldName, {
      // text: data[index].FieldName,
      demandPopin: true,
      hAlign: 'End',
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else if (data[index].FieldName === "ValidityEndDate") {
     column = new sap.m.Column("Admin" + data[index].FieldName, {
      // text: data[index].FieldName,
      demandPopin: true,
      hAlign: 'End',
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else {
     column = new sap.m.Column("Admin" + data[index].FieldName, {
      // text: data[index].FieldName,
      minScreenWidth: sap.m.ScreenSize.Small,
      demandPopin: true,
      hAlign: 'Begin',
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    }

   } else {
    if (index > 5 && data[index].FieldName !== "AssignmentName" && data[index].FieldName !== "AssignmentStatus" && data[index].FieldName !==
     "APPROVER" && data[index].FieldName !== "ValidityStartDate" && data[index].FieldName !== "ValidityEndDate") {
     column = new sap.m.Column("Admin" + data[index].FieldName, {
      // text: data[index].FieldName,
      minScreenWidth: "2800px",
      demandPopin: true,
      // popinDisplay: "Inline"
     }).setHeader(new sap.m.Text({
      text: data[index].FieldLabel
     }));
    } else {
     if (data[index].FieldName !== "ValidityStartDate" && data[index].FieldName !== "ValidityEndDate") {
      column = new sap.m.Column("Admin" + data[index].FieldName, {
       // text: data[index].FieldName,
       minScreenWidth: "Tablet",
       demandPopin: true,
       // popinDisplay: "Inline"
      }).setHeader(new sap.m.Text({
       text: data[index].FieldLabel
      }));
     } else {
      column = new sap.m.Column("Admin" + data[index].FieldName, {
       // text: data[index].FieldName,
       minScreenWidth: "Tablet",
       demandPopin: true,
       hAlign: 'End',
       // popinDisplay: "Inline"
      }).setHeader(new sap.m.Text({
       text: data[index].FieldLabel
      }));
     }

    }

   }

   return column;
  },
  performImportAssignments: function (selectedItems) {
   var that = this;
   this.showBusy();
   that.oDataImportAssignmentsModel = this.getOwnerComponent().getModel();
   that.oDataImportAssignmentsModel.resetChanges();
   that.oDataImportAssignmentsModel.setChangeBatchGroups({
    "*": {
     groupId: "ImportAssignments",
     changeSetId: "ImportAssignments",
     single: false
    }
   });
   that.oDataImportAssignmentsModel.setDeferredGroups(["ImportAssignments"]);
   that.oDataImportAssignmentsModel
    .refreshSecurityToken(
     function (oData) {
      if (selectedItems.length > 0) {
       for (var j = 0; j < selectedItems.length; j++) {
        var obj = {
         properties: {
          ApproverId: selectedItems[j].ApproverId,
          ApproverName: selectedItems[j].ApproverName,
          AssignmentId: selectedItems[j].AssignmentId,
          AssignmentName: selectedItems[j].AssignmentName,
          AssignmentOperation: selectedItems[j].AssignmentOperation,
          AssignmentStatus: selectedItems[j].AssignmentStatus,
          Counter: selectedItems[j].Counter,
          Pernr: selectedItems[j].Pernr,
          ProfileId: selectedItems[j].ProfileId,
          ValidityStartDate: selectedItems[j].ValidityStartDate,
          ValidityEndDate: selectedItems[j].ValidityEndDate,
          AssignmentFields: {
           AENAM: selectedItems[j].AssignmentFields.AENAM,
           ALLDF: selectedItems[j].AssignmentFields.ALLDF,
           APDAT: selectedItems[j].AssignmentFields.APDAT,
           APNAM: selectedItems[j].AssignmentFields.APNAM,
           ARBID: selectedItems[j].AssignmentFields.ARBID,
           ARBPL: selectedItems[j].AssignmentFields.ARBPL,
           AUERU: selectedItems[j].AssignmentFields.AUERU,
           AUFKZ: selectedItems[j].AssignmentFields.AUFKZ,
           AUTYP: selectedItems[j].AssignmentFields.AUTYP,
           AWART: selectedItems[j].AssignmentFields.AWART,
           BEGUZ: selectedItems[j].AssignmentFields.BEGUZ,
           BELNR: selectedItems[j].AssignmentFields.BELNR,
           BEMOT: selectedItems[j].AssignmentFields.BEMOT,
           BUDGET_PD: selectedItems[j].AssignmentFields.BUDGET_PD,
           BUKRS: selectedItems[j].AssignmentFields.BUKRS,
           BWGRL: selectedItems[j].AssignmentFields.BWGRL,
           CATSAMOUNT: selectedItems[j].AssignmentFields.CATSAMOUNT,
           CATSHOURS: selectedItems[j].AssignmentFields.CATSHOURS,
           CATSQUANTITY: selectedItems[j].AssignmentFields.CATSQUANTITY,
           CPR_EXTID: selectedItems[j].AssignmentFields.CPR_EXTID,
           CPR_GUID: selectedItems[j].AssignmentFields.CPR_GUID,
           CPR_OBJGEXTID: selectedItems[j].AssignmentFields.CPR_OBJGEXTID,
           CPR_OBJGUID: selectedItems[j].AssignmentFields.CPR_OBJGUID,
           CPR_OBJTYPE: selectedItems[j].AssignmentFields.CPR_OBJTYPE,
           ENDUZ: selectedItems[j].AssignmentFields.ENDUZ,
           ERNAM: selectedItems[j].AssignmentFields.ERNAM,
           ERSDA: selectedItems[j].AssignmentFields.ERSDA,
           ERSTM: selectedItems[j].AssignmentFields.ERSTM,
           ERUZU: selectedItems[j].AssignmentFields.ERUZU,
           EXTAPPLICATION: selectedItems[j].AssignmentFields.EXTAPPLICATION,
           EXTDOCUMENTNO: selectedItems[j].AssignmentFields.EXTDOCUMENTNO,
           EXTSYSTEM: selectedItems[j].AssignmentFields.EXTSYSTEM,
           FUNC_AREA: selectedItems[j].AssignmentFields.FUNC_AREA,
           FUND: selectedItems[j].AssignmentFields.FUND,
           GRANT_NBR: selectedItems[j].AssignmentFields.GRANT_NBR,
           HRBUDGET_PD: selectedItems[j].AssignmentFields.HRBUDGET_PD,
           HRCOSTASG: selectedItems[j].AssignmentFields.HRCOSTASG,
           HRFUNC_AREA: selectedItems[j].AssignmentFields.HRFUNC_AREA,
           HRFUND: selectedItems[j].AssignmentFields.HRFUND,
           HRGRANT_NBR: selectedItems[j].AssignmentFields.HRGRANT_NBR,
           HRKOSTL: selectedItems[j].AssignmentFields.HRKOSTL,
           HRLSTAR: selectedItems[j].AssignmentFields.HRLSTAR,
           KAPAR: selectedItems[j].AssignmentFields.KAPAR,
           KAPID: selectedItems[j].AssignmentFields.KAPID,
           KOKRS: selectedItems[j].AssignmentFields.KOKRS,
           LAEDA: selectedItems[j].AssignmentFields.LAEDA,
           LAETM: selectedItems[j].AssignmentFields.LAETM,
           LGART: selectedItems[j].AssignmentFields.LGART,
           LOGSYS: selectedItems[j].AssignmentFields.LOGSYS,
           LONGTEXT: selectedItems[j].AssignmentFields.LONGTEXT,
           LONGTEXT_DATA: selectedItems[j].AssignmentFields.LONGTEXT_DATA,
           LSTAR: selectedItems[j].AssignmentFields.LSTAR,
           LSTNR: selectedItems[j].AssignmentFields.LSTNR,
           LTXA1: selectedItems[j].AssignmentFields.LTXA1,
           MEINH: selectedItems[j].AssignmentFields.MEINH,
           OFMNW: selectedItems[j].AssignmentFields.OFMNW,
           OTYPE: selectedItems[j].AssignmentFields.OTYPE,
           PAOBJNR: selectedItems[j].AssignmentFields.PAOBJNR,
           PEDD: selectedItems[j].AssignmentFields.PEDD,
           PERNR: selectedItems[j].AssignmentFields.PERNR,
           PLANS: selectedItems[j].AssignmentFields.PLANS,
           POSID: selectedItems[j].AssignmentFields.POSID,
           PRAKN: selectedItems[j].AssignmentFields.PRAKN,
           PRAKZ: selectedItems[j].AssignmentFields.PRAKZ,
           PRICE: selectedItems[j].AssignmentFields.PRICE,
           RAPLZL: selectedItems[j].AssignmentFields.RAPLZL,
           RAUFNR: selectedItems[j].AssignmentFields.RAUFNR,
           RAUFPL: selectedItems[j].AssignmentFields.RAUFPL,
           REASON: selectedItems[j].AssignmentFields.REASON,
           REFCOUNTER: selectedItems[j].AssignmentFields.REFCOUNTER,
           REINR: selectedItems[j].AssignmentFields.REINR,
           RKDAUF: selectedItems[j].AssignmentFields.RKDAUF,
           RKDPOS: selectedItems[j].AssignmentFields.RKDPOS,
           RKOSTL: selectedItems[j].AssignmentFields.RKOSTL,
           RKSTR: selectedItems[j].AssignmentFields.RKSTR,
           RNPLNR: selectedItems[j].AssignmentFields.RNPLNR,
           RPROJ: selectedItems[j].AssignmentFields.RPROJ,
           RPRZNR: selectedItems[j].AssignmentFields.RPRZNR,
           SBUDGET_PD: selectedItems[j].AssignmentFields.SBUDGET_PD,
           SEBELN: selectedItems[j].AssignmentFields.SEBELN,
           SEBELP: selectedItems[j].AssignmentFields.SEBELP,
           SKOSTL: selectedItems[j].AssignmentFields.SKOSTL,
           SPLIT: selectedItems[j].AssignmentFields.SPLIT,
           SPRZNR: selectedItems[j].AssignmentFields.SPRZNR,
           STATKEYFIG: selectedItems[j].AssignmentFields.STATKEYFIG,
           STATUS: selectedItems[j].AssignmentFields.STATUS,
           S_FUNC_AREA: selectedItems[j].AssignmentFields.S_FUNC_AREA,
           S_FUND: selectedItems[j].AssignmentFields.S_FUND,
           S_GRANT_NBR: selectedItems[j].AssignmentFields.S_GRANT_NBR,
           TASKCOMPONENT: selectedItems[j].AssignmentFields.TASKCOMPONENT,
           TASKCOUNTER: selectedItems[j].AssignmentFields.TASKCOUNTER,
           TASKLEVEL: selectedItems[j].AssignmentFields.TASKLEVEL,
           TASKTYPE: selectedItems[j].AssignmentFields.TASKTYPE,
           TCURR: selectedItems[j].AssignmentFields.TCURR,
           TRFGR: selectedItems[j].AssignmentFields.TRFGR,
           TRFST: selectedItems[j].AssignmentFields.TRFST,
           UNIT: selectedItems[j].AssignmentFields.UNIT,
           UVORN: selectedItems[j].AssignmentFields.UVORN,
           VERSL: selectedItems[j].AssignmentFields.VERSL,
           VORNR: selectedItems[j].AssignmentFields.VORNR,
           VTKEN: selectedItems[j].AssignmentFields.VTKEN,
           WABLNR: selectedItems[j].AssignmentFields.WABLNR,
           WAERS: selectedItems[j].AssignmentFields.WAERS,
           WERKS: selectedItems[j].AssignmentFields.WERKS,
           WORKDATE: selectedItems[j].AssignmentFields.WORKDATE,
           WORKITEMID: selectedItems[j].AssignmentFields.WORKITEMID,
           WTART: selectedItems[j].AssignmentFields.WTART
          }
         },
         success: function (oDataReturn) {
          if (j == selectedItems.length) {
           that.getTasks(false);
           that.hideBusy();
           var toastMsg = that.oBundle.getText("assignmentsImported");
           sap.m.MessageToast.show(toastMsg, {
            duration: 3000
           });
          }
         },
         error: function (oError) {
          that.hideBusy();
          that.oErrorHandler.processError(oError);
         },
         changeSetId: "ImportAssignments",
         groupId: "ImportAssignments"
        };
        that.oDataImportAssignmentsModel
         .createEntry(
          "/AssignmentCollection",
          obj);
       }
      }
      that.oDataImportAssignmentsModel.submitChanges({
       groupId: "ImportAssignments",
       changeSetId: "ImportAssignments"
      });
     }, true);
  },

  /* =========================================================== */
  /* event handlers                                              */
  /* =========================================================== */

  /**
   * Triggered by the table's 'updateFinished' event: after new table
   * data is available, this handler method updates the table counter.
   * This should only happen if the update was successful, which is
   * why this handler is attached to 'updateFinished' and not to the
   * table's list binding's 'dataReceived' method.
   * @param {sap.ui.base.Event} oEvent the update finished event
   * @public
   */
  onUpdateFinished: function (oEvent) {
   // update the worklist's object counter after the table update
   // var sTitle,
   //  oTable = oEvent.getSource(),
   //  iTotalItems = oEvent.getParameter("total");
   // // only update the counter if the length is final and
   // // the table is not empty
   // if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
   //  sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
   // } else {
   //  sTitle = this.getResourceBundle().getText("worklistTableTitle");
   // }
   // this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
  },

  /**
   * Event handler when a table item gets pressed
   * @param {sap.ui.base.Event} oEvent the table selectionChange event
   * @public
   */
  onPress: function (oEvent) {
   // The source is the list item that got pressed
   // this._showObject(oEvent.getSource());
  },

  onLongTextPost: function (oEvent) {
   var index = oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1];
   var okButton = oEvent.getSource().getParent().getAggregation('beginButton');
   var data = this.getModel('TimeData').getData();
   if (oEvent.getParameter('value')) {
    // data[index].TimeEntryDataFields.LTXA1 = oEvent.getParameter('value');
    data[index].TimeEntryDataFields.LONGTEXT_DATA = oEvent.getParameter('value');
    data[index].TimeEntryDataFields.LONGTEXT = 'X';
    if (data[index].Counter !== "") {
     data[index].TimeEntryOperation = 'U';
    } else {
     data[index].TimeEntryOperation = 'C';
    }
    var oModel = new JSONModel(data);
    this.setModel(oModel, "TimeData");
    okButton.setEnabled(true);
   }
  },

  onTodoLongTextPost: function (oEvent) {
   var index = oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1];
   var okButton = oEvent.getSource().getParent().getAggregation('beginButton');
   var data = this.getModel('TodoList').getData();
   if (oEvent.getParameter('value')) {
    data[index].TimeEntryDataFields.LTXA1 = oEvent.getParameter('value');
    data[index].TimeEntryDataFields.LONGTEXT = 'X';
    if (data[index].Counter !== "") {
     data[index].TimeEntryOperation = 'U';
    } else {
     data[index].TimeEntryOperation = 'C';
    }
    data[index].TimeEntryDataFields.LONGTEXT_DATA = oEvent.getParameter('value');
    var oModel = new JSONModel(data);
    this.setModel(oModel, "TodoList");
    okButton.setEnabled(true);
   }
  },

  handleMessagePopover: function (oEvent) {
   var oMessageTemplate = new MessagePopoverItem({
    type: '{message>severity}',
    description: "{message>description}",
    title: '{message>message}',
    link: new sap.m.Link({
     text: this.oBundle.getText("clickHere"),
     press: this.onClickFocusError.bind(this),
     visible: "{=${message>code} === undefined ? false : true}",
     customData: [new sap.ui.core.CustomData({
      key: "counter",
      value: "{message>additionalText}"
     }), new sap.ui.core.CustomData({
      key: "code",
      value: "{message>code}"
     })]
    })
   });
   // if (!this.oMessagePopover) {
   var oMessagePopover = new MessagePopover({
    items: {
     path: "message>/",
     template: oMessageTemplate
    }
   });
   this.oMessagePopover = oMessagePopover;
   this.oMessagePopover.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");

   // }
   this.oMessagePopover.toggle(oEvent.getSource());
   // this.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");

  },
  onClickFocusError: function (oEvent) {
   var that = this;
   var oRecRowNo = oEvent.getSource().getCustomData("counter")[0].getValue();
   var dataModel = oEvent.getSource().getCustomData("code")[1].getValue();
   var oEntries = this.getModel(dataModel).getData();
   var highlightedRecords = $.grep(oEntries, function (element, ind) {
    if (element.valueState) {
     return element.valueState === "Error";
    }
   });
   for (var i = 0; i < highlightedRecords.length; i++) {
    highlightedRecords[i].valueState = "None";
   }
   this.getModel('TimeData').updateBindings();
   var entry = $.grep(oEntries, function (element, ind) {
    if (element.RecRowNo) {
     return element.RecRowNo === parseInt(oRecRowNo).toString();
    }
   });
   if (entry.length > 0) {
    entry[0].valueState = "Error";
   }
   this.getModel('TimeData').updateBindings();
   this.oMessagePopover.close();
  },

  handleCalendarSelect: function (oEvent) {
   var oControl = this.getModel('controls');
   if (sap.ui.Device.system.phone === true) {
    var oCalendar = oEvent.getSource();
    var aSelectedDates = oCalendar.getSelectedDates();
    this.mCalendar.destroySelectedDates();
    this.startdate = aSelectedDates[0].getStartDate();
    this.enddate = aSelectedDates[0].getStartDate();
    this.calendarSelection(oCalendar, new Date(this.startdate), new Date(this.enddate));
    this.bindTable(new Date(this.startdate), new Date(this.enddate));
    if (this.oReadOnlyTemplate) {
     this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
    }
   } else {
    var oCalendar = oEvent.getSource();
    var aSelectedDates = oCalendar.getSelectedDates();
    this.calendar.destroySelectedDates();
    this.startdate = this.getFirstDayOfWeek(aSelectedDates[0].getStartDate(), this.firstDayOfWeek);
    this.enddate = this.getLastDayOfWeek(aSelectedDates[0].getStartDate(), this.firstDayOfWeek);
    this.calendarSelection(oCalendar, new Date(this.startdate), new Date(this.enddate));
    var startdate = new Date(this.startdate);
    var enddate = new Date(this.enddate);
    this.bindTable(new Date(this.startdate), new Date(this.enddate));
    if (this.oReadOnlyTemplate) {
     this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
    }

   }
   // oControl.setProperty('/overviewCancel', false);
   // oControl.setProperty('/sendForApproval', false);
   // oControl.setProperty('/submitDraft', false);
   // oControl.setProperty('/todoDone', false);
   // oControl.setProperty('/todoCancel', false);
   oControl.setProperty('/onEdit', "None");
   // oControl.setProperty('/submitDraft', false);
   oControl.setProperty('/duplicateVisibility', false);
   oControl.setProperty('/duplicateWeekVisibility', false);
   oControl.setProperty('/overviewEdit', true);
   oControl.setProperty('/showFooter', false);

  },
  handleDuplicateWeekCalendar: function (oEvent) {
   var oCalendar = oEvent.getSource();
   var aSelectedDates = oCalendar.getSelectedDates();
   var dateFrom = this.getFirstDayOfWeek(aSelectedDates[0].getStartDate(), this.firstDayOfWeek);
   var dateTo = this.getLastDayOfWeek(aSelectedDates[0].getStartDate(), this.firstDayOfWeek);
   this.duplicateWeekCalendar(oCalendar, dateFrom, dateTo);
   var oDate;
   var oData = {
    selectedWeek: []
   };
   var oModel = new JSONModel();

   if (this.getModel("selectedDatesDupWeek")) {
    var data = this.getModel("selectedDatesDupWeek").getData();
    var search = $.grep(data.selectedWeek, function (element, index) {
     return element.dateFrom.toDateString() === dateFrom.toDateString();
    });
    if (search.length === 0) {
     data.selectedWeek.push({
      dateFrom: dateFrom,
      dateTo: dateTo
     });
    }
    oModel.setData(data);
   } else {
    oData.selectedWeek.push({
     dateFrom: dateFrom,
     dateTo: dateTo
    });
    oModel.setData(oData);
   }
   this.setModel(oModel, "selectedDatesDupWeek");
   this.getModel('controls').setProperty("/duplicateWeekButtonEnable", true);
  },

  calendarSelection: function (oCalendar, startDate, endDate) {
   oCalendar.destroySelectedDates();
   // for (var i = startDate; i <= endDate; i.setDate(i.getDate() + 1)) {
   //  oCalendar.set
   // }
   var selectedDates = new sap.ui.unified.DateRange();
   selectedDates.setStartDate(startDate);
   selectedDates.setEndDate(endDate);
   oCalendar.addSelectedDate(selectedDates);
  },

  duplicateWeekCalendar: function (oCalendar, startDate, endDate) {
   oCalendar.destroySelectedDates();
   var selectedDates = new sap.ui.unified.DateRange();
   selectedDates.setStartDate(startDate);
   selectedDates.setEndDate(endDate);
   oCalendar.addSelectedDate(selectedDates);
  },

  bindTable: function (startDate, endDate) {
   this.oTable.setBusy(true);
   var entries = $.extend(true, [], this.getModel('TimeEntries').getData());
   var oModel = new sap.ui.model.json.JSONModel();
   var timedata = [];
   var statusdata = [{
    key: '100',
    text: '{i18n>allStatus}'
   }, {
    key: '10'
   }, {
    key: '20'
   }, {
    key: '30'
   }, {
    key: '40'
   }];
   for (var i = startDate; i <= endDate; i.setDate(i.getDate() + 1)) {
    var dateSearch = this.oFormatyyyymmdd.format(i);
    var daterecords = $.grep(entries, function (element, index) {
     return element.CaleDate == dateSearch;
    });
    if (daterecords.length === 0) {
     continue;
    }
    var recordTemplate = {
     AllowEdit: "",
     AllowRelease: "",
     AssignmentId: "",
     AssignmentName: "",
     CatsDocNo: "",
     Counter: "",
     Pernr: this.empID,
     RefCounter: "",
     RejReason: "",
     Status: "",
     SetDraft: false,
     HeaderData: {
      target: daterecords[0].TargetHours,
      sum: "0.00",
      date: new Date(i),
      addButton: false,
      highlight: false
     },
     target: daterecords[0].TargetHours,
     TimeEntryDataFields: {
      AENAM: "",
      ALLDF: "",
      APDAT: null,
      APNAM: "",
      ARBID: "00000000",
      ARBPL: "",
      AUERU: "",
      AUFKZ: "",
      AUTYP: "00",
      AWART: "",
      BEGUZ: "000000",
      BELNR: "",
      BEMOT: "",
      BUDGET_PD: "",
      BUKRS: "",
      BWGRL: "0.0",
      CATSAMOUNT: "0.0",
      CATSHOURS: "0.00",
      CATSQUANTITY: "0.0",
      CPR_EXTID: "",
      CPR_GUID: "",
      CPR_OBJGEXTID: "",
      CPR_OBJGUID: "",
      CPR_OBJTYPE: "",
      ENDUZ: "000000",
      ERNAM: "",
      ERSDA: "",
      ERSTM: "",
      ERUZU: "",
      EXTAPPLICATION: "",
      EXTDOCUMENTNO: "",
      EXTSYSTEM: "",
      FUNC_AREA: "",
      FUND: "",
      GRANT_NBR: "",
      HRBUDGET_PD: "",
      HRCOSTASG: "0",
      HRFUNC_AREA: "",
      HRFUND: "",
      HRGRANT_NBR: "",
      HRKOSTL: "",
      HRLSTAR: "",
      KAPAR: "",
      KAPID: "00000000",
      KOKRS: "",
      LAEDA: "",
      LAETM: "",
      LGART: "",
      LOGSYS: "",
      LONGTEXT: "",
      LONGTEXT_DATA: "",
      LSTAR: "",
      LSTNR: "",
      LTXA1: "",
      MEINH: "",
      OFMNW: "0.0",
      OTYPE: "",
      PAOBJNR: "0000000000",
      PEDD: "00000000",
      PERNR: "00000000",
      PLANS: "00000000",
      POSID: "",
      PRAKN: "",
      PRAKZ: "0000",
      PRICE: "0.0",
      RAPLZL: "00000000",
      RAUFNR: "",
      RAUFPL: "0000000000",
      REASON: "",
      REFCOUNTER: "000000000000",
      REINR: "0000000000",
      RKDAUF: "",
      RKDPOS: "000000",
      RKOSTL: "",
      RKSTR: "",
      RNPLNR: "",
      RPROJ: "00000000",
      RPRZNR: "",
      SBUDGET_PD: "",
      SEBELN: "",
      SEBELP: "00000",
      SKOSTL: "",
      SPLIT: 0,
      SPRZNR: "",
      STATKEYFIG: "",
      STATUS: "",
      S_FUNC_AREA: "",
      S_FUND: "",
      S_GRANT_NBR: "",
      TASKCOMPONENT: "",
      TASKCOUNTER: "",
      TASKLEVEL: "",
      TASKTYPE: "",
      TCURR: "",
      TRFGR: "",
      TRFST: "",
      UNIT: "",
      UVORN: "",
      VERSL: "",
      VORNR: "",
      VTKEN: "",
      WABLNR: "",
      WAERS: "",
      WERKS: "",
      WORKDATE: new Date(i),
      WORKITEMID: "000000000000",
      WTART: ""
     },
     TimeEntryOperation: ""
    };
    if (daterecords[0].TimeEntries.results.length > 1) {
     daterecords[0].TimeEntries.results = daterecords[0].TimeEntries.results.sort(function (obj1, obj2) {
      if (parseFloat(obj1.TimeEntryDataFields.CATSHOURS) > parseFloat(obj2.TimeEntryDataFields.CATSHOURS)) {
       return -1;
      } else if (parseFloat(obj2.TimeEntryDataFields.CATSHOURS) > parseFloat(obj1.TimeEntryDataFields.CATSHOURS)) {
       return 1;
      }
     });
    }
    // recordTemplate.target = daterecords[0].TargetHours;
    // recordTemplate.CaleDate = new Date(i);
    // recordTemplate.TimeEntryDataFields.WORKDATE = new Date(i);

    // recordTemplate.hours = daterecords[0].CatsHours;
    var sumHours = 0;
    for (var j = 0; j < daterecords[0].TimeEntries.results.length; j++) {
     daterecords[0].TimeEntries.results[j].target = daterecords[0].TargetHours;
     daterecords[0].TimeEntries.results[j].TimeEntryDataFields.CATSHOURS = parseFloat(daterecords[0].TimeEntries.results[j].TimeEntryDataFields
      .CATSHOURS).toFixed(2);
     sumHours = parseFloat(sumHours) + parseFloat(daterecords[0].TimeEntries.results[j].TimeEntryDataFields
      .CATSHOURS);

     // formatter.status(daterecords[0].TimeEntries.results[j].TimeEntryDataFields.STATUS);
     timedata.push(daterecords[0].TimeEntries.results[j]);
    }
    for (var j = 0; j < daterecords[0].TimeEntries.results.length; j++) {
     daterecords[0].TimeEntries.results[j].totalHours = sumHours.toFixed(2);
     if ((j + 1) === daterecords[0].TimeEntries.results.length) {
      daterecords[0].TimeEntries.results[j].addButton = true;
      daterecords[0].TimeEntries.results[j].addButtonEnable = true;
      daterecords[0].TimeEntries.results[j].deleteButton = true;
      daterecords[0].TimeEntries.results[j].deleteButtonEnable = true;
      daterecords[0].TimeEntries.results[j].SetDraft = false;
      daterecords[0].TimeEntries.results[j].HeaderData = {
       target: daterecords[0].TargetHours,
       sum: sumHours,
       date: new Date(i),
       addButton: true,
       highlight: false
      };
     } else {
      daterecords[0].TimeEntries.results[j].addButton = false;
      daterecords[0].TimeEntries.results[j].deleteButton = true;
      daterecords[0].TimeEntries.results[j].deleteButtonEnable = true;
      daterecords[0].TimeEntries.results[j].SetDraft = false;
      daterecords[0].TimeEntries.results[j].HeaderData = {
       target: daterecords[0].TargetHours,
       sum: sumHours,
       date: new Date(i),
       addButton: false,
       highlight: false
      };
     }
    }
    if (daterecords[0].TimeEntries.results.length === 0) {
     recordTemplate.totalHours = sumHours.toFixed(2);
     recordTemplate.addButton = true;
     recordTemplate.HeaderData.addButton = true;
     recordTemplate.addButtonEnable = false;
     recordTemplate.deleteButtonEnable = false;
     recordTemplate.SetDraft = false;
     timedata.push(recordTemplate);
    }

   }
   for (var i = 0; i < timedata.length; i++) {
    if (timedata[i].TimeEntryDataFields.STATUS === "10") {
     timedata[i].SetDraft = true;
    }
    var element = $.grep(statusdata, function (element, index) {
     if (timedata[i].TimeEntryDataFields.STATUS && timedata[i].TimeEntryDataFields.STATUS != "")
      return element.key === timedata[i].TimeEntryDataFields.STATUS;
    });
    if (element && element.length > 0) {
     continue;
    }
    timedata[i].highlight = "None";
    timedata[i].valueState = "None";
   }
   oModel.setData(timedata);
   oModel.attachPropertyChange(this.onOverviewDataChanged.bind(this));
   this.setModel(oModel, "TimeData");
   this.setModel(new JSONModel(statusdata), "Status");
   this.oTable.setBusy(false);
  },
  onOverviewDataChanged: function () {
   var that = this;
   var oControl = this.getModel("controls");
   oControl.setProperty('/overviewDataChanged', true);
  },
  getFirstDayOfWeek: function (date, from) {
   //Default start week from 'Sunday'. You can change it yourself.
   // from = from || 'Sunday';
   // var index = this.weekday.indexOf(from);
   // var index = this.weekday.indexOf(from);
   var index = from;
   var start = index >= 0 ? index : 0;
   var d = new Date(date);
   var day = d.getDay();
   var diff = d.getDate() - day + (start > day ? start - 7 : start);
   d.setDate(diff);
   return d;
  },
  getLastDayOfWeek: function (date, from) {
   // from = from || 'Sunday';
   // var index = this.weekday.indexOf(from);
   var index = from;
   var start = index >= 0 ? index : 0;

   var d = new Date(date);
   var day = d.getDay();
   var diff = d.getDate() - day + (start > day ? start - 1 : 6 + start);
   d.setDate(diff);
   return d;
  },
  onEdit: function () {
   var oModel = this.getModel('controls');
   oModel.setProperty('/showFooter', true);
   oModel.setProperty('/sendForApproval', true);
   oModel.setProperty('/submitDraft', this.profileInfo.AllowRelease === "TRUE" ? false : true);
   oModel.setProperty('/overviewCancel', true);
   oModel.setProperty('/todoCancel', false);
   oModel.setProperty('/duplicateVisibility', true);
   if (sap.ui.Device.system.phone === false) {
    oModel.setProperty('/duplicateWeekVisibility', true);
   }
   oModel.setProperty('/overviewEdit', false);
   oModel.setProperty('/todoDone', false);
   // oModel.setProperty('/onEdit', "MultiSelect");
   oModel.setProperty('/onEdit', "None");
   oModel.setProperty('/duplicateTaskEnable', false);

   this.readTemplate = new sap.m.ColumnListItem({
    cells: [
     new sap.m.Text({
      text: "{path: 'TimeData>TimeEntryDataFields/WORKDATE', type: 'sap.ui.model.type.Date', formatOptions: { pattern: 'EEEE, MMMM d' }}"
     }),
     new sap.m.ObjectIdentifier({
      text: "{TimeData>TimeEntryDataFields/AWART}"
     }),
     // new sap.m.ObjectIdentifier({
     //  text: "{TimeData>TimeEntryDataFields/CATSHOURS} / {TimeData>target}",
     //  state: {
     //   parts: [{
     //    path: 'TimeData>TimeEntryDataFields/CATSHOURS'
     //   }, {
     //    path: 'TimeData>target'
     //   }],
     //   formatter: formatter.hoursValidation
     //  }
     // }),
     new sap.m.ObjectStatus({
      text: {
       path: 'TimeData>TimeEntryDataFields/STATUS',
       formatter: formatter.status
      },
      state: {
       path: 'TimeData>TimeEntryDataFields/STATUS',
       formatter: formatter.state
      }
     }),
     new sap.m.ObjectStatus({
      icon: "sap-icon://notes",
      visible: {
       path: 'TimeData>TimeEntryDataFields/LONGTEXT',
       formatter: formatter.visibility
      }
     })
    ]
   });
   // this.oReadOnlyTemplate = this.getView().byId("idOverviewTable").removeItem(0);

   // this.getView().byId("idOverviewTable").setMode("MultiSelect");
   this.oEditableTemplate = new sap.m.ColumnListItem({
    highlight: "{TimeData>highlight}",
    cells: [
     // new sap.ui.layout.VerticalLayout({content:[
     //  new sap.m.Text({
     //  text: "{path: 'TimeData>TimeEntryDataFields/WORKDATE', type: 'sap.ui.model.type.Date', formatOptions: { pattern: 'EEEE, MMMM d' }}"
     // }),
     // new sap.m.ObjectStatus({
     //  text: {
     //   parts: [{
     //    path: 'TimeData>totalHours'
     //   }, {
     //    path: 'TimeData>target'
     //   }],
     //   formatter: formatter.concatStrings
     //  },
     //  state: {
     //   parts: [{
     //    path: 'TimeData>totalHours'
     //   }, {
     //    path: 'TimeData>target'
     //   }],
     //   formatter: formatter.hoursValidation
     //  }
     // }),
     // ]}),
     // new sap.m.Text({
     //  text: "{path: 'TimeData>TimeEntryDataFields/WORKDATE', type: 'sap.ui.model.type.Date', formatOptions: { pattern: 'EEE, MMM d' }}"
     // }),
     // new sap.m.ObjectStatus({
     //  text: {
     //   parts: [{
     //    path: 'TimeData>totalHours'
     //   }, {
     //    path: 'TimeData>target'
     //   }],
     //   formatter: formatter.concatStrings
     //  },
     //  state: {
     //   parts: [{
     //    path: 'TimeData>totalHours'
     //   }, {
     //    path: 'TimeData>target'
     //   }],
     //   formatter: formatter.hoursValidation
     //  }
     // }),
     // new sap.m.ComboBox({
     //  selectedKey: "{TimeData>AssignmentId}",
     //  selectionChange: this.onSelectionChange
     // }).bindItems({
     //  path: "Tasks>/",
     //  // factory: this.activeTasks,
     //  template: new sap.ui.core.Item({
     //   key: "{Tasks>AssignmentId}",
     //   text: "{Tasks>AssignmentName}",
     //   enabled: {
     //    path: 'Tasks>AssignmentStatus',
     //    formatter: this.formatter.activeTasks
     //   }
     //  }),
     //  templateShareable: true
     // }),
     new sap.m.ObjectStatus({
      text: {
       parts: [{
        path: 'TimeData>totalHours',
        type: 'sap.ui.model.odata.type.Decimal',
        formatOptions: {
         parseAsString: true,
         decimals: 2,
         maxFractionDigits: 2,
         minFractionDigits: 0
        },
        constraints: {
         precision: 4,
         scale: 2,
         minimum: '0',
         maximum: '10000'
        }
       }, {
        path: 'TimeData>target',
        type: 'sap.ui.model.odata.type.Decimal',
        formatOptions: {
         parseAsString: true,
         decimals: 2,
         maxFractionDigits: 2,
         minFractionDigits: 0
        },
        constraints: {
         precision: 4,
         scale: 2,
         minimum: '0',
         maximum: '10000'
        }
       }],
       formatter: formatter.concatStrings
      },
      visible: sap.ui.Device.system.phone ? false : true
     }),
     new sap.m.ComboBox({
      selectedKey: "{TimeData>AssignmentId}",
      selectionChange: this.onSelectionChange,
      showSecondaryValues: true
     }).bindItems({
      path: "TasksWithGroups>/",
      // factory: this.activeTasks,
      template: new sap.ui.core.ListItem({
       key: "{TasksWithGroups>AssignmentId}",
       text: "{TasksWithGroups>AssignmentName}",
       enabled: {
        path: 'TasksWithGroups>AssignmentStatus',
        formatter: this.formatter.activeTasks
       },
       additionalText: "{TasksWithGroups>AssignmentType}"
      }),
      templateShareable: true
     }),

     // new sap.ui.layout.VerticalLayout({
     // content: [
     new sap.ui.layout.HorizontalLayout({
      content: [
       // new sap.m.Input({
       //  value: {
       //   path: 'TimeData>TimeEntryDataFields/CATSHOURS',
       //   type: 'sap.ui.model.odata.type.Decimal',
       //   formatOptions: {
       //    parseAsString: true,
       //    decimals: 2,
       //    maxFractionDigits: 2,
       //    minFractionDigits: 0
       //   },
       //   constraints: {
       //    precision: 4,
       //    scale: 2,
       //    minimum: '0',
       //    maximum: '10000'
       //   }
       //  },
       //  description: {
       //   parts: [{
       //    path: 'TimeData>TimeEntryDataFields/UNIT'
       //   }, {
       //    path: 'TimeData>TimeEntryDataFields/CATSHOURS'
       //   }],
       //   formatter: formatter.getUnitTexts.bind(this)
       //  },
       //  liveChange: this.liveChangeHours.bind(this),
       //  type: sap.m.InputType.Number,
       //  width: "100%",
       //  fieldWidth: "60%",
       //  valueState: "{TimeData>valueState}",
       //  valueStateText: "{TimeData>valueStateText}",
       // })
       // new sap.m.StepInput({
       //  value: "{TimeData>TimeEntryDataFields/CATSHOURS}",
       //  description: {
       //   parts: [{
       //    path: 'TimeData>TimeEntryDataFields/UNIT'
       //   }, {
       //    path: 'TimeData>TimeEntryDataFields/CATSHOURS'
       //   }],
       //   formatter: formatter.getUnitTexts.bind(this)
       //  },
       //  change: this.liveChangeHours.bind(this),
       //  displayValuePrecision: 2,
       //  step: 1,
       //  required: true,
       //  min: 0,
       //  fieldWidth: "60%",
       //  valueState: "{TimeData>valueState}",
       //  valueStateText: "{TimeData>valueStateText}",
       // })
       new sap.m.StepInput({
        value: {
         parts: [{
          path: 'TimeData>TimeEntryDataFields/CATSHOURS'
         }, {
          path: 'TimeData>TimeEntryDataFields/CATSQUANTITY'
         }, {
          path: 'TimeData>TimeEntryDataFields/CATSAMOUNT'
         }],
         formatter: formatter.calHoursQuanAmountInput.bind(this)
        },
        description: {
         parts: [{
          path: 'TimeData>TimeEntryDataFields/UNIT'
         }, {
          path: 'TimeData>TimeEntryDataFields/CATSHOURS'
         }],
         formatter: formatter.getUnitTexts.bind(this)
        },
        change: this.liveChangeHours.bind(this),
        displayValuePrecision: 2,
        step: 1,
        min: 0,
        fieldWidth: "60%",
        valueState: "{TimeData>valueState}",
        valueStateText: "{TimeData>valueStateText}",
       })
       //  , 
       //  new sap.m.Label({
       //   text: "{TimeData>TimeEntryDataFields/UNIT}",
       //   style: "Bold"
      ]
     }),
     new sap.m.CheckBox({
      selected: "{TimeData>SetDraft}",
      visible: this.draftStatus,
     }).attachSelect(this.onSelectionDraft.bind(this)),
     // {

     // path: 
     // "{TimeData>SetDraft}"
     // ,
     // formatter: this.formatter.isSelected.bind(this)
     //  allowWrapping: true
     // }),
     new sap.m.TimePicker({
      value: {
       path: 'TimeData>TimeEntryDataFields/BEGUZ',
       formatter: this.formatter.formatTime.bind(this)
      },
      visible: this.clockTimeVisible,
      valueFormat: "HH:mm",
      displayFormat: "HH:mm",
      change: this.startTimeChange.bind(this),
      placeholder: this.oBundle.getText("startTime")
     }),
     new sap.m.TimePicker({
      value: {
       path: 'TimeData>TimeEntryDataFields/ENDUZ',
       formatter: this.formatter.formatTime.bind(this)
      },
      visible: this.clockTimeVisible,
      valueFormat: "HH:mm",
      displayFormat: "HH:mm",
      change: this.endTimeChange.bind(this),
      placeholder: this.oBundle.getText("endTime")
     }),
     // new sap.ui.layout.ResponsiveFlowLayout({
     //  content: [new sap.m.TimePicker({
     //   value: {
     //    path: 'TimeData>TimeEntryDataFields/BEGUZ',
     //    formatter: '.formatTime'
     //   },
     //   valueFormat: "HH:mm",
     //   displayFormat: "HH:mm",
     //   change: "handleChange",
     //   placeholder: this.oBundle.getText("startTime")
     //  }), new sap.m.TimePicker({
     //   value: {
     //    path: 'TimeData>TimeEntryDataFields/ENDUZ',
     //    formatter: '.formatTime'
     //   },
     //   valueFormat: "HH:mm",
     //   displayFormat: "HH:mm",
     //   change: "handleChange",
     //   placeholder: this.oBundle.getText("endTime")
     //  })],
     //  visible: this.clockTimeVisible
     // }),
     // new sap.m.Button({
     //  icon: 'sap-icon://history',
     //  type: sap.m.ButtonType.Emphasized,
     //  tooltip: this.oBundle.getText('clockTime'),
     //  press: this.clockTimesPopOver.bind(this)
     // })
     // new sap.m.Link({
     //  text: "{i18n>clockTime}",
     //  press: this.clockTimesPopOver.bind(this),
     //  visible: this.clockTimeVisible
     // })
     // ],
     // class:"sapUiSmallMargin"
     // }),
     // new sap.ui.layout.HorizontalLayout({
     // content: [
     new sap.m.ObjectStatus({
      text: {
       path: 'TimeData>TimeEntryDataFields/STATUS',
       formatter: formatter.status
      },
      state: {
       path: 'TimeData>TimeEntryDataFields/STATUS',
       formatter: formatter.state
      }
     }),
     // ]}),
     new sap.m.Button({
      icon: {
       path: 'TimeData>TimeEntryDataFields/LONGTEXT',
       formatter: formatter.longtextButtons
      },
      type: sap.m.ButtonType.Transparent,
      press: this.longtextPopover.bind(this)
     }),
     new sap.ui.layout.HorizontalLayout({
      content: [new sap.m.Button({
        icon: "sap-icon://sys-cancel",
        type: sap.m.ButtonType.Transparent,
        press: this.onOverviewDeleteRow.bind(this),
        visible: "{TimeData>deleteButton}",
        enabled: "{TimeData>deleteButtonEnable}"
       }),
       new sap.m.Button({
        icon: "sap-icon://add",
        type: sap.m.ButtonType.Transparent,
        press: this.onOverviewAddRow.bind(this),
        visible: "{TimeData>addButton}",
        enabled: "{TimeData>addButtonEnable}"
       })
      ]
     })

    ],
    customData: [new sap.ui.core.CustomData({
     key: "counter",
     value: "{TimeData>Counter}"
    })]
   });
   // this.rebindTable(this.oEditableTemplate, "Edit");
   this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oEditableTemplate, "Edit");
  },
  onSave: function () {

  },
  onSelectionDraft: function (oEvent) {
   var that = this;
   var oModel = this.oTable.getModel('TimeData');
   var index = parseInt(oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1]);
   var data = oModel.getData();
   var counter = oEvent.getSource().getParent().getCustomData('counter')[0].getValue();
   if (counter && counter !== null) {
    data[index].TimeEntryOperation = 'U';
   } else {
    data[index].TimeEntryOperation = 'C';
   }
   this.getModel("controls").setProperty("/isOverviewChanged", true);
   this.getModel("controls").setProperty("/overviewDataChanged", true);
  },
  onSelectionChange: function (oEvent) {
   var selectedKey = oEvent.getParameter('selectedItem').getKey();
   var selectedText = oEvent.getParameter('selectedItem').getText();

   if (oEvent.getParameter('selectedItem').getBindingContext('TasksWithGroups').getModel().getData()[parseInt(oEvent.getParameter(
     'selectedItem').getBindingContext('TasksWithGroups').getPath().split("/")[1])].Type === "group") {
    var entry;
    var oModel = this.getModel('TimeData');
    var oGroups = this.getModel('AssignmentGroups').getData();
    var data = oModel.getData();
    var index = parseInt(oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1]);
    var oSelectedGroup = $.grep(oGroups, function (element, ind) {
     return element.groupId === selectedKey;
    });
    for (var i = 0; i < oSelectedGroup[0].Assignments.length; i++) {
     var workdate = new Date(data[index].TimeEntryDataFields.WORKDATE);
     var hours = data[index].TimeEntryDataFields.CATSHOURS;
     var status = data[index].TimeEntryDataFields.STATUS;
     var startTime = data[index].TimeEntryDataFields.BEGUZ;
     var endTime = data[index].TimeEntryDataFields.ENDUZ;
     // delete data[index].TimeEntryDataFields;
     var taskdata = this.getModel('Tasks').getData();
     var task = $.grep(taskdata, function (element, ind) {
      return element.AssignmentId === oSelectedGroup[0].Assignments[i].AssignmentId;
     });
     if (i === 0) {
      data[index].TimeEntryDataFields = $.extend(true, {}, task[0].AssignmentFields);
      if (this.getModel('controls').getProperty('/approverAllowed')) {
       data[index].ApproverId = task[0].ApproverId;
      }
      data[index].AssignmentId = task[0].AssignmentId;
      data[index].AssignmentName = task[0].AssignmentName;
      data[index].TimeEntryDataFields
       .WORKDATE = workdate;
      data[index].TimeEntryDataFields.CATSHOURS = hours;
      data[index].TimeEntryDataFields.STATUS = status;
      data[
       index].TimeEntryDataFields.BEGUZ = startTime;
      data[index].TimeEntryDataFields.ENDUZ = endTime;
      // insert.AssignmentName = selectedText;
      // insert.AssignmentId = selectedKey;
      if (data[index].Counter && data[index].Counter !== null && data[index].Counter !== "") {
       data[index].TimeEntryOperation = 'U';
       data[index].deleteButtonEnable = true;
       // if (i == oSelectedGroup[0].Assignments.length - 1) {
       data[index].addButtonEnable = true;
       // }

      } else {
       data[index].TimeEntryOperation = 'C';
       data[index].Counter = "";
       data[index].deleteButtonEnable = true;
       // if (i == oSelectedGroup[0].Assignments.length - 1) {
       data[index].addButtonEnable = true;
       // }
      }
      data[index].highlight = sap.ui.core.MessageType.Information;
      data[index].HeaderData.highlight = sap.ui.core.MessageType.Information;
      data[
       index].HeaderData.addButton = true;
     } else {
      var insert = $.extend(true, {}, data[index]);
      insert.TimeEntryDataFields = $.extend(true, {}, task[0].AssignmentFields);
      if (this.getModel('controls').getProperty('/approverAllowed')) {
       insert.ApproverId = task[0].ApproverId;
      }
      insert.AssignmentId = task[0].AssignmentId;
      insert.AssignmentName = task[0].AssignmentName;
      insert.TimeEntryDataFields.WORKDATE = workdate;
      insert.TimeEntryDataFields.CATSHOURS = hours;
      insert.TimeEntryDataFields.STATUS = status;
      insert.TimeEntryDataFields.BEGUZ = startTime;
      insert.TimeEntryDataFields.ENDUZ = endTime;
      // insert.AssignmentName = selectedText;
      // insert.AssignmentId = selectedKey;
      // if (insert.Counter && insert.Counter !== null && insert.Counter !== "") {
      //  insert.TimeEntryOperation = 'U';
      //  insert.deleteButtonEnable = true;
      //  if (i == oSelectedGroup[0].Assignments.length - 1) {
      //   insert.addButtonEnable = true;
      //  }

      // } else {
      insert.TimeEntryOperation = 'C';
      insert.Counter = "";
      insert.deleteButtonEnable = true;
      // if (i == oSelectedGroup[0].Assignments.length - 1) {
      insert.addButtonEnable = false;
      insert.addButton = false;
      // }
      // }
      insert.highlight = sap.ui.core.MessageType.Information;
      insert.HeaderData.highlight = sap.ui.core.MessageType.Information;
      insert.HeaderData.addButton = false;
      data.splice(index, 0, insert);
     }

    }
    var toastMsg = this.getModel("i18n").getResourceBundle().getText('groupImported');
    sap.m.MessageToast.show(toastMsg, {
     duration: 2000
    });
   } else {
    var entry;
    var oModel = this.getModel('TimeData');
    var data = oModel.getData();
    var index = parseInt(oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1]);
    var workdate = data[index].TimeEntryDataFields.WORKDATE;
    var hours = data[index].TimeEntryDataFields.CATSHOURS;
    var status = data[index].TimeEntryDataFields.STATUS;
    var startTime = data[index].TimeEntryDataFields.BEGUZ;
    var endTime = data[index].TimeEntryDataFields.ENDUZ;
    delete data[index].TimeEntryDataFields;
    var taskdata = this.getModel('Tasks').getData();
    var task = $.grep(taskdata, function (element, ind) {
     return element.AssignmentId === selectedKey;
    });
    data[index].TimeEntryDataFields = $.extend(true, {}, task[0].AssignmentFields);
    if (this.getModel('controls').getProperty('/approverAllowed')) {
     data[index].ApproverId = task[0].ApproverId;
    }
    data[index].TimeEntryDataFields.WORKDATE = workdate;
    data[index].TimeEntryDataFields.CATSHOURS = hours;
    data[index].TimeEntryDataFields.STATUS = status;
    data[index].TimeEntryDataFields.BEGUZ = startTime;
    data[index].TimeEntryDataFields.ENDUZ = endTime;
    data[index].AssignmentName = selectedText;
    data[index].AssignmentId = selectedKey;
    if (data[index].Counter && data[index].Counter !== null && data[index].Counter !== "") {
     data[index].TimeEntryOperation = 'U';
     data[index].deleteButtonEnable = true;
     data[index].addButtonEnable = true;
    } else {
     data[index].TimeEntryOperation = 'C';
     data[index].Counter = "";
     data[index].deleteButtonEnable = true;
     data[index].addButtonEnable = true;
    }
    // oModel.setData(data);
    // this.setModel(oModel, 'TimeData');
   }
   this.getModel("controls").setProperty("/isOverviewChanged", true);
   this.getModel("controls").setProperty("/overviewDataChanged", true);
  },
  onSelectionChangeToDo: function (oEvent) {
   // var selectedKey = oEvent.getParameter('selectedItem').getKey();
   // var selectedText = oEvent.getParameter('selectedItem').getText();
   // var oModel = this.getModel('TodoList');
   // var data = $.extend(true, [], oModel.getData());
   // var index = parseInt(oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1]);
   // var workdate = new Date(data[index].TimeEntryDataFields.WORKDATE);
   // var hours = data[index].TimeEntryDataFields.CATSHOURS;
   // var status = data[index].TimeEntryDataFields.STATUS;
   // var startTime = data[index].TimeEntryDataFields.BEGUZ;
   // var endTime = data[index].TimeEntryDataFields.ENDUZ;
   // delete data[index].TimeEntryDataFields;
   // var taskdata = this.getModel('Tasks').getData();
   // var task = $.grep(taskdata, function (element, ind) {
   //  return element.AssignmentId === selectedKey;
   // });
   // data[index].TimeEntryDataFields = $.extend(true, {}, task[0].AssignmentFields);
   // data[index].TimeEntryDataFields.WORKDATE = workdate;
   // data[index].TimeEntryDataFields.CATSHOURS = hours;
   // data[index].TimeEntryDataFields.STATUS = status;
   // data[index].TimeEntryDataFields.BEGUZ = startTime;
   // data[index].TimeEntryDataFields.ENDUZ = endTime;
   // data[index].AssignmentName = selectedText;
   // data[index].AssignmentId = selectedKey;
   // if (data[index].Counter && data[index].Counter !== null && data[index].Counter !== "") {
   //  data[index].TimeEntryOperation = 'U';
   //  data[index].sendButton = true;
   //  data[index].addButtonEnable = true;
   // } else {
   //  data[index].TimeEntryOperation = 'C';
   //  data[index].sendButton = true;
   //  data[index].addButtonEnable = true;
   // }
   // oModel.setData(data);
   // this.setModel(oModel, 'TodoList');
   var selectedKey = oEvent.getParameter('selectedItem').getKey();
   var selectedText = oEvent.getParameter('selectedItem').getText();

   if (oEvent.getParameter('selectedItem').getBindingContext('TasksWithGroups').getModel().getData()[parseInt(oEvent.getParameter(
     'selectedItem').getBindingContext('TasksWithGroups').getPath().split("/")[1])].Type === "group") {
    var entry;
    var oModel = this.getModel('TodoList');
    var oGroups = this.getModel('AssignmentGroups').getData();
    var data = oModel.getData();
    var index = parseInt(oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1]);
    var oSelectedGroup = $.grep(oGroups, function (element, ind) {
     return element.groupId === selectedKey;
    });
    for (var i = 0; i < oSelectedGroup[0].Assignments.length; i++) {
     var workdate = new Date(data[index].TimeEntryDataFields.WORKDATE);
     var hours = data[index].TimeEntryDataFields.CATSHOURS;
     var status = data[index].TimeEntryDataFields.STATUS;
     var startTime = data[index].TimeEntryDataFields.BEGUZ;
     var endTime = data[index].TimeEntryDataFields.ENDUZ;
     // delete data[index].TimeEntryDataFields;
     var taskdata = this.getModel('Tasks').getData();
     var task = $.grep(taskdata, function (element, ind) {
      return element.AssignmentId === oSelectedGroup[0].Assignments[i].AssignmentId;
     });
     if (i === 0) {
      data[index].TimeEntryDataFields = $.extend(true, {}, task[0].AssignmentFields);
      if (this.getModel('controls').getProperty('/approverAllowed')) {
       data[index].ApproverId = task[0].ApproverId;
      }
      data[index].AssignmentId = task[0].AssignmentId;
      data[index].AssignmentName = task[0].AssignmentName;
      data[index].TimeEntryDataFields.WORKDATE = workdate;
      data[index].TimeEntryDataFields.CATSHOURS = hours;
      data[index].TimeEntryDataFields.STATUS = status;
      data[index].TimeEntryDataFields.BEGUZ = startTime;
      data[index].TimeEntryDataFields.ENDUZ = endTime;
      data[index].highlight = sap.ui.core.MessageType.Information;
      // insert.AssignmentName = selectedText;
      // insert.AssignmentId = selectedKey;
      if (data[index].Counter && data[index].Counter !== null && data[index].Counter !== "") {
       data[index].TimeEntryOperation = 'U';
       data[index].deleteButtonEnable = true;
       // if (i == oSelectedGroup[0].Assignments.length - 1) {
       data[index].addButtonEnable = true;
       // }

      } else {
       data[index].TimeEntryOperation = 'C';
       data[index].Counter = "";
       data[index].deleteButtonEnable = true;
       // if (i == oSelectedGroup[0].Assignments.length - 1) {
       data[index].addButtonEnable = true;
       // }
      }
     } else {
      var insert = $.extend(true, {}, data[index]);
      insert.TimeEntryDataFields = $.extend(true, {}, task[0].AssignmentFields);
      if (this.getModel('controls').getProperty('/approverAllowed')) {
       insert.ApproverId = task[0].ApproverId;
      }
      insert.AssignmentId = task[0].AssignmentId;
      insert.AssignmentName = task[0].AssignmentName;
      insert.TimeEntryDataFields.WORKDATE = workdate;
      insert.TimeEntryDataFields.CATSHOURS = hours;
      insert.TimeEntryDataFields.STATUS = status;
      insert.TimeEntryDataFields.BEGUZ = startTime;
      insert.TimeEntryDataFields.ENDUZ = endTime;
      insert.highlight = sap.ui.core.MessageType.Information;
      // insert.AssignmentName = selectedText;
      // insert.AssignmentId = selectedKey;
      insert.TimeEntryOperation = 'C';
      insert.Counter = "";
      insert.deleteButtonEnable = true;
      // if (i == oSelectedGroup[0].Assignments.length - 1) {
      //  insert.addButtonEnable = true;
      // }
      insert.addButton = false;
      // insert.highlight = sap.ui.core.MessageType.Information;
      // insert.HeaderData.highlight = sap.ui.core.MessageType.Information;
      // insert.HeaderData.addButton = true;
      data.splice(index, 0, insert);
     }

    }
    var toastMsg = this.getModel("i18n").getResourceBundle().getText('groupImported');
    sap.m.MessageToast.show(toastMsg, {
     duration: 2000
    });
   } else {
    var entry;
    var oModel = this.getModel('TodoList');
    var data = oModel.getData();
    var index = parseInt(oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1]);
    var workdate = data[index].TimeEntryDataFields.WORKDATE;
    var hours = data[index].TimeEntryDataFields.CATSHOURS;
    var status = data[index].TimeEntryDataFields.STATUS;
    var startTime = data[index].TimeEntryDataFields.BEGUZ;
    var endTime = data[index].TimeEntryDataFields.ENDUZ;
    delete data[index].TimeEntryDataFields;
    var taskdata = this.getModel('Tasks').getData();
    var task = $.grep(taskdata, function (element, ind) {
     return element.AssignmentId === selectedKey;
    });
    data[index].TimeEntryDataFields = $.extend(true, {}, task[0].AssignmentFields);
    if (this.getModel('controls').getProperty('/approverAllowed')) {
     data[index].ApproverId = task[0].ApproverId;
    }
    data[index].TimeEntryDataFields.WORKDATE = workdate;
    data[index].TimeEntryDataFields.CATSHOURS = hours;
    data[index].TimeEntryDataFields.STATUS = status;
    data[index].TimeEntryDataFields.BEGUZ = startTime;
    data[index].TimeEntryDataFields.ENDUZ = endTime;
    data[index].highlight = sap.ui.core.MessageType.Information;
    data[index].AssignmentName = selectedText;
    data[index].AssignmentId = selectedKey;
    if (data[index].Counter && data[index].Counter !== null && data[index].Counter !== "") {
     data[index].TimeEntryOperation = 'U';
     data[index].deleteButtonEnable = true;
     data[index].addButtonEnable = true;
    } else {
     data[index].TimeEntryOperation = 'C';
     data[index].Counter = "";
     data[index].deleteButtonEnable = true;
     data[index].addButtonEnable = true;
    }
    oModel.setData(data);
    this.setModel(oModel, 'TodoList');
   }
   this.getModel("controls").setProperty("/isToDoChanged", true);
   this.getModel("controls").setProperty("/todoDataChanged", true);
  },
  onOverviewDeleteRow: function (oEvent) {
   var that = this;
   this.oTable.setBusy(true);
   var counter = oEvent.getSource().getParent().getParent().getCustomData('counter')[0].getValue();
   var oModel = this.getModel('TimeData');
   var data = oModel.getData();
   this.setModel(oModel, 'OriginalTime');
   var index = parseInt(oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1]);
   var deleteRow = $.extend(true, {}, data[index]);
   var delModel = this.getModel('deleteRecords');
   var deleteArray = this.getModel('deleteRecords').getData();
   var recordTemplate = this.recordTemplate();
   if (data[index].Counter && data[index].Counter != null) {
    if (deleteArray.length) {
     deleteArray.push(deleteRow);
     delModel.setData(deleteArray);
    } else {
     delModel.setData([deleteRow]);
    }
    this.setModel(delModel, 'deleteRecords');
   }
   var otherRecords = $.grep(data, function (element, ind) {
    return that.oFormatyyyymmdd.format(new Date(element.TimeEntryDataFields.WORKDATE)) === that.oFormatyyyymmdd.format(new Date(
     data[
      index].TimeEntryDataFields
     .WORKDATE));
   });
   var date = that.oFormatyyyymmdd.format(new Date(data[
     index].TimeEntryDataFields
    .WORKDATE));
   if (otherRecords.length >= 2) {
    data.splice(index, 1);
    var otherRecords = $.grep(data, function (element, ind) {
     return that.oFormatyyyymmdd.format(new Date(element.TimeEntryDataFields.WORKDATE)) === date;
    });
    otherRecords[otherRecords.length - 1].addButtonEnable = true;
    otherRecords[otherRecords.length - 1].addButton = true;
    otherRecords[otherRecords.length - 1].HeaderData.addButton = true;
    data = this.calculateSum(new Date(otherRecords[otherRecords.length - 1].TimeEntryDataFields.WORKDATE), data);
    oModel.setData(data);
    this.setModel(oModel, 'TimeData');
   } else {
    data[index].AssignmentId = "";
    data[index].AssignmentName = "";
    data[index].addButton = true;
    data[index].deleteButtonEnable = false;
    data[index].addButtonEnable = false;
    data[index].SetDraft = false;
    data[index].HeaderData.addButton = true;
    Object.getOwnPropertyNames(data[index].TimeEntryDataFields).forEach(function (prop) {
     if (prop == "WORKDATE") {} else {
      data[index].TimeEntryDataFields[prop] = recordTemplate.TimeEntryDataFields[prop];
     }
    });
    data = this.calculateSum(new Date(data[index].TimeEntryDataFields.WORKDATE), data);
    oModel.setData(data);
    this.setModel(oModel, 'TimeData');
   }
   this.getModel("controls").setProperty("/isOverviewChanged", true);
   this.getModel("controls").setProperty("/overviewDataChanged", true);
   this.oTable.setBusy(false);
  },

  onOverviewAddRow: function (oEvent) {
   this.oTable.setBusy(true);
   var newRecord = this.recordTemplate();
   var oControls = this.getModel("controls");
   var counter = oEvent.getSource().getParent().getParent().getCustomData('counter')[0].getValue();
   var oModel = this.getModel('TimeData');
   var index = parseInt(oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1]);
   var data = oModel.getData();
   data[index].addButton = false;
   var insert = $.extend(true, {}, newRecord);
   insert.totalHours = data[index].totalHours;
   insert.TimeEntryDataFields.WORKDATE = new Date(data[index].TimeEntryDataFields.WORKDATE);
   insert.target = data[index].target;
   insert.HeaderData = $.extend(true, {}, data[index].HeaderData);
   data[index].HeaderData.addButton = false;
   insert.highlight = sap.ui.core.MessageType.Information;
   insert.HeaderData.highlight = true;
   insert.HeaderData.addButton = true;
   insert.addButton = true;
   data.splice(index + 1, 0, insert);
   oModel.setData(data);
   this.setModel(oModel, 'TimeData');
   this.getModel("controls").setProperty("/isOverviewChanged", true);
   this.getModel("controls").setProperty("/overviewDataChanged", true);
   this.oTable.setBusy(false);
  },
  onTodoAddRow: function (oEvent) {
   this.oToDoTable.setBusy(true);
   var counter = oEvent.getSource().getParent().getParent().getCustomData('counter')[0].getValue();
   var oModel = this.getModel('TodoList');
   var index = parseInt(oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1]);
   var data = oModel.getData();
   data[index].addButton = false;
   var insert = $.extend(true, {}, data[index]);
   insert.TimeEntryDataFields.CATSHOURS = "0.00";
   insert.TimeEntryDataFields.STATUS = "";
   insert.Counter = "";
   insert.highlight = sap.ui.core.MessageType.Information;
   // insert.total = parseFloat(0.00).toFixed(2);
   insert.addButton = true;
   data.splice(index + 1, 0, insert);
   oModel.setData(data);
   this.setModel(oModel, 'TodoList');
   this.getModel("controls").setProperty("/isToDoChanged", true);
   this.getModel("controls").setProperty("/todoDataChanged", true);
   this.oToDoTable.setBusy(false);

  },
  onTodoDeleteRow: function (oEvent) {
   var that = this;
   this.oToDoTable.setBusy(true);
   var counter = oEvent.getSource().getParent().getParent().getCustomData('counter')[0].getValue();
   var oModel = this.getModel('TodoList');
   var data = oModel.getData();
   this.setModel(oModel, 'OriginalTodoTime');
   var index = parseInt(oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1]);
   var deleteRow = $.extend(true, {}, data[index]);
   var delModel = this.getModel('deleteRecords');
   var deleteArray = this.getModel('deleteRecords').getData();
   var recordTemplate = this.recordTemplate();
   // if (data[index].Counter && data[index].Counter != null) {
   //  if (deleteArray.length) {
   //   deleteArray.push(deleteRow);
   //   delModel.setData(deleteArray);
   //  } else {
   //   delModel.setData([deleteRow]);
   //  }
   //  this.setModel(delModel, 'deleteRecords');
   // }
   var otherRecords = $.grep(data, function (element, ind) {
    return that.oFormatyyyymmdd.format(new Date(element.TimeEntryDataFields.WORKDATE)) === that.oFormatyyyymmdd.format(new Date(
     data[
      index].TimeEntryDataFields
     .WORKDATE));
   });
   var date = that.oFormatyyyymmdd.format(new Date(data[
     index].TimeEntryDataFields
    .WORKDATE));
   if (otherRecords.length >= 2) {
    // if(index!==0 && index > 0 ){
    // data[index-1].addButtonEnable = true;
    // data[index-1].addButton = true;
    // }
    data.splice(index, 1);
    var otherRecords = $.grep(data, function (element, ind) {
     return that.oFormatyyyymmdd.format(new Date(element.TimeEntryDataFields.WORKDATE)) === date;
    });
    otherRecords[otherRecords.length - 1].addButtonEnable = true;
    otherRecords[otherRecords.length - 1].addButton = true;
    data = this.calculateSumToDo(new Date(otherRecords[otherRecords.length - 1].TimeEntryDataFields.WORKDATE), data);
    oModel.setData(data);
    this.setModel(oModel, 'TodoList');
   } else {
    data[index].AssignmentId = "";
    data[index].AssignmentName = "";
    data[index].addButton = true;
    data[index].addButtonEnable = true;
    Object.getOwnPropertyNames(data[index].TimeEntryDataFields).forEach(function (prop) {
     if (prop == "WORKDATE") {} else {
      data[index].TimeEntryDataFields[prop] = recordTemplate.TimeEntryDataFields[prop];
     }
    });
    data = this.calculateSumToDo(new Date(data[index].TimeEntryDataFields.WORKDATE), data);
    oModel.setData(data);
    this.setModel(oModel, 'TodoList');
   }
   this.getModel("controls").setProperty("/isToDoChanged", true);
   this.getModel("controls").setProperty("/todoDataChanged", true);
   this.oToDoTable.setBusy(false);
  },
  liveChangeHours: function (oEvent) {
   var val = /^\d+(\.\d{1,2})?$/;
   this.getModel("controls").setProperty("/isOverviewChanged", true);
   this.getModel("controls").setProperty("/overviewDataChanged", true);
   // if (!isNaN(parseFloat(oEvent.getSource().getValue()))) {
   if (val.test(oEvent.getSource().getValue())) {
    var counter = oEvent.getSource().getParent().getParent().getCustomData('counter')[0].getValue();
    // var oModel = this.getModel('TimeData');
    var oModel = this.oTable.getModel('TimeData');
    var index = parseInt(oEvent.getSource().getParent().getParent().getBindingContext('TimeData').getPath().split('/')[1]);
    var data = oModel.getData();
    if (counter && counter !== null) {
     data[index].TimeEntryOperation = 'U';
     data[index].TimeEntryDataFields.CATSHOURS = parseFloat(oEvent.getSource().getValue()).toFixed(2);
    } else {
     data[index].TimeEntryOperation = 'C';
     data[index].TimeEntryDataFields.CATSHOURS = parseFloat(oEvent.getSource().getValue()).toFixed(2);
    }
    data = this.calculateSum(new Date(data[index].TimeEntryDataFields.WORKDATE), data);
    if (data[index].AssignmentId && data[index].AssignmentId !== "") {
     // this.checkTimeEntry(oEvent.getSource(), data[index].AssignmentId, data[index].TimeEntryDataFields.CATSHOURS,
     //  data[index].TimeEntryDataFields
     //  .BEGUZ,
     //  data[index].TimeEntryDataFields.ENDUZ, this.formatter.formatToBackendString(data[index].TimeEntryDataFields.WORKDATE) +
     //  "T00:00:00", counter);
    }
    // oEvent.getSource().setValueState("None");
    // oModel.setData(data);
    this.setModel(new JSONModel(data), 'TimeData');
    // this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oEditableTemplate, "Navigation");
    // this.calculateChangeCount();
   }

  },
  checkTimeEntry: function (oSource, oAssignmentId, hours, starttime, endtime, workdate, counter) {
   var that = this;
   var obj = null;
   if (counter && counter !== null) {
    obj = {
     'AssignmentId': oAssignmentId,
     'CatsHours': hours,
     'Counter': counter,
     'EndTime': endtime,
     'Operation': "U",
     'StartTime': starttime,
     'WorkDate': workdate
    };
   } else {
    obj = {
     'AssignmentId': oAssignmentId,
     'CatsHours': hours,
     'Counter': counter,
     'EndTime': endtime,
     'Operation': "C",
     'StartTime': starttime,
     'WorkDate': workdate
    };
   }
   var mParameters = {
    // urlParameters: 'AssignmentId='+oAssignmentId+'&CatsHours='+hours+'m&Counter='+counter+'&EndTime='+endtime+'&Operation=C&StartTime='+starttime+'&WorkDate=datetime'+"'"+workdate"'",
    urlParameters: obj,
    success: function (oData, oResponse) {
     if (oData.results.length >= 1) {
      oSource.setValueState("Warning");
      oSource.setValueStateText(oData.results[0].Text);
     }

    },
    error: function (oError) {
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.callFunction('/CheckTimesheet', mParameters);
  },
  calculateChangeCount: function () {
   var data = this.getModel('TimeData').getData();
   var controls = this.getModel('controls').getData();
   var newRecords = $.grep(data, function (element, index) {
    return element.TimeEntryOperation == 'C';
   });
   var updateRecords = $.grep(data, function (element, index) {
    return element.TimeEntryOperation == 'U';
   });
   var selectedRecords = $.grep(data, function (element, index) {
    return element.TimeEntryOperation == 'R';
   });
   if (selectedRecords.length > 0) {
    controls.numberOfRecords = selectedRecords.length;
   } else {
    controls.numberOfRecords = newRecords.length + updateRecords.length;
   }
   this.getModel('controls').setData(controls);
  },
  calculateSum: function (oDate, data) {
   var that = this;
   var sum = parseFloat(0);
   oDate = this.oFormatyyyymmdd.format(oDate);
   var element = $.grep(data, function (element, index) {
    return that.oFormatyyyymmdd.format(new Date(element.TimeEntryDataFields.WORKDATE)) == oDate;
   });
   for (var i = 0; i < element.length; i++) {
    sum = (parseFloat(sum) + parseFloat(element[i].TimeEntryDataFields.CATSHOURS)).toFixed(2);
   }
   for (var j = 0; j < data.length; j++) {
    if (that.oFormatyyyymmdd.format(new Date(data[j].TimeEntryDataFields.WORKDATE)) === oDate) {
     data[j].totalHours = sum;
     data[j].HeaderData.sum = sum;
    }
   }
   return data;

  },
  calculateSumToDo: function (oDate, data) {
   var that = this;
   var sum = parseFloat(0);
   oDate = this.oFormatyyyymmdd.format(oDate);
   var element = $.grep(data, function (element, index) {
    return that.oFormatyyyymmdd.format(new Date(element.TimeEntryDataFields.WORKDATE)) == oDate;
   });
   var total = ((parseFloat(element[0].target) - parseFloat(element[0].missing))).toFixed(2);
   for (var i = 0; i < element.length; i++) {
    sum = (parseFloat(sum) + parseFloat(element[i].TimeEntryDataFields.CATSHOURS)).toFixed(2);
   }
   for (var j = 0; j < data.length; j++) {
    if (that.oFormatyyyymmdd.format(new Date(data[j].TimeEntryDataFields.WORKDATE)) === oDate) {
     data[j].total = (parseFloat(sum) + parseFloat(total)).toFixed(2);
     data[j].currentMissing = ((parseFloat(data[j].target)) - parseFloat(data[j].total)) < 0 ? parseFloat(0).toFixed(2) : ((
      parseFloat(
       data[j].target)) - parseFloat(data[j].total)).toFixed(2);
    }
   }
   return data;

  },
  onCancel: function () {
   var that = this;
   var oControl = this.getModel('controls');
   // oControl.setProperty('/showFooter', false);
   // oControl.setProperty('/sendForApproval', false);
   // oControl.setProperty('/submitDraft', false);
   // oControl.setProperty('/overviewCancel', false);
   // oControl.setProperty('/todoCancel', false);
   oControl.setProperty('/duplicateVisibility', false);
   oControl.setProperty('/duplicateWeekVisibility', false);
   oControl.setProperty('/overviewEdit', true);
   oControl.setProperty('/onEdit', "None");
   oControl.setProperty('/showFooter', false);
   oControl.setProperty('/overviewDataChanged', false);
   oControl.setProperty('/isOverviewChanged', false);
   that.bindTable(new Date(that.startdate), new Date(that.enddate));
   // this.rebindTable(this.oReadOnlyTemplate, "Navigation");
   this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
   var data = {};
   var oModel = new JSONModel();
   oModel.setData(data);
   this.setModel(oModel, 'deleteRecords');
   this.setModel(oModel, 'changedRecords');
   this.setModel(oModel, 'newRecords');
   this.setModel(oControl, "controls");
   sap.ui.getCore().getMessageManager().removeAllMessages();
   // this.rebindTable(this.readTemplate, "Navigation");
  },
  onTodoCancel: function () {
   var oControl = this.getModel('controls');
   // oControl.setProperty('/todoCancel', false);
   // oControl.setProperty('/todoDone', false);
   oControl.setProperty('/editTodoVisibility', true);
   oControl.setProperty('/showFooter', false);
   var oModel = new JSONModel($.extend(true, [], this.todolist));
   this.setModel(oModel, "TodoList");
   if (this.oReadOnlyToDoTemplate) {
    this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
   }
   sap.ui.getCore().getMessageManager().removeAllMessages();
  },
  rebindTable: function (oTemplate, sKeyboardMode) {
   this.oTable.bindItems({
    path: "TimeData>/",
    template: oTemplate,

    templateShareable: true
   }).setKeyboardMode(sKeyboardMode);
  },
  rebindTableWithTemplate: function (oTable, sPath, oTemplate, sKeyboardMode) {
   if (sPath === 'TimeData>/' && sap.ui.Device.system.phone === false) {
    oTable.bindItems({
     path: sPath,
     sorter: [new sap.ui.model.Sorter("HeaderData", false, true, this.compareRows)],
     template: oTemplate,
     templateShareable: true,
     groupHeaderFactory: this.getGroupHeader.bind(this)
    }).setKeyboardMode(sKeyboardMode);
   } else if (sPath === 'TimeData>/' && sap.ui.Device.system.phone === true) {
    oTable.bindItems({
     path: sPath,
     sorter: [new sap.ui.model.Sorter("TimeEntryDataFields/WORKDATE", false, false)
      // , new sap.ui.model.Sorter(
      //  "TimeEntryDataFields/CATSHOURS", true, false)
     ],
     template: oTemplate,
     templateShareable: true,
     // groupHeaderFactory: this.getGroupHeader
    }).setKeyboardMode(sKeyboardMode);
   } else if (sPath === 'TodoList>/') {
    oTable.bindItems({
     path: sPath,
     template: oTemplate,
     templateShareable: true
    }).setKeyboardMode(sKeyboardMode);
   }
  },
  compareRows: function (a, b) {
   if (new Date(a.date) > new Date(b.date)) {
    return 1;
   } else if (new Date(b.date) > new Date(a.date)) {
    return -1;
   } else {
    if (a.addButton == true && b.addButton == true) {
     return 0;
    } else if (b.addButton == true) {
     return -1;
    } else if (a.addButton == true) {
     return 1;
    } else if (a.highlight == true && b.highlight == true) {
     return 0;
    } else if (a.highlight == true) {
     return 1;
    } else if (b.highlight == true) {
     return -1;
    }
   }
  },

  loadTasks: function () {
   return new sap.ui.core.Item({
    key: "{Tasks>AssignmentName}",
    text: "{Tasks>AssignmentName}"
   });
  },
  onTaskCreate: function (oEvent) {
   var that = this;
   that.byId("idTasks").setBusy(true);
   var oView = this.getView();
   var formElements = [];
   var formContainers = [];
   var form = {
    name: null,
    status: false,
    containers: null
   };
   var oControl = this.getModel("controls");
   oControl.setProperty('/createAssignment', true);
   oControl.setProperty('/editAssignment', false);
   oControl.setProperty('/copyAssignment', false);
   oControl.setProperty('/displayAssignment', false);
   oControl.setProperty('/editAssignmentCancel', true);
   oControl.setProperty('/displayAssignmentCancel', false);
   oControl.setProperty('/assignmentTitle', this.oBundle.getText("createAssignment"));
   this.setGlobalModel(oControl, "controls");
   this.setGlobalModel(oControl, "controls");
   // var selectedTask = oTable.getSelectedItem().getAggregation('cells');
   var profileFields = $.extend(true, [], this.getModel('ProfileFields').getData());
   // create dialog lazily
   // var oDialog;
   // if (!oDialog) {
   //  var oDialogController = {
   //   handleConfirm: function(oEvent) {
   //    // var custom = oEvent.getSource().getCustomData('FieldName')[0].getValue();
   //    var TaskData = {
   //     ApproverId: "",
   //     ApproverName: "",
   //     AssignmentFields: {
   //      AENAM: "",
   //      ALLDF: "",
   //      APDAT: null,
   //      APNAM: "",
   //      ARBID: "",
   //      ARBPL: "",
   //      AUERU: "",
   //      AUFKZ: "",
   //      AUTYP: "",
   //      AWART: "",
   //      BEGUZ: "",
   //      BELNR: "",
   //      BEMOT: "",
   //      BUDGET_PD: "",
   //      BUKRS: "",
   //      BWGRL: "0.0",
   //      CATSAMOUNT: "0.0",
   //      CATSHOURS: "0.0",
   //      CATSQUANTITY: "0.0",
   //      CPR_EXTID: "",
   //      CPR_GUID: "",
   //      CPR_OBJGEXTID: "",
   //      CPR_OBJGUID: "",
   //      CPR_OBJTYPE: "",
   //      ENDUZ: "",
   //      ERNAM: "",
   //      ERSDA: null,
   //      ERSTM: "",
   //      ERUZU: "",
   //      EXTAPPLICATION: "",
   //      EXTDOCUMENTNO: "",
   //      EXTSYSTEM: "",
   //      FUNC_AREA: "",
   //      FUND: "",
   //      GRANT_NBR: "",
   //      HRBUDGET_PD: "",
   //      HRCOSTASG: "",
   //      HRFUNC_AREA: "",
   //      HRFUND: "",
   //      HRGRANT_NBR: "",
   //      HRKOSTL: "",
   //      HRLSTAR: "",
   //      KAPAR: "",
   //      KAPID: "",
   //      KOKRS: "",
   //      LAEDA: null,
   //      LAETM: "",
   //      LGART: "",
   //      LOGSYS: "",
   //      LONGTEXT: "",
   //      LONGTEXT_DATA: "",
   //      LSTAR: "",
   //      LSTNR: "",
   //      LTXA1: "",
   //      MEINH: "",
   //      OFMNW: "0.0",
   //      OTYPE: "",
   //      PAOBJNR: "",
   //      PEDD: "",
   //      PERNR: "",
   //      PLANS: "",
   //      POSID: "",
   //      PRAKN: "",
   //      PRAKZ: "",
   //      PRICE: "0.0",
   //      RAPLZL: "",
   //      RAUFNR: "",
   //      RAUFPL: "",
   //      REASON: "",
   //      REFCOUNTER: "",
   //      REINR: "",
   //      RKDAUF: "",
   //      RKDPOS: "",
   //      RKOSTL: "",
   //      RKSTR: "",
   //      RNPLNR: "",
   //      RPROJ: "",
   //      RPRZNR: "",
   //      SBUDGET_PD: "",
   //      SEBELN: "",
   //      SEBELP: "",
   //      SKOSTL: "",
   //      SPLIT: 0,
   //      SPRZNR: "",
   //      STATKEYFIG: "",
   //      STATUS: "",
   //      S_FUNC_AREA: "",
   //      S_FUND: "",
   //      S_GRANT_NBR: "",
   //      TASKCOMPONENT: "",
   //      TASKCOUNTER: "",
   //      TASKLEVEL: "",
   //      TASKTYPE: "",
   //      TCURR: "",
   //      TRFGR: "",
   //      TRFST: "",
   //      UNIT: "",
   //      UVORN: "",
   //      VERSL: "",
   //      VORNR: "",
   //      VTKEN: "",
   //      WABLNR: "",
   //      WAERS: "",
   //      WERKS: "",
   //      WORKDATE: null,
   //      WORKITEMID: "",
   //      WTART: ""
   //     },
   //     AssignmentId: "",
   //     AssignmentName: "",
   //     AssignmentOperation: "C",
   //     AssignmentStatus: "",
   //     Counter: "",
   //     Pernr: this.empID,
   //     ProfileId: ""
   //    };

   //    for (var i = 0; i < this.byId('FORM_FIELDS').getFormElements().length; i++) {

   //     if (this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue() == "AssignmentName") {
   //      TaskData[this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue()] = this.byId(
   //       'FORM_FIELDS').getFormElements()[i].getFields()[0].getValue();
   //     } else if (this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue() == "Approver" || this.byId(
   //       "FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue() == "Status") {
   //      continue;
   //     } else {
   //      TaskData.AssignmentFields[this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue()] = this
   //       .byId(
   //        'FORM_FIELDS').getFormElements()[i].getFields()[0].getValue();
   //     }
   //    }
   //    this.SubmitTask(TaskData);
   //    oDialog.close();
   //    oDialog.destroy();
   //   }.bind(that),
   //   handleCancel: function(oEvent) {
   //    oDialog.close();
   //    oDialog.destroy();
   //   }.bind(that),
   //   onValueHelp: that.onValueHelp.bind(that)
   //  };
   // create dialog via fragment factory
   // oDialog = sap.ui.xmlfragment(oView.getId(), "hcm.fab.mytimesheet.view.fragments.CreateTask", oDialogController);
   // connect dialog to view (models, lifecycle)
   // oView.addDependent(oDialog);
   // }
   // jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);

   // jQuery.sap.delayedCall(0, this, function() {
   //  // oDialog.open();
   // });
   var oModel = new JSONModel();
   for (var i = 0; i < profileFields.length; i++) {
    // var obj = $.grep(data, function(element, index) {
    //  return element.FieldName == selectedTask[i].getCustomData('FieldName')[0].getValue();
    // });
    if (profileFields[i].FieldName !== "AssignmentName" && profileFields[i].FieldName !== "ValidityStartDate" && profileFields[i].FieldName !==
     "ValidityEndDate") {
     formElements.push(profileFields[i]);
    }
    if (((formElements.length + 1) % 5) === 0 || i === (profileFields.length - 1)) {
     formContainers.push({
      form: $.extend(formElements, [], true)
     });
     formElements = [];
    }
   }
   form.containers = formContainers;
   // form.formElements = formElements;
   oModel.setData(form);
   this.setGlobalModel(oModel, "EditedTask");
   that.byId("idTasks").setBusy(false);
   this.getRouter().navTo("editAssignment", {}, false);
  },

  onTaskDelete: function (oEvent) {
   var that = this;
   this.showBusy();
   var oTable = this.byId('idTasks');
   var data = this.getModel('Tasks').getData();
   var selectedItems = oTable.getSelectedItems();
   var deleteEntries = [];
   for (var i = 0; i < selectedItems.length; i++) {
    var selectedTask = selectedItems[i].getAggregation('cells');
    var AssignmentId = selectedTask[0].getAggregation('customData')[1].getValue();
    var index = selectedItems[i].getBindingContext('TaskFields').getPath().split("/")[1];
    delete data[index].ToGrps;
    data[index].ValidityStartDate = this.oFormatYyyymmdd.format(new Date(data[index].ValidityStartDate)) + "T00:00:00";
    data[index].ValidityEndDate = this.oFormatYyyymmdd.format(new Date(data[index].ValidityEndDate)) + "T00:00:00";
    var oData = $.extend(true, {}, data[index]);
    oData.AssignmentOperation = "D";
    deleteEntries.push(oData);
   }
   // var mParameters = {
   //  success: function (oData, oResponse) {
   //   var toastMsg = that.oBundle.getText("tasksDeletedSuccessfully");
   //   sap.m.MessageToast.show(toastMsg, {
   //    duration: 1000
   //   });
   //   that.getTasks(false);

   //  },
   //  error: function (oError) {
   //   var error = oError;
   //  }
   // };
   // this.oDataModel.create('/AssignmentCollection', oData, mParameters);
   var oModel = $.extend(true, {}, this.oDataModel);
   oModel.setChangeBatchGroups({
    "*": {
     groupId: "TimeEntry",
     changeSetId: "TimeEntry",
     single: false
    }
   });
   oModel.setDeferredGroups(["TimeEntry"]);
   oModel
    .refreshSecurityToken(
     function (oData) {
      for (var i = 0; i < deleteEntries.length; i++) {
       var obj = {
        properties: deleteEntries[i],
        changeSetId: "TimeEntry",
        groupId: "TimeEntry"
       };
       oModel
        .createEntry(
         "/AssignmentCollection",
         obj);
      }
      oModel.submitChanges({
       groupId: "TimeEntry",
       changeSetId: "TimeEntry",
       success: function (oData, res) {
        if (!oData.__batchResponses[0].__changeResponses) {
         // for (var i=0; i<that.batches.length;i++){
         //  that.batches[i].TimeEntryDataFields.WORKDATE = new Date(that.batches[i].TimeEntryDataFields.WORKDATE);
         // }
         that.hideBusy(true);
         return;
        }
        var toastMsg = that.oBundle.getText("tasksDeletedSuccessfully");
        sap.m.MessageToast.show(toastMsg, {
         duration: 1000
        });
        that.getTasks(false);
        that.hideBusy(true);
       },
       error: function (oError) {
        that.hideBusy(true);
        that.oErrorHandler.processError(oError);
       }
      });

     }, true);
   that.hideBusy(true);
  },

  onTaskEdit: function (oEvent) {
   var that = this;
   that.byId("idTasks").setBusy(true);
   var oView = this.getView();
   var oTable = this.byId('idTasks');
   var oModel = new JSONModel();
   var data = this.getModel('ProfileFields').getData();
   var tasks = this.getModel('Tasks').getData();
   var index = oTable.getSelectedItem().getBindingContext('TaskFields').getPath().split("/")[1];
   var formElements = [];
   var formContainers = [];
   var form = {
    name: null,
    status: false,
    containers: null
   };
   var oControl = this.getModel("controls");
   oControl.setProperty('/createAssignment', false);
   oControl.setProperty('/editAssignment', true);
   oControl.setProperty('/editAssignmentCancel', true);
   oControl.setProperty('/displayAssignment', false);
   oControl.setProperty('/displayAssignmentCancel', false);
   oControl.setProperty('/copyAssignment', false);
   oControl.setProperty('/assignmentTitle', this.oBundle.getText("editAssignment"));
   this.setGlobalModel(oControl, "controls");
   var selectedTask = oTable.getSelectedItem().getAggregation('cells');
   var profileFields = $.extend(true, [], this.getModel('ProfileFields').getData());
   // for (var i = 0; i < selectedTask.length; i++) {
   //  var obj = $.grep(data, function(element, index) {
   //   return element.FieldName == selectedTask[i].getCustomData('FieldName')[0].getValue();
   //  });
   //  if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentStatus") {
   //   // obj[0].FieldValue = selectedTask[i].getText();
   //   if (tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()]) {
   //    obj[0].FieldValue = tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()];
   //   } else {
   //    obj[0].FieldValue = selectedTask[i].getText();
   //   }
   //   obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
   //  } else {
   //   obj[0].FieldValue = selectedTask[i].getAggregation('customData')[2].getValue();
   //   obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
   //  }
   // }
   // oModel.setData(data);
   // this.setModel(oModel, "EditedTask");
   // this.setGlobalModel(oModel, "EditedTask");
   for (var i = 0; i < selectedTask.length; i++) {
    var obj = $.grep(data, function (element, index) {
     return element.FieldName == selectedTask[i].getCustomData('FieldName')[0].getValue();
    });
    if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentStatus" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "AssignmentName" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityStartDate" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityEndDate") {
     if (tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()] !== undefined) {
      obj[0].FieldValue = tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()];
     }
     obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
    } else {
     if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentStatus") {
      obj[0].FieldValue = selectedTask[i].getAggregation('customData')[2].getValue();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentName") {
      obj[0].FieldValue = selectedTask[i].getText();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityStartDate") {
      obj[0].FieldValue = selectedTask[i].getText();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityEndDate") {
      obj[0].FieldValue = selectedTask[i].getText();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     }
    }
    if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentName" && selectedTask[i].getCustomData('FieldName')[
      0]
     .getValue() !== "AssignmentStatus" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityStartDate" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityEndDate") {
     formElements.push(obj[0]);
    } else {
     if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentName") {
      form.name = obj[0].FieldValue;
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentStatus") {
      form.status = obj[0].FieldValue;
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityStartDate") {
      form.validFrom = new Date(obj[0].FieldValue);
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityEndDate") {
      form.validTo = new Date(obj[0].FieldValue);
     }
    }
    if (((formElements.length + 1) % 5) === 0 || i === (selectedTask.length - 1)) {
     formContainers.push({
      form: $.extend(formElements, [], true)
     });
     formElements = [];
    }
   }
   // for (var i = 0; i < profileFields.length; i++) {
   //  if (profileFields[i].FieldName !== "AssignmentStatus") {
   //   // if (tasks[index][profileFields[i].FieldName] !== undefined) {
   //    profileFields[i].FieldValue = tasks[index][profileFields[i].FieldName];
   //   // }
   //  }
   //  if (profileFields[i].FieldName !== "AssignmentName" && profileFields[i].FieldName !== "AssignmentStatus") {
   //   formElements.push(profileFields[i]);
   //  } else {
   //   if (profileFields[i].FieldName === "AssignmentName") {
   //    form.name = profileFields[i].FieldValue;
   //   } else {
   //    form.status = profileFields[i].FieldValue;
   //   }
   //  }
   //  if (((i + 1) % 5) === 0 || i === (selectedTask.length - 1)) {
   //   formContainers.push({
   //    form: $.extend(true, [], formElements)
   //   });
   //   formElements = [];
   //  }
   // }
   form.containers = formContainers;
   oModel.setData(form);
   this.setGlobalModel(oModel, "EditedTask");
   // var oDialog;
   // var oDialogController = {
   //  handleConfirm: function(oEvent) {
   //   var TaskData = {
   //    ApproverId: "",
   //    ApproverName: "",
   //    AssignmentFields: {
   //     AENAM: "",
   //     ALLDF: "",
   //     APDAT: null,
   //     APNAM: "",
   //     ARBID: "",
   //     ARBPL: "",
   //     AUERU: "",
   //     AUFKZ: "",
   //     AUTYP: "",
   //     AWART: "",
   //     BEGUZ: "",
   //     BELNR: "",
   //     BEMOT: "",
   //     BUDGET_PD: "",
   //     BUKRS: "",
   //     BWGRL: "0.0",
   //     CATSAMOUNT: "0.0",
   //     CATSHOURS: "0.00",
   //     CATSQUANTITY: "0.0",
   //     CPR_EXTID: "",
   //     CPR_GUID: "",
   //     CPR_OBJGEXTID: "",
   //     CPR_OBJGUID: "",
   //     CPR_OBJTYPE: "",
   //     ENDUZ: "",
   //     ERNAM: "",
   //     ERSDA: null,
   //     ERSTM: "",
   //     ERUZU: "",
   //     EXTAPPLICATION: "",
   //     EXTDOCUMENTNO: "",
   //     EXTSYSTEM: "",
   //     FUNC_AREA: "",
   //     FUND: "",
   //     GRANT_NBR: "",
   //     HRBUDGET_PD: "",
   //     HRCOSTASG: "",
   //     HRFUNC_AREA: "",
   //     HRFUND: "",
   //     HRGRANT_NBR: "",
   //     HRKOSTL: "",
   //     HRLSTAR: "",
   //     KAPAR: "",
   //     KAPID: "",
   //     KOKRS: "",
   //     LAEDA: null,
   //     LAETM: "",
   //     LGART: "",
   //     LOGSYS: "",
   //     LONGTEXT: "",
   //     LONGTEXT_DATA: "",
   //     LSTAR: "",
   //     LSTNR: "",
   //     LTXA1: "",
   //     MEINH: "",
   //     OFMNW: "0.0",
   //     OTYPE: "",
   //     PAOBJNR: "",
   //     PEDD: "",
   //     PERNR: "",
   //     PLANS: "",
   //     POSID: "",
   //     PRAKN: "",
   //     PRAKZ: "",
   //     PRICE: "0.0",
   //     RAPLZL: "",
   //     RAUFNR: "",
   //     RAUFPL: "",
   //     REASON: "",
   //     REFCOUNTER: "",
   //     REINR: "",
   //     RKDAUF: "",
   //     RKDPOS: "",
   //     RKOSTL: "",
   //     RKSTR: "",
   //     RNPLNR: "",
   //     RPROJ: "",
   //     RPRZNR: "",
   //     SBUDGET_PD: "",
   //     SEBELN: "",
   //     SEBELP: "",
   //     SKOSTL: "",
   //     SPLIT: 0,
   //     SPRZNR: "",
   //     STATKEYFIG: "",
   //     STATUS: "",
   //     S_FUNC_AREA: "",
   //     S_FUND: "",
   //     S_GRANT_NBR: "",
   //     TASKCOMPONENT: "",
   //     TASKCOUNTER: "",
   //     TASKLEVEL: "",
   //     TASKTYPE: "",
   //     TCURR: "",
   //     TRFGR: "",
   //     TRFST: "",
   //     UNIT: "",
   //     UVORN: "",
   //     VERSL: "",
   //     VORNR: "",
   //     VTKEN: "",
   //     WABLNR: "",
   //     WAERS: "",
   //     WERKS: "",
   //     WORKDATE: null,
   //     WORKITEMID: "",
   //     WTART: ""
   //    },
   //    AssignmentId: "",
   //    AssignmentName: "",
   //    AssignmentOperation: "U",
   //    AssignmentStatus: "",
   //    Counter: "",
   //    Pernr: this.empID,
   //    ProfileId: ""
   //   };

   //   for (var i = 0; i < this.byId('FORM_FIELDS').getFormElements().length; i++) {
   //    TaskData.AssignmentId = this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[1].getValue();
   //    if (this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue() == "AssignmentName") {
   //     TaskData[this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue()] = this.byId(
   //      'FORM_FIELDS').getFormElements()[i].getFields()[0].getValue();
   //    } else if (this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue() == "Approver" || this.byId(
   //      "FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue() == "Status") {
   //     continue;
   //    } else {
   //     TaskData.AssignmentFields[this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue()] = this
   //      .byId(
   //       'FORM_FIELDS').getFormElements()[i].getFields()[0].getValue();
   //    }
   //   }
   //   TaskData.AssignmentId = this.byId("FORM_FIELDS").getFormElements()[0].getFields()[0].getCustomData()[1].getValue();
   //   this.UpdateTask(TaskData);
   //   oDialog.close();
   //   oDialog.destroy();
   //  }.bind(this),
   //  handleCancel: function() {
   //   oDialog.close();
   //   oDialog.destroy();
   //  }.bind(this)
   // };
   // if (!oDialog) {
   //  // create dialog via fragment factory
   //  oDialog = sap.ui.xmlfragment(oView.getId(), "hcm.fab.mytimesheet.view.fragments.EditTask", oDialogController);
   //  // connect dialog to view (models, lifecycle)
   //  oView.addDependent(oDialog);
   // }
   // jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);

   // jQuery.sap.delayedCall(0, this, function() {
   //  oDialog.open();
   // });
   that.byId("idTasks").setBusy(false);
   this.getRouter().navTo("editAssignment", {}, false);
  },
  onTaskSelection: function (oEvent) {
   var oControl = this.getModel("controls");
   // var oSelectedItems = oEvent.getParameter("selectedContexts");
   if (oEvent.getParameters().listItem.getSelected() === true && this.oTaskTable.getSelectedItems().length == 1) {
    oControl.setProperty("/taskEdit", true);
    oControl.setProperty("/taskDelete", true);
    oControl.setProperty("/taskCopy", true);
    oControl.setProperty("/createGroupButton", true);
   } else if (this.oTaskTable.getSelectedItems().length == 1) {
    oControl.setProperty("/taskEdit", true);
    oControl.setProperty("/taskDelete", true);
    oControl.setProperty("/taskCopy", true);
    oControl.setProperty("/createGroupButton", true);
   } else {
    oControl.setProperty("/taskEdit", false);
    oControl.setProperty("/taskDelete", true);
    oControl.setProperty("/taskCopy", false);
    oControl.setProperty("/createGroupButton", true);
   }
  },
  deleteSelectedDays: function (oEvent) {
   var index = oEvent.getParameters().listItem.getBindingContext('selectedDatesDup').getPath().split('/selectedDates/')[1];
   var data = this.getModel('selectedDatesDup').getData();
   // this.byId("duplicateCalendar").removeSelectedDate(new sap.ui.unified.DateRange({startDate:data.selectedDates[index].Date}));
   // this.byId("mDuplicateCalendar").removeSelectedDate(new sap.ui.unified.DateRange({startDate:data.selectedDates[index].Date}));
   this.byId("duplicateCalendar").removeAllSelectedDates();
   this.byId("mDuplicateCalendar").removeAllSelectedDates();
   delete data.selectedDates[index].Date;
   data.selectedDates.splice(index, 1);
   for (var i = 0; i < data.selectedDates.length; i++) {
    this.byId("duplicateCalendar").addSelectedDate(new sap.ui.unified.DateRange({
     startDate: data.selectedDates[i].Date
    }));
    this.byId("mDuplicateCalendar").addSelectedDate(new sap.ui.unified.DateRange({
     startDate: data.selectedDates[i].Date
    }));
   }
   var oModel = new JSONModel(data);
   this.setModel(oModel, 'selectedDatesDup');

  },
  onDuplicateTask: function (oEvent) {
   var that = this;
   var oView = this.getView();
   var oTable = this.byId('idTasks');
   var oModel = new JSONModel();
   var oDialog;
   var oDialogController = {
    handleCancel: function () {
     oDialog.close();
     oDialog.destroy();
     this.setModel(new JSONModel({
      selectedDates: []
     }), "selectedDatesDup");
     this.setModel(new JSONModel([]), "TimeDataDuplicateTask");
     this.getModel("controls").setProperty("/duplicateTaskButtonEnable", false);
    }.bind(this),
    onSelect: this.handleDupTaskCalendarSelect.bind(this),
    onDelete: this.deleteSelectedDays.bind(this),
    onOverviewSelect: this.onOverviewSelectDup.bind(this),
    handleConfirm: function () {
     var sucess = this.handleDuplicateTaskConfirm();
     if (sucess) {
      oDialog.close();
      oDialog.destroy();
      this.calendar.removeAllSelectedDates();
      this.setModel(new JSONModel({
       selectedDates: []
      }), "selectedDatesDup");
      this.setModel(new JSONModel([]), "TimeDataDuplicateTask");
      var toastMsg = that.oBundle.getText("duplicatedSuccessfully");
      sap.m.MessageToast.show(toastMsg, {
       duration: 3000
      });
      this.getModel("controls").setProperty("/overviewDataChanged", true);
      this.getModel("controls").setProperty("/isOverviewChanged", true);
      this.getModel("controls").setProperty("/duplicateTaskButtonEnable", false);
     }

    }.bind(this),
    dayOfWeek: this.formatter.dayOfWeek.bind(this),

   };
   if (!oDialog) {
    // create dialog via fragment factory
    oDialog = sap.ui.xmlfragment(oView.getId(), "hcm.fab.mytimesheet.view.fragments.DuplicateTask", oDialogController);
    // oDialog.bindElement('TimeDataDuplicateTask>/0');
    // connect dialog to view (models, lifecycle)
    oView.addDependent(oDialog);
   }
   jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);

   jQuery.sap.delayedCall(0, this, function () {
    oDialog.open();
   });

  },
  onDuplicateWeek: function (oEvent) {
   var that = this;
   var oView = this.getView();
   var oTable = this.byId('idTasks');
   var oModel = new JSONModel();
   var oDialog;
   var oDialogController = {
    handleCancel: function () {
     oDialog.close();
     oDialog.destroy();
     this.setModel(new JSONModel({
      selectedWeek: []
     }), "selectedDatesDupWeek");
     this.getModel('controls').setProperty("/duplicateWeekButtonEnable", false);
    }.bind(this),
    concatDates: this.formatter.concatDates.bind(this),
    onDelete: this.deleteSelectedWeeks.bind(this),
    handleDuplicateWeekCalendar: this.handleDuplicateWeekCalendar.bind(this),
    dayOfWeek: this.formatter.dayOfWeek.bind(this),
    handleConfirm: function (oEvent) {
     var sucess = this.handleConfirmDuplicateWeek(oEvent);
     if (sucess) {
      oDialog.close();
      oDialog.destroy();
      this.calendar.removeAllSelectedDates();
      this.setModel(new JSONModel({
       selectedWeek: []
      }), "selectedDatesDupWeek");
      var toastMsg = that.oBundle.getText("duplicatedSuccessfully");
      sap.m.MessageToast.show(toastMsg, {
       duration: 3000
      });
      this.getModel("controls").setProperty("/overviewDataChanged", true);
      this.getModel("controls").setProperty("/isOverviewChanged", true);
     }
    }.bind(this)

   };
   if (!oDialog) {
    // create dialog via fragment factory
    oDialog = sap.ui.xmlfragment(oView.getId(), "hcm.fab.mytimesheet.view.fragments.DuplicateWeek", oDialogController);
    // connect dialog to view (models, lifecycle)
    oView.addDependent(oDialog);
   }
   jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);

   jQuery.sap.delayedCall(0, this, function () {
    oDialog.open();
   });

  },
  deleteSelectedWeeks: function (oEvent) {
   var index = oEvent.getParameters().listItem.getBindingContext('selectedDatesDupWeek').getPath().split('/selectedWeek/')[1];
   var data = this.getModel('selectedDatesDupWeek').getData();
   delete data.selectedWeek[index].dateFrom;
   data.selectedWeek.splice(index, 1);
   var oModel = new JSONModel(data);
   this.setModel(oModel, 'selectedDatesDupWeek');
  },
  handleConfirmDuplicateWeek: function (oEvent) {
   var data = $.extend(true, [], this.getModel('TimeData').getData());
   var timeFrom = new Date(this.oFormatYyyymmdd.format(data[0].TimeEntryDataFields.WORKDATE) + "T00:00:00");
   var timeTo = new Date(this.oFormatYyyymmdd.format(data[data.length - 1].TimeEntryDataFields.WORKDATE) + "T00:00:00");
   if (this.getModel('selectedDatesDupWeek') && this.getModel('selectedDatesDupWeek').getData().selectedWeek.length > 0) {
    var dates = this.getModel('selectedDatesDupWeek').getData().selectedWeek;
   } else {
    var toastMsg = this.oBundle.getText("selectWeekDup");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
    return false;
   }
   var oModel = new JSONModel();
   var WeekData = [];
   for (var k = new Date(timeFrom); k <= timeTo; k.setDate(k.getDate() + 1)) {
    var entries = $.grep(data, function (element, index) {
     return element.TimeEntryDataFields.WORKDATE.toDateString() === k.toDateString();
    });
    var day = {
     day: entries
    };
    WeekData.push(day);
   }
   for (var i = 0; i < dates.length; i++) {
    for (var j = new Date(dates[i].dateFrom), k = 0; j <= dates[i].dateTo, k < 7; j.setDate(
      j.getDate() + 1, k++)) {
     for (var m = 0; m < WeekData[k].day.length; m++) {
      var entry = $.extend(true, {}, WeekData[k].day[m]);
      entry.TimeEntryDataFields.WORKDATE = new Date(j);
      entry.Counter = "";
      entry.TimeEntryDataFields.STATUS = "";
      entry.TimeEntryDataFields.LONGTEXT = "";
      entry.TimeEntryDataFields.LONGTEXT_DATA = "";
      entry.TimeEntryDataFields.REFCOUNTER = "";
      entry.HeaderData.date = new Date(j);
      entry.highlight = sap.ui.core.MessageType.Information;
      entry.HeaderData.highlight = sap.ui.core.MessageType.Information;
      // entry.HeaderData.addButton = true;
      if (entry.TimeEntryDataFields.CATSHOURS !== "0.00") {
       entry.TimeEntryOperation = "C";
      }
      data.push(entry);

     }
    }
   }
   oModel.setData(data);
   this.setModel(oModel, "TimeData");
   this.oTable.bindItems({
    path: 'TimeData>/',
    sorter: [new sap.ui.model.Sorter("HeaderData", false, true, this.compareRows)],
    template: this.oEditableTemplate,
    templateShareable: true,
    groupHeaderFactory: this.getGroupHeader.bind(this)
   }).setKeyboardMode('Edit');
   this.getModel('controls').setProperty("/duplicateWeekButtonEnable", false);
   return true;
  },
  handleDuplicateWeekCalSelect: function (oEvent) {
   var oCalendar = oEvent.getSource();
   var aSelectedDates = oCalendar.getSelectedDates();
   var oDate;
   var oData = {
    selectedDates: []
   };
   var oModel = new JSONModel();
   if (aSelectedDates.length > 0) {
    for (var i = 0; i < aSelectedDates.length; i++) {
     oDate = aSelectedDates[i].getStartDate();
     oData.selectedDates.push({
      Date: oDate
     });
    }
    oModel.setData(oData);
    this.setModel(oModel, 'selectedDatesDup');
   } else {
    // this._clearModel();
   }
  },
  onOverviewSelect: function (oEvent) {
   var that = this;
   var selectedItem = oEvent;
   var oControl = this.getModel('controls');
   var data = this.getModel('TimeData');
   var oModel = new JSONModel();
   var index = null;
   var data = this.getModel('TimeData').getData();
   var taskModel = this.getModel('TimeDataDuplicateTask');
   var task = [];
   if (oEvent.getParameters().listItem.getBindingContext('TimeData')) {
    index = oEvent.getParameters().listItem.getBindingContext('TimeData').getPath().split('/')[1];
    data[index].TimeEntryOperation = "";
    var previousSelected = $.grep(data, function (element, ind) {
     return element.TimeEntryOperation == 'R';
    });
    for (var i = 0; i < previousSelected.length; i++) {
     previousSelected[i].TimeEntryOperation = "";
    }
   }
   if (this.oTable.getSelectedItems().length >= 1) {
    var selected = this.oTable.getSelectedContextPaths();
    for (var i = 0; i < selected.length; i++) {
     if (data[selected[i].split('/')[1]].Counter !==
      null && data[selected[i].split('/')[1]].Counter && data[selected[i].split('/')[1]].Counter !== "" || (parseFloat(data[selected[
        i]
       .split('/')[1]].TimeEntryDataFields.CATSHOURS).toFixed(2) !== parseFloat("0.00").toFixed(2) || parseFloat(data[selected[i].split(
       '/')[1]].TimeEntryDataFields.CATSQUANTITY).toFixed(2) !== parseFloat("0.00").toFixed(2) || parseFloat(data[selected[i].split(
       '/')[1]].TimeEntryDataFields.CATSAMOUNT).toFixed(2) !== parseFloat("0.00").toFixed(2))) {
      data[selected[i].split('/')[1]].TimeEntryOperation = "R";
      task.push($.extend(true, {}, data[selected[i].split('/')[1]]));
      // oControl.setProperty('/duplicateTaskEnable', true);
     }
    }
   } else {
    // oControl.setProperty('/duplicateTaskEnable', false);
    // oControl.setProperty('/duplicateWeekEnable', true);
   }
   oModel.setData(task);
   this.setModel(oModel, 'TimeDataDuplicateTask');
   that.calculateChangeCount();
  },
  onOverviewSelectDup: function (oEvent) {
   var that = this;
   var selectedItem = oEvent;
   var oControl = this.getModel('controls');
   var data = this.getModel('TimeData');
   var oModel = new JSONModel();
   var index = null;
   var data = this.getModel('TimeData').getData();
   var taskModel = this.getModel('TimeDataDuplicateTask');
   var task = [];
   // if (oEvent.getParameters().listItem.getBindingContext('TimeData')) {
   //  index = oEvent.getParameters().listItem.getBindingContext('TimeData').getPath().split('/')[1];
   //  data[index].TimeEntryOperation = "";
   //  var previousSelected = $.grep(data, function (element, ind) {
   //   return element.TimeEntryOperation == 'R';
   //  });
   //  for (var i = 0; i < previousSelected.length; i++) {
   //   previousSelected[i].TimeEntryOperation = "";
   //  }
   // }
   if (oEvent.getSource().getSelectedItems().length >= 1) {
    // oControl.setProperty('/duplicateTaskEnable', true);
    var selected = oEvent.getSource().getSelectedContextPaths();
    for (var i = 0; i < selected.length; i++) {
     // if (data[selected[i].split('/')[1]].Counter !==
     //  null && data[selected[i].split('/')[1]].Counter && data[selected[i].split('/')[1]].Counter !== "" || (parseFloat(data[selected[
     //    i]
     //   .split('/')[1]].TimeEntryDataFields.CATSHOURS).toFixed(2) !== parseFloat("0.00").toFixed(2) || parseFloat(data[selected[i].split(
     //   '/')[1]].TimeEntryDataFields.CATSQUANTITY).toFixed(2) !== parseFloat("0.00").toFixed(2) || parseFloat(data[selected[i].split(
     //   '/')[1]].TimeEntryDataFields.CATSAMOUNT).toFixed(2) !== parseFloat("0.00").toFixed(2))) {
     // data[selected[i].split('/')[1]].TimeEntryOperation = "R";
     task.push($.extend(true, {}, data[selected[i].split('/')[1]]));
     // oControl.setProperty('/duplicateTaskEnable', true);
     // }
    }
   } else {
    // oControl.setProperty('/duplicateTaskEnable', false);
    // oControl.setProperty('/duplicateWeekEnable', true);
   }
   oModel.setData(task);
   this.setModel(oModel, 'TimeDataDuplicateTask');
   if (this.getModel("selectedDatesDup").getData().selectedDates.length >= 1) {
    this.getModel("controls").setProperty("/duplicateTaskButtonEnable", true);
   }
   // that.calculateChangeCount();
  },
  handleDuplicateTaskConfirm: function () {
   if (this.getModel("TimeDataDuplicateTask") && this.getModel("TimeDataDuplicateTask").getData().length > 0) {
    var oModel = this.getModel("TimeDataDuplicateTask");
   } else {
    var toastMsg = this.oBundle.getText("selectRecordDup");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
    return false;
   }
   if (this.getModel("selectedDatesDup") && this.getModel("selectedDatesDup").getData().selectedDates.length > 0) {
    var dates = this.getModel("selectedDatesDup").getData();
   } else {
    var toastMsg = this.oBundle.getText("selectDatesDup");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
    return false;
   }

   var timeData = this.getModel("TimeData").getData();
   for (var i = 0; i < dates.selectedDates.length; i++) {
    var data = $.extend(true, [], oModel.getData());
    for (var j = 0; j < data.length; j++) {
     data[j].TimeEntryDataFields.WORKDATE = new Date(dates.selectedDates[i].Date);
     data[j].Counter = "";
     data[j].TimeEntryOperation = 'C';
     data[j].TimeEntryDataFields.STATUS = "";
     data[j].TimeEntryDataFields.LONGTEXT = "";
     data[j].TimeEntryDataFields.LONGTEXT_DATA = "";
     data[j].HeaderData.date = new Date(dates.selectedDates[i].Date);
     data[j].highlight = sap.ui.core.MessageType.Information;
     data[j].HeaderData.highlight = sap.ui.core.MessageType.Information;
     data[j].HeaderData.addButton = false;
     data[j].addButton = false;
     if (j == 0) {
      var select = $.grep(timeData, function (element, ind) {
       return element.TimeEntryDataFields.WORKDATE.toDateString() === data[j].TimeEntryDataFields.WORKDATE.toDateString();
      });
      if (select.length === 0) {
       data[j].HeaderData.addButton = true;
       data[j].addButton = true;
      }
     }

     timeData.push(data[j]);
    }
   }
   oModel.setData(timeData);
   this.setModel(oModel, "TimeData");
   this.oTable.bindItems({
    path: 'TimeData>/',
    sorter: [new sap.ui.model.Sorter("HeaderData", false, true, this.compareRows)],
    template: this.oEditableTemplate,
    templateShareable: true,
    groupHeaderFactory: this.getGroupHeader.bind(this)
   }).setKeyboardMode('Edit');
   // oTable.bindItems({
   //  path: sPath,
   //  sorter: [new sap.ui.model.Sorter("HeaderData", false, true, this.compareRows)],
   //  template: oTemplate,
   //  templateShareable: true,
   //  groupHeaderFactory: this.getGroupHeader.bind(this)
   // }).setKeyboardMode(sKeyboardMode);
   return true;
  },
  onAssignmentQuickView: function (oEvent) {
   var that = this;
   var index = oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1];
   var timeData = this.getModel('TimeData').getData();
   var profileData = this.getModel('ProfileFields').getData();
   var data = [{
    label: this.oBundle.getText("name"),
    value: timeData[index].AssignmentName
   }];
   var item;
   var element = {
    label: null,
    value: null
   };
   profileData.forEach(function (item, ind) {
    var oModel = that.getModel(item.FieldName);
    if (oModel) {
     var text = oModel.getData();
    }
    if (item.FieldName !== "AssignmentStatus" && item.FieldName !== "APPROVER" && item.FieldName !== "AssignmentName" && item.FieldName !==
     "ValidityStartDate" && item.FieldName !== "ValidityEndDate") {
     element.label = item.FieldLabel;
     var fieldValue = timeData[index].TimeEntryDataFields[item.FieldName];
     if (text) {
      var textFound = $.grep(text, function (element, ind) {
       return element.DispField1Id === fieldValue;
      });
      if (textFound.length && textFound.length > 0) {
       element.value = timeData[index].TimeEntryDataFields[item.FieldName] + "  " + textFound[0].DispField1Val;
      } else {
       element.value = timeData[index].TimeEntryDataFields[item.FieldName];
      }
     } else {
      element.value = timeData[index].TimeEntryDataFields[item.FieldName];
     }
     // element.value = textFound[0].FieldValue + "(" + timeData[index].TimeEntryDataFields[item.FieldName] + ")";
     item = $.extend(true, {}, element);
     data.push(item);
    }
   });
   var oModel = new JSONModel(data);
   this.setModel(oModel, "TimeDataDetail");
   var oDialog;
   if (oDialog) {
    oDialog.close();
   }
   var oDialogController = {
    handleClose: function (event) {
     oDialog.close();
    }
   };
   if (!oDialog) {
    oDialog = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.AssignmentQuickView",
     oDialogController);
    this.getView().addDependent(oDialog);
    // oDialog.bindElement('TimeData>' + oEvent.getSource().getBindingContext('TimeData').getPath());
   }

   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   var oButton = oEvent.getSource();
   jQuery.sap.delayedCall(0, this, function () {
    oDialog.openBy(oButton);
   });
  },
  UpdateTask: function (TaskData) {
   var that = this;
   var oModel = new JSONModel();
   var mParameters = {
    success: function (oData, oResponse) {
     var data = oData.results;
    },
    error: function (oError) {
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.create('/AssignmentCollection', TaskData, mParameters);
  },
  SubmitTask: function (TaskData) {
   var that = this;
   var oModel = new JSONModel();
   var mParameters = {
    success: function (oData, oResponse) {
     var data = oData.results;
     var toastMsg = that.oBundle.getText("taskSaved");
     sap.m.MessageToast.show(toastMsg, {
      duration: 1000
     });
     that.getTasks(false);
    },
    error: function (oError) {
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.create('/AssignmentCollection', TaskData, mParameters);
   // this.oDataModel.submitChanges();
  },

  iconTabSelection: function (oEvent) {
   var oControl = this.getModel('controls');
   // if (oEvent.getParameter('selectedKey') == "overview") {
   //  oControl.setProperty('/showFooter', false);
   //  // oControl.setProperty('/todoCancel', false);
   //  oControl.setProperty('/overviewEdit', true);
   //  oControl.setProperty('/editTodoVisibility', true);
   //  oControl.setProperty('/duplicateVisibility', false);
   //  oControl.setProperty('/duplicateWeekVisibility', false);
   //  // oControl.setProperty('/todoDone', false);
   //  if (this.oReadOnlyToDoTemplate) {
   //   this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
   //   oControl.setProperty('/showFooter', false);
   //  }
   // } else if (oEvent.getParameter('selectedKey') == "todolist") {
   //  // oControl.setProperty('/overviewCancel', false);
   //  // oControl.setProperty('/sendForApproval', false);
   //  // oControl.setProperty('/submitDraft', false);
   //  oControl.setProperty('/showFooter', false);
   //  // oControl.setProperty('/todoDone', false);
   //  // oControl.setProperty('/editTodoVisibility', true);
   //  oControl.setProperty('/onEdit', "None");
   //  oControl.setProperty('/duplicateVisibility', false);
   //  oControl.setProperty('/duplicateWeekVisibility', false);
   //  // oControl.setProperty('/showFooter', false);
   //  if (this.oReadOnlyTemplate) {
   //   this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
   //   oControl.setProperty('/showFooter', false);
   //  }

   // } else if (oEvent.getParameter('selectedKey') == "tasks") {
   //  oControl.setProperty('/showFooter', false);
   //  // oControl.setProperty('/overviewCancel', false);
   //  // oControl.setProperty('/sendForApproval', false);
   //  // oControl.setProperty('/submitDraft', false);
   //  // oControl.setProperty('/todoDone', false);
   //  oControl.setProperty('/onEdit', "None");
   //  if (this.oReadOnlyTemplate) {
   //   this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
   //   oControl.setProperty('/showFooter', false);
   //  }

   //  // oControl.setProperty('/todoCancel', false);
   //  oControl.setProperty('/overviewEdit', true);
   //  // if (!sap.ui.Device.system.phone) {
   //  oControl.setProperty('/editTodoVisibility', true);
   //  // }
   //  oControl.setProperty('/duplicateVisibility', false);
   //  oControl.setProperty('/duplicateWeekVisibility', false);
   //  // oControl.setProperty('/todoDone', false);
   //  if (this.oReadOnlyToDoTemplate) {
   //   this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
   //  }
   //  oControl.setProperty('/showFooter', false);
   // } else {
   //  oControl.setProperty('/showFooter', false);
   //  // oControl.setProperty('/overviewCancel', false);
   //  // oControl.setProperty('/sendForApproval', false);
   //  // oControl.setProperty('/submitDraft', false);
   //  // oControl.setProperty('/todoDone', false);
   //  oControl.setProperty('/onEdit', "None");
   //  if (this.oReadOnlyTemplate) {
   //   this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
   //   oControl.setProperty('/showFooter', false);
   //  }

   //  // oControl.setProperty('/todoCancel', false);
   //  oControl.setProperty('/overviewEdit', true);
   //  // if (!sap.ui.Device.system.phone) {
   //  oControl.setProperty('/editTodoVisibility', true);
   //  // }
   //  oControl.setProperty('/duplicateVisibility', false);
   //  oControl.setProperty('/duplicateWeekVisibility', false);
   //  // oControl.setProperty('/todoDone', false);
   //  if (this.oReadOnlyToDoTemplate) {
   //   this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
   //  }
   //  oControl.setProperty('/showFooter', false);
   // }
   // this.setModel(oControl, "controls");
   // Code after

   // var oControl = this.getModel('controls');
   // if (oEvent.getParameter('section').getId().split("worklist--")[1] == "overview") {
   //  oControl.setProperty('/showFooter', false);
   //  // oControl.setProperty('/todoCancel', false);
   //  oControl.setProperty('/overviewEdit', true);
   //  oControl.setProperty('/editTodoVisibility', true);
   //  oControl.setProperty('/duplicateVisibility', false);
   //  oControl.setProperty('/duplicateWeekVisibility', false);
   //  // oControl.setProperty('/todoDone', false);
   //  if (this.oReadOnlyToDoTemplate) {
   //   this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
   //   oControl.setProperty('/showFooter', false);
   //  }
   // } else if (oEvent.getParameter('section').getId().split("worklist--")[1] == "todolist") {
   //  // oControl.setProperty('/overviewCancel', false);
   //  // oControl.setProperty('/sendForApproval', false);
   //  // oControl.setProperty('/submitDraft', false);
   //  oControl.setProperty('/showFooter', false);
   //  // oControl.setProperty('/todoDone', false);
   //  // oControl.setProperty('/editTodoVisibility', true);
   //  oControl.setProperty('/onEdit', "None");
   //  oControl.setProperty('/duplicateVisibility', false);
   //  oControl.setProperty('/duplicateWeekVisibility', false);
   //  // oControl.setProperty('/showFooter', false);
   //  if (this.oReadOnlyTemplate) {
   //   this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
   //   oControl.setProperty('/showFooter', false);
   //  }

   // } else if (oEvent.getParameter('section').getId().split("worklist--")[1] == "tasks") {
   //  oControl.setProperty('/showFooter', false);
   //  // oControl.setProperty('/overviewCancel', false);
   //  // oControl.setProperty('/sendForApproval', false);
   //  // oControl.setProperty('/submitDraft', false);
   //  // oControl.setProperty('/todoDone', false);
   //  oControl.setProperty('/onEdit', "None");
   //  if (this.oReadOnlyTemplate) {
   //   this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
   //   oControl.setProperty('/showFooter', false);
   //  }

   //  // oControl.setProperty('/todoCancel', false);
   //  oControl.setProperty('/overviewEdit', true);
   //  // if (!sap.ui.Device.system.phone) {
   //  oControl.setProperty('/editTodoVisibility', true);
   //  // }
   //  oControl.setProperty('/duplicateVisibility', false);
   //  oControl.setProperty('/duplicateWeekVisibility', false);
   //  // oControl.setProperty('/todoDone', false);
   //  if (this.oReadOnlyToDoTemplate) {
   //   this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
   //  }
   //  oControl.setProperty('/showFooter', false);
   // } else {
   //  oControl.setProperty('/showFooter', false);
   //  // oControl.setProperty('/overviewCancel', false);
   //  // oControl.setProperty('/sendForApproval', false);
   //  // oControl.setProperty('/submitDraft', false);
   //  // oControl.setProperty('/todoDone', false);
   //  oControl.setProperty('/onEdit', "None");
   //  if (this.oReadOnlyTemplate) {
   //   this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
   //   oControl.setProperty('/showFooter', false);
   //  }

   //  // oControl.setProperty('/todoCancel', false);
   //  oControl.setProperty('/overviewEdit', true);
   //  // if (!sap.ui.Device.system.phone) {
   //  oControl.setProperty('/editTodoVisibility', true);
   //  // }
   //  oControl.setProperty('/duplicateVisibility', false);
   //  oControl.setProperty('/duplicateWeekVisibility', false);
   //  // oControl.setProperty('/todoDone', false);
   //  if (this.oReadOnlyToDoTemplate) {
   //   this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
   //  }
   //  oControl.setProperty('/showFooter', false);
   // }
   // this.setModel(oControl, "controls");
   var that = this;
   var messageHeader = that.oBundle.getText("confirmationSwitchTab");
   var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
   if (this.filterAppliedFlag === "X" && oEvent.getParameter('section').getId().split("worklist--")[1] !== "tasks") {
    sap.m.MessageBox.warning(
     messageHeader, {
      title: that.oBundle.getText("confirm"),
      actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
      styleClass: bCompact ? "sapUiSizeCompact" : "",
      onClose: function (sAction) {
       if (sAction === "CANCEL") {
        // that.byId("ObjectPageLayout").setSelectedSection("application-MyTimesheet-display-component---worklist--tasks");
        that.byId("ObjectPageLayout").setSelectedSection(that.byId("ObjectPageLayout").getSections()[2].getId());
        return;
       } else {
        that.filterAppliedFlag = "";
        that.getTasks(false);
        sap.ui.getCore().getMessageManager().removeAllMessages();
        this.iconTabSelectionProcessing(oEvent.getParameter('section').getId().split("worklist--")[1]);
       }
      }
     }

    );
   }
   if ((oControl.getProperty("/isOverviewChanged") || oControl.getProperty("/overviewDataChanged")) && oEvent.getParameter('section').getId()
    .split("worklist--")[1] !== "overview") {
    sap.m.MessageBox.warning(
     that.oBundle.getText("confirmationSwitchTabGeneral"), {
      title: that.oBundle.getText("confirm"),
      actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
      styleClass: bCompact ? "sapUiSizeCompact" : "",
      onClose: function (sAction) {
       if (sAction === "CANCEL") {
        // that.byId("ObjectPageLayout").setSelectedSection("application-MyTimesheet-display-component---worklist--tasks");
        that.byId("ObjectPageLayout").setSelectedSection(that.byId("ObjectPageLayout").getSections()[0].getId());
        return;
       } else {
        that.onCancel();

        sap.ui.getCore().getMessageManager().removeAllMessages();
        this.iconTabSelectionProcessing(oEvent.getParameter('section').getId().split("worklist--")[1]);
       }
      }
     }

    );
   } else if (!(oControl.getProperty("/isOverviewChanged") || oControl.getProperty("/overviewDataChanged")) && oEvent.getParameter(
     'section').getId().split("worklist--")[1] !== "overview") {
    that.onCancel();
    if (oControl.getProperty("/isToDoChanged") || oControl.getProperty("/todoDataChanged")) {
     oControl.setProperty("/showFooter", true);
    }
    // this.iconTabSelectionProcessing(oEvent.getParameter('section').getId().split("worklist--")[1]);
   }
   if ((oControl.getProperty("/isToDoChanged") || oControl.getProperty("/todoDataChanged")) && oEvent.getParameter('section').getId()
    .split(
     "worklist--")[1] !== "todolist") {
    sap.m.MessageBox.warning(
     that.oBundle.getText("confirmationSwitchTabGeneral"), {
      title: that.oBundle.getText("confirm"),
      actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
      styleClass: bCompact ? "sapUiSizeCompact" : "",
      onClose: function (sAction) {
       if (sAction === "CANCEL") {
        that.byId("ObjectPageLayout").setSelectedSection(that.byId("ObjectPageLayout").getSections()[1].getId());
        return;
       } else {
        that.onTodoCancel();
        oControl.setProperty("/isToDoChanged", false);
        oControl.setProperty("/todoDataChanged", false);
        sap.ui.getCore().getMessageManager().removeAllMessages();
        this.iconTabSelectionProcessing(oEvent.getParameter('section').getId().split("worklist--")[1]);
       }
      }
     }

    );
   } else if (!(oControl.getProperty("/isToDoChanged") || oControl.getProperty("/todoDataChanged")) && oEvent.getParameter('section')
    .getId()
    .split(
     "worklist--")[1] !== "todolist") {
    that.onTodoCancel();
    oControl.setProperty("/isToDoChanged", false);
    oControl.setProperty("/todoDataChanged", false);
    if (oControl.getProperty("/isOverviewChanged") || oControl.getProperty("/overviewDataChanged")) {
     oControl.setProperty("/showFooter", true);
    }
    // this.iconTabSelectionProcessing(oEvent.getParameter('section').getId().split("worklist--")[1]);
   }
   // this.iconTabSelectionProcessing(oEvent.getParameter('section').getId().split("worklist--")[1]);
  },
  iconTabSelectionProcessing: function (section) {
   var oControl = this.getModel('controls');
   if (section == "overview") {
    oControl.setProperty('/showFooter', false);
    // oControl.setProperty('/todoCancel', false);
    oControl.setProperty('/overviewEdit', true);
    oControl.setProperty('/editTodoVisibility', true);
    oControl.setProperty('/duplicateVisibility', false);
    oControl.setProperty('/duplicateWeekVisibility', false);
    // oControl.setProperty('/todoDone', false);
    if (this.oReadOnlyToDoTemplate) {
     this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
     oControl.setProperty('/showFooter', false);
    }
   } else if (section == "todolist") {
    // oControl.setProperty('/overviewCancel', false);
    // oControl.setProperty('/sendForApproval', false);
    // oControl.setProperty('/submitDraft', false);
    oControl.setProperty('/showFooter', false);
    // oControl.setProperty('/todoDone', false);
    // oControl.setProperty('/editTodoVisibility', true);
    oControl.setProperty('/onEdit', "None");
    oControl.setProperty('/duplicateVisibility', false);
    oControl.setProperty('/duplicateWeekVisibility', false);
    // oControl.setProperty('/showFooter', false);
    if (this.oReadOnlyTemplate) {
     this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
     oControl.setProperty('/showFooter', false);
    }

   } else if (section == "tasks") {
    oControl.setProperty('/showFooter', false);
    // oControl.setProperty('/overviewCancel', false);
    // oControl.setProperty('/sendForApproval', false);
    // oControl.setProperty('/submitDraft', false);
    // oControl.setProperty('/todoDone', false);
    oControl.setProperty('/onEdit', "None");
    if (this.oReadOnlyTemplate) {
     this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
     oControl.setProperty('/showFooter', false);
    }

    // oControl.setProperty('/todoCancel', false);
    oControl.setProperty('/overviewEdit', true);
    // if (!sap.ui.Device.system.phone) {
    oControl.setProperty('/editTodoVisibility', true);
    // }
    oControl.setProperty('/duplicateVisibility', false);
    oControl.setProperty('/duplicateWeekVisibility', false);
    // oControl.setProperty('/todoDone', false);
    if (this.oReadOnlyToDoTemplate) {
     this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
    }
    oControl.setProperty('/showFooter', false);
   } else {
    oControl.setProperty('/showFooter', false);
    // oControl.setProperty('/overviewCancel', false);
    // oControl.setProperty('/sendForApproval', false);
    // oControl.setProperty('/submitDraft', false);
    // oControl.setProperty('/todoDone', false);
    oControl.setProperty('/onEdit', "None");
    if (this.oReadOnlyTemplate) {
     this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
     oControl.setProperty('/showFooter', false);
    }

    // oControl.setProperty('/todoCancel', false);
    oControl.setProperty('/overviewEdit', true);
    // if (!sap.ui.Device.system.phone) {
    oControl.setProperty('/editTodoVisibility', true);
    // }
    oControl.setProperty('/duplicateVisibility', false);
    oControl.setProperty('/duplicateWeekVisibility', false);
    // oControl.setProperty('/todoDone', false);
    if (this.oReadOnlyToDoTemplate) {
     this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oReadOnlyToDoTemplate, "Navigation");
    }
    oControl.setProperty('/showFooter', false);
   }
   this.setModel(oControl, "controls");
  },
  onValueHelp: function (oEvent) {
   var that = this;
   var FieldName = oEvent.getSource().getCustomData('FieldName')[0].getValue();
   new Promise(
    function (fnResolve, fnReject) {
     that.getValueHelpCollection(FieldName);
     fnResolve(that.valueHelpFragment());
     fnReject();
    }
   );
  },
  valueHelpFragment: function () {
   var that = this;
   var that = this;
   var oView = this.getView();
   // create dialog lazily
   var oDialog;
   if (!oDialog) {
    var oDialogController = {
     handleConfirm: that.handleClick.bind(that),
     handleCancel: function (oEvent) {
      // oDialog.close();
      oDialog.destroy();
     }.bind(that),
     onValueHelp: that.onValueHelp.bind(that),
     handleClickValueHelp: that.handleClick.bind(that)
    };
    // create dialog via fragment factory
    oDialog = sap.ui.xmlfragment(oView.getId(), "hcm.fab.mytimesheet.view.fragments.ValueHelp", oDialogController);
    // connect dialog to view (models, lifecycle)
    oView.addDependent(oDialog);
   }
   jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);

   jQuery.sap.delayedCall(0, this, function () {
    oDialog.open();
   });
  },
  getValueHelpCollection: function (FieldName) {
   var that = this;
   var oModel = new sap.ui.model.json.JSONModel();
   var f = [];
   // var a = new sap.ui.model.Filter({
   //  path: "StartDate",
   //  operator: sap.ui.model.FilterOperator.EQ,
   //  value1: this.oFormatYyyymmdd.format(that.startDate)
   // });
   // var b = new sap.ui.model.Filter({
   //  path: "EndDate",
   //  operator: sap.ui.model.FilterOperator.EQ,
   //  value1: this.oFormatYyyymmdd.format(that.endDate)
   // });
   var c = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   var d = new sap.ui.model.Filter({
    path: "FieldName",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: FieldName
   });
   // f.push(a);
   // f.push(b);
   f.push(c);
   f.push(d);
   var mParameters = {
    urlParameters: '$expand=ValueHelpHits',
    filters: f,
    success: function (oData, oResponse) {
     that.results = oData.results[0].ValueHelpHits.results;;
     oModel.setData(that.results);
     that.setModel(oModel, "ValueHelp");
    },
    error: function (oError) {
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/ValueHelpCollection', mParameters);
  },
  handleClick: function (oEvent) {
   var that = this;
   var value = oEvent.getParameter('selectedItem');
  },
  onToDoEdit: function (oEvent) {
   var that = this;
   var oModel = this.getModel('controls');
   oModel.setProperty('/sendForApproval', false);
   oModel.setProperty('/submitDraft', false);
   oModel.setProperty('/overviewCancel', false);
   oModel.setProperty('/todoCancel', true);
   oModel.setProperty('/todoDone', true);
   oModel.setProperty('/showFooter', true);
   oModel.setProperty('/editTodoVisibility', false);
   this.oReadOnlyToDoTemplate = this.getView().byId("idToDoList").removeItem(0);
   // this.oReadOnlyToDoTemplate = new sap.m.ColumnListItem({
   //  cells: [
   //   new sap.m.Text({
   //    text: "{path: 'TodoList>TimeEntryDataFields/WORKDATE', type: 'sap.ui.model.type.Date', formatOptions: { pattern: 'EEE,MMM d' }}"
   //   }),
   //   new sap.m.ObjectStatus({
   //    text: {
   //     parts: [{
   //      path: 'TodoList>TimeEntryDataFields/CATSHOURS'
   //     }, {
   //      path: 'TodoList>target'
   //     }],
   //     formatter: formatter.concatStrings
   //    },
   //    state: {
   //     path: 'TodoList>TimeEntryDataFields/STATUS',
   //     formatter: formatter.TodoState
   //    }

   //   }), 
   //   // new sap.m.Text({
   //   //  selectedKey: "{TodoList>AssignmentId}",
   //   //  selectionChange: this.onSelectionChangeToDo
   //   // }).bindItems({
   //   //  path: "Tasks>/",
   //   //  template: new sap.ui.core.Item({
   //   //   key: "{Tasks>AssignmentId}",
   //   //   text: "{Tasks>AssignmentName}"
   //   //  }),
   //   //  templateShareable: true
   //   // }),

   //   // new sap.m.Input({
   //   //  value: "{TodoList>TimeEntryDataFields/CATSHOURS}",
   //   //  liveChange: this.liveChangeHoursToDo
   //   // }),

   //   new sap.m.ObjectStatus({
   //    text: "{TodoList>TimeEntryDataFields/STATUS}",
   //    state: {
   //     path: 'TodoList>TimeEntryDataFields/STATUS',
   //     formatter: formatter.TodoState
   //    }
   //   }),
   //   // new sap.m.Button({
   //   //  icon: {
   //   //   path: 'TodoList>TimeEntryDataFields/LONGTEXT',
   //   //   formatter: formatter.longtextButtons
   //   //  },
   //   //  type: sap.m.ButtonType.Transparent,
   //   //  press: this.EditTodoLongTextPopover.bind(this)
   //   // }),
   //   // new sap.m.Button({
   //   //  text: this.oBundle.getText('SendForApproval'),
   //   //  press: this.onSendForApprovalToDo.bind(this)
   //   // })
   //  ],
   //  customData: [new sap.ui.core.CustomData({
   //   key: "counter",
   //   value: "{TodoList>Counter}"
   //  })]
   // });
   this.oEditableToDoTemplate = new sap.m.ColumnListItem({
    highlight: "{TodoList>highlight}",
    cells: [
     new sap.m.Text({
      text: "{path: 'TodoList>TimeEntryDataFields/WORKDATE', type: 'sap.ui.model.type.Date', formatOptions: { style: 'full' }}"
     }),
     new sap.m.ObjectStatus({
      text: {
       parts: [{
        path: 'TodoList>total',
        type: 'sap.ui.model.odata.type.Decimal',
        formatOptions: {
         parseAsString: true,
         decimals: 2,
         maxFractionDigits: 2,
         minFractionDigits: 0
        },
        constraints: {
         precision: 4,
         scale: 2,
         minimum: '0',
         maximum: '10000'
        }
       }, {
        path: 'TodoList>target',
        type: 'sap.ui.model.odata.type.Decimal',
        formatOptions: {
         parseAsString: true,
         decimals: 2,
         maxFractionDigits: 2,
         minFractionDigits: 0
        },
        constraints: {
         precision: 4,
         scale: 2,
         minimum: '0',
         maximum: '10000'
        }
       }],
       formatter: formatter.concatStrings
      },
      // state: {
      //  path: 'TodoList>TimeEntryDataFields/STATUS',
      //  formatter: formatter.TodoState
      // }

     }),

     new sap.m.ObjectStatus({
      text: {
       path: 'TodoList>currentMissing',
       type: 'sap.ui.model.odata.type.Decimal',
       formatOptions: {
        parseAsString: true,
        decimals: 2,
        maxFractionDigits: 2,
        minFractionDigits: 0
       },
       constraints: {
        precision: 4,
        scale: 2,
        minimum: '0',
        maximum: '10000'
       }
      }
      // state: {
      //  path: 'TodoList>TimeEntryDataFields/STATUS',
      //  formatter: formatter.TodoState
      // }

     }),

     // new sap.m.ComboBox({
     //  selectedKey: "{TodoList>AssignmentId}",
     //  selectionChange: this.onSelectionChangeToDo
     // }).bindItems({
     //  path: "Tasks>/",
     //  template: new sap.ui.core.Item({
     //   key: "{Tasks>AssignmentId}",
     //   text: "{Tasks>AssignmentName}",
     //   enabled: {
     //    path: 'Tasks>AssignmentStatus',
     //    formatter: this.formatter.activeTasks
     //   }
     //  }),
     //  templateShareable: true
     // }),
     new sap.m.ComboBox({
      selectedKey: "{TodoList>AssignmentId}",
      selectionChange: this.onSelectionChangeToDo,
      showSecondaryValues: true
     }).bindItems({
      path: "TasksWithGroups>/",
      // factory: this.activeTasks,
      template: new sap.ui.core.ListItem({
       key: "{TasksWithGroups>AssignmentId}",
       text: "{TasksWithGroups>AssignmentName}",
       enabled: {
        path: 'TasksWithGroups>AssignmentStatus',
        formatter: this.formatter.activeTasks
       },
       additionalText: "{TasksWithGroups>AssignmentType}"
      }),
      templateShareable: true
     }),
     // new sap.ui.layout.HorizontalLayout({
     //  content: [new sap.m.Input({
     //   value: "{TodoList>TimeEntryDataFields/CATSHOURS}",
     //   type: sap.m.InputType.Number,
     //   width: "60%",
     //   liveChange: this.liveChangeHoursToDo.bind(this)
     //  }), new sap.m.Text({
     //   text: "{TodoList>TimeEntryDataFields/UNIT}"
     //  })]
     // }),
     new sap.ui.layout.HorizontalLayout({
      content: [
       // new sap.m.Input({
       //  value: "{TodoList>TimeEntryDataFields/CATSHOURS}",
       //  description: {
       //   parts: [{
       //    path: 'TodoList>TimeEntryDataFields/UNIT'
       //   }, {
       //    path: 'TodoList>TimeEntryDataFields/CATSHOURS'
       //   }],
       //   formatter: formatter.getUnitTexts.bind(this)
       //  },
       //  liveChange: this.liveChangeHoursToDo.bind(this),
       //  type: sap.m.InputType.Number,
       //  width: "100%",
       //  fieldWidth: "60%"
       // })
       new sap.m.StepInput({
        value: {
         parts: [{
          path: 'TodoList>TimeEntryDataFields/CATSHOURS'
         }, {
          path: 'TodoList>TimeEntryDataFields/CATSQUANTITY'
         }, {
          path: 'TodoList>TimeEntryDataFields/CATSAMOUNT'
         }],
         formatter: formatter.calHoursQuanAmountInput.bind(this)
        },
        description: {
         parts: [{
          path: 'TodoList>TimeEntryDataFields/UNIT'
         }, {
          path: 'TodoList>TimeEntryDataFields/CATSHOURS'
         }],
         formatter: formatter.getUnitTexts.bind(this)
        },
        change: this.liveChangeHoursToDo.bind(this),
        displayValuePrecision: 2,
        step: 1,
        min: 0,
        fieldWidth: "60%",
        valueState: "{TodoList>valueState}",
        valueStateText: "{TodoList>valueStateText}",
       })
       //  , 
       //  new sap.m.Label({
       //   text: "{TimeData>TimeEntryDataFields/UNIT}",
       //   style: "Bold"
      ]
     }),
     new sap.m.TimePicker({
      value: {
       path: 'TodoList>TimeEntryDataFields/BEGUZ',
       formatter: this.formatter.formatTime.bind(this)
      },
      visible: this.clockTimeVisible,
      valueFormat: "HH:mm",
      displayFormat: "HH:mm",
      change: this.startTimeToDoChange.bind(this),
      placeholder: this.oBundle.getText("startTime")
     }),
     new sap.m.TimePicker({
      value: {
       path: 'TodoList>TimeEntryDataFields/ENDUZ',
       formatter: this.formatter.formatTime.bind(this)
      },
      visible: this.clockTimeVisible,
      valueFormat: "HH:mm",
      displayFormat: "HH:mm",
      change: this.stopTimeToDoChange.bind(this),
      placeholder: this.oBundle.getText("endTime")
     }),

     new sap.m.ObjectStatus({
      text: {
       path: 'TodoList>TimeEntryDataFields/STATUS',
       formatter: formatter.status
      },
      state: {
       path: 'TodoList>TimeEntryDataFields/STATUS',
       formatter: formatter.TodoState
      }
     }),
     new sap.m.Button({
      icon: {
       path: 'TodoList>TimeEntryDataFields/LONGTEXT',
       formatter: formatter.longtextButtons
      },
      type: sap.m.ButtonType.Transparent,
      press: this.EditTodoLongTextPopover.bind(this)

     }),
     // new sap.m.Button({
     //  text: this.oBundle.getText('SendForApproval'),
     //  press: this.onSendForApprovalToDo.bind(this),
     //  enabled: '{TodoList>sendButton}',
     //  type: sap.m.ButtonType.Emphasized
     // }),
     new sap.ui.layout.HorizontalLayout({
      content: [
       new sap.m.Button({
        icon: "sap-icon://sys-cancel",
        type: sap.m.ButtonType.Transparent,
        press: this.onTodoDeleteRow.bind(this),
        visible: "{TodoList>deleteButton}",
        enabled: "{TodoList>deleteButtonEnable}"
       }),
       new sap.m.Button({
        icon: "sap-icon://add",
        type: sap.m.ButtonType.Transparent,
        press: this.onTodoAddRow.bind(this),
        visible: "{TodoList>addButton}",
        enabled: "{TodoList>addButtonEnable}"
       })
      ]
     })
    ],
    customData: [new sap.ui.core.CustomData({
     key: "counter",
     value: "{TodoList>Counter}"
    })]
   });
   this.rebindTableWithTemplate(this.oToDoTable, "TodoList>/", this.oEditableToDoTemplate, "Edit");

  },
  liveChangeHoursToDo: function (oEvent) {
   this.getModel("controls").setProperty("/isToDoChanged", true);
   this.getModel("controls").setProperty("/todoDataChanged", true);
   var val = /^\d+(\.\d{1,2})?$/;
   // if (parseFloat(oEvent.getSource().getValue())) {
   if (val.test(oEvent.getSource().getValue())) {
    var counter = oEvent.getSource().getParent().getParent().getCustomData('counter')[0].getValue();
    var oModel = this.oToDoTable.getModel('TodoList');
    var index = parseInt(oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1]);
    var data = oModel.getData();
    data[index].addButtonEnable = true;
    data[index].deleteButtonEnable = true;
    data[index].sendButton = true;
    data[index].TimeEntryDataFields.CATSHOURS = parseFloat(oEvent.getSource().getValue()).toFixed(2);
    // data[index].total = ((parseFloat(data[index].target) - parseFloat(data[index].missing)) + parseFloat(oEvent.getSource().getValue()))
    //  .toFixed(2);
    if (counter && counter !== null) {
     data[index].TimeEntryOperation = 'U';
    } else {
     data[index].TimeEntryOperation = 'C';
    }
    data = this.calculateSumToDo(new Date(data[index].TimeEntryDataFields.WORKDATE), data);
    this.setModel(new JSONModel(data), "TodoList");
   }
  },
  onCopyTask: function (oEvent) {
   var that = this;
   var oView = this.getView();
   var oTable = this.byId('idTasks');
   var oModel = new JSONModel();
   var data = this.getModel('ProfileFields').getData();
   var tasks = this.getModel('Tasks').getData();
   var index = oTable.getSelectedItem().getBindingContext('TaskFields').getPath().split("/")[1];
   var formElements = [];
   var formContainers = [];
   var form = {
    name: null,
    status: false,
    containers: null
   };
   var oControl = this.getModel("controls");
   oControl.setProperty('/createAssignment', false);
   oControl.setProperty('/editAssignment', false);
   oControl.setProperty('/copyAssignment', true);
   oControl.setProperty('/displayAssignment', false);
   oControl.setProperty('/assignmentTitle', this.oBundle.getText("copyAssignment"));
   this.setGlobalModel(oControl, "controls");
   var selectedTask = oTable.getSelectedItem().getAggregation('cells');
   var profileFields = $.extend(true, [], this.getModel('ProfileFields').getData());
   // Commented code to be removed...
   // for (var i = 0; i < selectedTask.length; i++) {
   //  var obj = $.grep(data, function (element, index) {
   //   return element.FieldName == selectedTask[i].getCustomData('FieldName')[0].getValue();
   //  });
   //  if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentStatus" && selectedTask[i].getCustomData('FieldName')[
   //    0].getValue() !== "AssignmentName") {
   //   if (tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()] !== undefined) {
   //    obj[0].FieldValue = tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()];
   //   }
   //   obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
   //  } else {
   //   if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentStatus") {
   //    obj[0].FieldValue = selectedTask[i].getAggregation('customData')[2].getValue();
   //    obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
   //   } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentName") {
   //    obj[0].FieldValue = selectedTask[i].getText();
   //    obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
   //   }
   //  }
   //  if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentName" && selectedTask[i].getCustomData('FieldName')[0]
   //   .getValue() !== "AssignmentStatus") {
   //   formElements.push(obj[0]);
   //  } else {
   //   if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentName") {
   //    form.name = obj[0].FieldValue;
   //   } else {
   //    form.status = obj[0].FieldValue;
   //   }
   //  }
   for (var i = 0; i < selectedTask.length; i++) {
    var obj = $.grep(data, function (element, index) {
     return element.FieldName == selectedTask[i].getCustomData('FieldName')[0].getValue();
    });
    if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentStatus" && selectedTask[i].getCustomData(
      'FieldName')[
      0].getValue() !== "AssignmentName" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityStartDate" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityEndDate") {
     if (tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()] !== undefined) {
      obj[0].FieldValue = tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()];
     }
     obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
    } else {
     if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentStatus") {
      obj[0].FieldValue = selectedTask[i].getAggregation('customData')[2].getValue();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentName") {
      // obj[0].FieldValue = selectedTask[i].getText();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
      obj[0].FieldValue = "";
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityStartDate") {
      obj[0].FieldValue = selectedTask[i].getText();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityEndDate") {
      obj[0].FieldValue = selectedTask[i].getText();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     }
    }
    if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentName" && selectedTask[i].getCustomData('FieldName')[
      0]
     .getValue() !== "AssignmentStatus" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityStartDate" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityEndDate") {
     formElements.push(obj[0]);
    } else {
     if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentName") {
      form.name = obj[0].FieldValue;
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentStatus") {
      form.status = obj[0].FieldValue;
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityStartDate") {
      form.validFrom = new Date(obj[0].FieldValue);
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityEndDate") {
      form.validTo = new Date(obj[0].FieldValue);
     }
    }
    if (((formElements.length + 1) % 5) === 0 || i === (selectedTask.length - 1)) {
     formContainers.push({
      form: $.extend(formElements, [], true)
     });
     formElements = [];
    }
   }
   // for (var i = 0; i < profileFields.length; i++) {
   //  if (profileFields[i].FieldName !== "AssignmentStatus") {
   //   // if (tasks[index][profileFields[i].FieldName]) {
   //    profileFields[i].FieldValue = tasks[index][profileFields[i].FieldName];
   //   // }
   //  }
   //  if (profileFields[i].FieldName !== "AssignmentName" && profileFields[i].FieldName !== "AssignmentStatus") {
   //   formElements.push(profileFields[i]);
   //  } else {
   //   if (profileFields[i].FieldName === "AssignmentName") {
   //    form.name = profileFields[i].FieldValue;
   //   } else {
   //    form.status = profileFields[i].FieldValue;
   //   }
   //  }
   //  if (((i + 1) % 5) === 0 || i === (selectedTask.length - 1)) {
   //   formContainers.push({
   //    form: $.extend(true, [], formElements)
   //   });
   //   formElements = [];
   //  }
   // }
   form.containers = formContainers;
   oModel.setData(form);
   this.setGlobalModel(oModel, "EditedTask");
   // for (var i = 0; i < selectedTask.length; i++) {
   //  var obj = $.grep(data, function(element, index) {
   //   return element.FieldName == selectedTask[i].getCustomData('FieldName')[0].getValue();
   //  });
   //  if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentStatus") {
   //   // obj[0].FieldValue = selectedTask[i].getText();
   //   if (tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()]) {
   //    obj[0].FieldValue = tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()];
   //   } else {
   //    obj[0].FieldValue = selectedTask[i].getText();
   //   }
   //   obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
   //  } else {
   //   obj[0].FieldValue = selectedTask[i].getAggregation('customData')[2].getValue();
   //   obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
   //  }

   // }
   // oModel.setData(data);
   // this.setGlobalModel(oModel, "EditedTask");
   // var oDialog;
   // var oDialogController = {
   //  handleConfirm: function(oEvent) {
   //   var TaskData = {
   //    ApproverId: "",
   //    ApproverName: "",
   //    AssignmentFields: {
   //     AENAM: "",
   //     ALLDF: "",
   //     APDAT: null,
   //     APNAM: "",
   //     ARBID: "",
   //     ARBPL: "",
   //     AUERU: "",
   //     AUFKZ: "",
   //     AUTYP: "",
   //     AWART: "",
   //     BEGUZ: "",
   //     BELNR: "",
   //     BEMOT: "",
   //     BUDGET_PD: "",
   //     BUKRS: "",
   //     BWGRL: "0.0",
   //     CATSAMOUNT: "0.0",
   //     CATSHOURS: "0.00",
   //     CATSQUANTITY: "0.0",
   //     CPR_EXTID: "",
   //     CPR_GUID: "",
   //     CPR_OBJGEXTID: "",
   //     CPR_OBJGUID: "",
   //     CPR_OBJTYPE: "",
   //     ENDUZ: "",
   //     ERNAM: "",
   //     ERSDA: null,
   //     ERSTM: "",
   //     ERUZU: "",
   //     EXTAPPLICATION: "",
   //     EXTDOCUMENTNO: "",
   //     EXTSYSTEM: "",
   //     FUNC_AREA: "",
   //     FUND: "",
   //     GRANT_NBR: "",
   //     HRBUDGET_PD: "",
   //     HRCOSTASG: "",
   //     HRFUNC_AREA: "",
   //     HRFUND: "",
   //     HRGRANT_NBR: "",
   //     HRKOSTL: "",
   //     HRLSTAR: "",
   //     KAPAR: "",
   //     KAPID: "",
   //     KOKRS: "",
   //     LAEDA: null,
   //     LAETM: "",
   //     LGART: "",
   //     LOGSYS: "",
   //     LONGTEXT: "",
   //     LONGTEXT_DATA: "",
   //     LSTAR: "",
   //     LSTNR: "",
   //     LTXA1: "",
   //     MEINH: "",
   //     OFMNW: "0.0",
   //     OTYPE: "",
   //     PAOBJNR: "",
   //     PEDD: "",
   //     PERNR: "",
   //     PLANS: "",
   //     POSID: "",
   //     PRAKN: "",
   //     PRAKZ: "",
   //     PRICE: "0.0",
   //     RAPLZL: "",
   //     RAUFNR: "",
   //     RAUFPL: "",
   //     REASON: "",
   //     REFCOUNTER: "",
   //     REINR: "",
   //     RKDAUF: "",
   //     RKDPOS: "",
   //     RKOSTL: "",
   //     RKSTR: "",
   //     RNPLNR: "",
   //     RPROJ: "",
   //     RPRZNR: "",
   //     SBUDGET_PD: "",
   //     SEBELN: "",
   //     SEBELP: "",
   //     SKOSTL: "",
   //     SPLIT: 0,
   //     SPRZNR: "",
   //     STATKEYFIG: "",
   //     STATUS: "",
   //     S_FUNC_AREA: "",
   //     S_FUND: "",
   //     S_GRANT_NBR: "",
   //     TASKCOMPONENT: "",
   //     TASKCOUNTER: "",
   //     TASKLEVEL: "",
   //     TASKTYPE: "",
   //     TCURR: "",
   //     TRFGR: "",
   //     TRFST: "",
   //     UNIT: "",
   //     UVORN: "",
   //     VERSL: "",
   //     VORNR: "",
   //     VTKEN: "",
   //     WABLNR: "",
   //     WAERS: "",
   //     WERKS: "",
   //     WORKDATE: null,
   //     WORKITEMID: "",
   //     WTART: ""
   //    },
   //    AssignmentId: "",
   //    AssignmentName: "",
   //    AssignmentOperation: "U",
   //    AssignmentStatus: "",
   //    Counter: "",
   //    Pernr: this.empID,
   //    ProfileId: ""
   //   };

   //   for (var i = 0; i < this.byId('FORM_FIELDS').getFormElements().length; i++) {
   //    TaskData.AssignmentId = this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[1].getValue();
   //    if (this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue() == "AssignmentName") {
   //     TaskData[this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue()] = this.byId(
   //      'FORM_FIELDS').getFormElements()[i].getFields()[0].getValue();
   //    } else if (this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue() == "Approver" || this.byId(
   //      "FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue() == "Status") {
   //     continue;
   //    } else {
   //     TaskData.AssignmentFields[this.byId("FORM_FIELDS").getFormElements()[i].getFields()[0].getCustomData()[0].getValue()] = this
   //      .byId(
   //       'FORM_FIELDS').getFormElements()[i].getFields()[0].getValue();
   //    }
   //   }
   //   TaskData.AssignmentId = this.byId("FORM_FIELDS").getFormElements()[0].getFields()[0].getCustomData()[1].getValue();
   //   this.UpdateTask(TaskData);
   //   oDialog.close();
   //   oDialog.destroy();
   //  }.bind(this),
   //  handleCancel: function() {
   //   oDialog.close();
   //   oDialog.destroy();
   //  }.bind(this)
   // };
   // if (!oDialog) {
   //  // create dialog via fragment factory
   //  oDialog = sap.ui.xmlfragment(oView.getId(), "hcm.fab.mytimesheet.view.fragments.CopyTask", oDialogController);
   //  // connect dialog to view (models, lifecycle)
   //  oView.addDependent(oDialog);
   // }
   // jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);

   // jQuery.sap.delayedCall(0, this, function() {
   //  oDialog.open();
   // });
   this.getRouter().navTo("editAssignment", {}, false);
  },
  onSendForApprovalToDo: function (oEvent) {
   var that = this;
   // this.showBusy();
   var index = parseInt(oEvent.getSource().getBindingContext('TodoList').getPath().split('/')[1]);
   var oModel = this.getModel("TodoList");
   var oAprModel = this.getModel("TodoListApproval");
   var aprData;
   var data = oModel.getData();
   if (oAprModel) {
    aprData = oAprModel.getData();
    aprData.push(data[index]);
   } else {
    aprData = [data[index]];
    oAprModel = new JSONModel();
   }
   oAprModel.setData(aprData);
   this.setModel(oAprModel, "TodoListApproval");
   data.splice(index, 1);
   oModel.setData(data);
   this.setModel(oModel, "TodoList");
   var toastMsg = that.oBundle.getText("todoEntriesSaved");
   sap.m.MessageToast.show(toastMsg, {
    duration: 2000
   });
  },
  onToDoSubmit: function (oEvent) {
   var that = this;
   this.showBusy();
   var submitEntries = this.fetchToDoRecords();
   var selectedItems;
   var oModel = $.extend(true, {}, this.oDataModel);
   var oControl = this.getModel("controls");
   oModel.setChangeBatchGroups({
    "*": {
     groupId: "TimeEntry",
     changeSetId: "TimeEntry",
     single: false
    }
   });
   oModel.setDeferredGroups(["TimeEntry"]);
   oModel
    .refreshSecurityToken(
     function (oData) {
      if (submitEntries.length === 0) {
       that.hideBusy(true);
       var toastMsg = that.oBundle.getText("noEntriesToSubmit");
       sap.m.MessageToast.show(toastMsg, {
        duration: 3000
       });
       return;
      }
      for (var i = 0; i < submitEntries.length; i++) {
       var obj = {
        properties: submitEntries[i],
        changeSetId: "TimeEntry",
        groupId: "TimeEntry"
       };
       oModel
        .createEntry(
         "/TimeEntryCollection",
         obj);
      }
      oModel.submitChanges({
       groupId: "TimeEntry",
       changeSetId: "TimeEntry",
       success: function (oData, res) {
        // that.responses = oData.__batchResponses[0].__changeResponses;
        if (that.oMessagePopover) {
         // that.oMessagePopover.removeAllItems();
         that.oMessagePopover.destroy();
         sap.ui.getCore().getMessageManager().removeAllMessages();
         // that.oMessagePopover.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");
        }
        var error = false;
        var entries = that.getModel('TodoList').getData();
        var oMessages = [];
        if (!oData.__batchResponses[0].__changeResponses) {
         that.hideBusy(true);

         return;
        } else {
         for (var i = 0; i < oData.__batchResponses[0].__changeResponses.length; i++) {
          var entry = $.grep(entries, function (element, ind) {
           if (element.RecRowNo) {
            return element.RecRowNo === parseInt(oData.__batchResponses[0].__changeResponses[i].data.RecRowNo).toString();
           }
          });
          if (oData.__batchResponses[0].__changeResponses[i].data.ErrorMsg !== "") {
           error = true;
           if (entry.length > 0) {
            entry[0].valueState = "Error";
            entry[0].highlight = "Error";
            entry[0].valueStateText = oData.__batchResponses[0].__changeResponses[i].data.ErrorMsg;
            oMessages.push(new sap.ui.core.message.Message({
             message: oData.__batchResponses[0].__changeResponses[i].data.ErrorMsg,
             description: oData.__batchResponses[0].__changeResponses[i].data.ErrorMsg,
             type: sap.ui.core.MessageType.Error,
             processor: that.getOwnerComponent().oMessageProcessor,
             additionalText: parseInt(oData.__batchResponses[0].__changeResponses[i].data.RecRowNo),
             code: "TodoList"
            }));
           }

          } else {
           if (entry.length > 0) {
            entry[0].valueState = "Success";
            entry[0].highlight = "Success";
           }
          }
         }
        }
        sap.ui.getCore().getMessageManager().addMessages(
         oMessages
        );
        that.getModel('TodoList').updateBindings();
        // that.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");
        if (!error) {
         var toastMsg = that.oBundle.getText("timeEntriesSaved");
         sap.m.MessageToast.show(toastMsg, {
          duration: 1000
         });
         that.getToDoList();
         that.getTimeEntries(new Date(that.dateFrom), new Date(that.dateTo));
         sap.ui.getCore().getMessageManager().removeAllMessages();
         var data = [];
         var oModel = new JSONModel();
         oModel.setData(data);
         that.setModel(oModel, 'deleteRecords');
         that.setModel(oModel, 'changedRecords');
         that.setModel(oModel, 'newRecords');
         if (that.oReadOnlyToDoTemplate) {
          that.rebindTableWithTemplate(that.oToDoTable, "TodoList>/", that.oReadOnlyToDoTemplate, "Navigation");
         }
         oControl.setProperty("/editTodoVisibility", true);
         oControl.setProperty("/todoDone", false);
         oControl.setProperty("/todoCancel", false);
         oControl.setProperty("/showFooter", false);
         oControl.setProperty("/todoDataChanged", false);
         oControl.setProperty("/isToDoChanged", false);
        }
        that.hideBusy(true);
       },
       error: function (oError) {
        that.hideBusy(true);
        that.oErrorHandler.processError(oError);
       }
      });

     }, true);
   oModel.attachBatchRequestCompleted(this.onSubmissionSuccess.bind(this));
  },
  onStartDateChange: function (oEvent) {
   var that = this;
   var oCalendar = oEvent.getSource();
   var oControl = this.getModel("controls");
   var curDate = new Date();
   curDate = new Date(oCalendar.getStartDate());
   if (sap.ui.Device.system.phone === true) {
    this.dateFrom = this.getFirstDayOfWeek(oCalendar.getStartDate(), that.firstDayOfWeek);
    // curDate.setDate(oCalendar.getStartDate().getDate() + 6);
    this.dateTo = this.getLastDayOfWeek(oCalendar.getStartDate(), that.firstDayOfWeek);
    this.startdate = this.getFirstDayOfWeek(oCalendar.getStartDate(), that.firstDayOfWeek);
    this.enddate = this.getFirstDayOfWeek(oCalendar.getStartDate(), that.firstDayOfWeek);
   } else {
    this.dateFrom = this.getFirstDayOfWeek(oCalendar.getStartDate(), that.firstDayOfWeek);
    curDate.setMonth(curDate.getMonth() + 2, 0);
    this.dateTo = this.getLastDayOfWeek(curDate, that.firstDayOfWeek);
    this.startdate = this.getFirstDayOfWeek(oCalendar.getStartDate(), that.firstDayOfWeek);
    this.enddate = this.getLastDayOfWeek(oCalendar.getStartDate(), that.firstDayOfWeek);
   }
   this.showBusy();
   if (this.oReadOnlyTemplate) {
    this.rebindTableWithTemplate(this.oTable, "TimeData>/", this.oReadOnlyTemplate, "Navigation");
   }
   oControl.setProperty('/overviewCancel', false);
   oControl.setProperty('/sendForApproval', false);
   oControl.setProperty('/submitDraft', false);
   oControl.setProperty('/todoDone', false);
   oControl.setProperty('/todoCancel', false);
   oControl.setProperty('/onEdit', "None");
   oControl.setProperty('/submitDraft', false);
   oControl.setProperty('/duplicateVisibility', false);
   oControl.setProperty('/duplicateWeekVisibility', false);
   oControl.setProperty('/overviewEdit', true);
   that.getTimeEntries(new Date(that.dateFrom), new Date(that.dateTo));
   // that.bindTable(new Date(this.startdate), new Date(this.enddate));

  },

  onSendApproval: function () {
   var that = this;
   this.showBusy();
   var submitEntries = this.fetchRecords(true);
   var selectedItems;
   var data;
   var oModel = $.extend(true, {}, this.oDataModel);
   var oControl = this.getModel("controls");
   this.batches = submitEntries;
   var mParameters;
   oModel.setChangeBatchGroups({
    "*": {
     groupId: "TimeEntry",
     changeSetId: "TimeEntry",
     single: true
    }
   });
   oModel.setDeferredGroups(["TimeEntry"]);
   oModel
    .refreshSecurityToken(
     function (oData) {
      if (submitEntries.length === 0) {
       that.hideBusy(true);
       var toastMsg = that.oBundle.getText("noEntriesToSubmit");
       sap.m.MessageToast.show(toastMsg, {
        duration: 3000
       });
       return;
      }
      for (var i = 0; i < submitEntries.length; i++) {
       var obj = {
        properties: submitEntries[i],
        changeSetId: "TimeEntry",
        groupId: "TimeEntry"
       };
       oModel
        .createEntry(
         "/TimeEntryCollection",
         obj);
      }

      oModel.submitChanges({
       groupId: "TimeEntry",
       changeSetId: "TimeEntry",
       success: function (oData, res) {
        // that.responses = oData.__batchResponses[0].__changeResponses;
        if (that.oMessagePopover) {
         // that.oMessagePopover.removeAllItems();
         that.oMessagePopover.destroy();
         sap.ui.getCore().getMessageManager().removeAllMessages();
         // that.oMessagePopover.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");
        }
        var error = false;
        var entries = that.getModel('TimeData').getData();
        var oMessages = [];
        if (!oData.__batchResponses[0].__changeResponses) {
         // var messageText = "";
         // var messageType;
         // var errorJSON = JSON.parse(oData.__batchResponses[0].response.body);
         // var totalLength = errorJSON.error.innererror.errordetails.length - 1;
         // sap.ui.getCore().getMessageManager().removeAllMessages();
         // // Additional coding to handle Warning and Error message(s)
         // for (var len = 0; len < totalLength; len++) {
         //  if (messageType !== "error") {
         //   messageType = errorJSON.error.innererror.errordetails[len].severity;
         //  }
         //  messageText = errorJSON.error.innererror.errordetails[len].message;
         //  if (messageType === "warning") {
         //   sap.ui.getCore().getMessageManager().addMessages(
         //    new sap.ui.core.message.Message({
         //     message: messageText,
         //     description: messageText,
         //     type: sap.ui.core.MessageType.Warning,
         //     processor: that.getOwnerComponent().oMessageProcessor,
         //     code: "TimeData"
         //    }));
         //  } else {
         //   sap.ui.getCore().getMessageManager().addMessages(
         //    new sap.ui.core.message.Message({
         //     message: messageText,
         //     description: messageText,
         //     type: sap.ui.core.MessageType.Error,
         //     processor: that.getOwnerComponent().oMessageProcessor,
         //     code: "TimeData"
         //    }));
         //  }
         // }
         // //if message type is error then add the last error message
         // if (messageType !== "error") {
         //  if (!errorJSON.error.innererror.errordetails[len].code.match("/IWBEP")) {
         //   messageType = errorJSON.error.innererror.errordetails[len].severity;
         //  }
         // }
         // if (messageType === "error") {
         //  messageText = errorJSON.error.innererror.errordetails[len].message;
         //  if (errorJSON.error.innererror.errordetails[len].severity === "warning") {
         //   sap.ui.getCore().getMessageManager().addMessages(
         //    new sap.ui.core.message.Message({
         //     message: messageText,
         //     description: messageText,
         //     type: sap.ui.core.MessageType.Warning,
         //     processor: that.getOwnerComponent().oMessageProcessor,
         //     code: "TimeData"
         //    }));
         //  } else {
         //   sap.ui.getCore().getMessageManager().addMessages(
         //    new sap.ui.core.message.Message({
         //     message: messageText,
         //     description: messageText,
         //     type: sap.ui.core.MessageType.Error,
         //     processor: that.getOwnerComponent().oMessageProcessor,
         //     code: "TimeData"
         //    }));
         //  }
         // }
         // //If there are no errors then go to display mode
         // if (messageType === sap.ui.core.MessageType.Warning) {
         //  var toastMsg = that.oBundle.getText("timeEntriesSaved");
         //  sap.m.MessageToast.show(toastMsg, {
         //   duration: 1000
         //  });
         //  that.getTimeEntries(new Date(that.minDate), new Date(that.maxDate));
         //  that.getToDoList();
         //  var data = [];
         //  var oModel = new JSONModel();
         //  oModel.setData(data);
         //  that.setModel(oModel, 'deleteRecords');
         //  that.setModel(oModel, 'changedRecords');
         //  that.setModel(oModel, 'newRecords');
         //  if (that.oReadOnlyTemplate) {
         //   that.rebindTableWithTemplate(that.oTable, "TimeData>/", that.oReadOnlyTemplate, "Navigation");
         //  }
         //  oControl.setProperty("/overviewEdit", true);
         //  oControl.setProperty("/overviewCancel", false);
         //  oControl.setProperty("/submitDraft", false);
         //  oControl.setProperty("/sendForApproval", false);
         //  oControl.setProperty("/duplicateVisibility", false);
         //  oControl.setProperty("/showFooter", false);
         //  oControl.setProperty("/duplicateWeekVisibility", false);
         //  oControl.setProperty("/onEdit", "None");
         //  oControl.setProperty('/overviewDataChanged', false);
         //  oControl.setProperty("/isOverviewChanged", false);
         //  that.setModel(oControl, "controls");
         //  that.calculateChangeCount();
         // }
         var messageText = "";
         // var messageType;
         var errorJSON = JSON.parse(oData.__batchResponses[0].response.body);
         var totalLength = errorJSON.error.innererror.errordetails.length - 1;
         sap.ui.getCore().getMessageManager().removeAllMessages();
         // Additional coding to handle error message(s)
         for (var len = 0; len < totalLength; len++) {
          messageText = errorJSON.error.innererror.errordetails[len].message;
          sap.ui.getCore().getMessageManager().addMessages(
           new sap.ui.core.message.Message({
            message: messageText,
            description: messageText,
            type: sap.ui.core.MessageType.Error,
            processor: that.getOwnerComponent().oMessageProcessor,
            code: "TimeData"
           }));
         }
         //if message type is error then add the last error message
         if (!errorJSON.error.innererror.errordetails[len].code.match("/IWBEP")) {
          messageText = errorJSON.error.innererror.errordetails[len].message;
          sap.ui.getCore().getMessageManager().addMessages(
           new sap.ui.core.message.Message({
            message: messageText,
            description: messageText,
            type: sap.ui.core.MessageType.Error,
            processor: that.getOwnerComponent().oMessageProcessor,
            code: "TimeData"
           }));
         }
         that.hideBusy(true);
         return;
        } else {
         for (var i = 0; i < oData.__batchResponses[0].__changeResponses.length; i++) {
          var entry = $.grep(entries, function (element, ind) {
           if (element.RecRowNo) {
            return element.RecRowNo === parseInt(oData.__batchResponses[0].__changeResponses[i].data.RecRowNo).toString();
           }
          });
          if (oData.__batchResponses[0].__changeResponses[i].data.ErrorMsg !== "") {
           error = true;
           if (entry.length > 0) {
            entry[0].valueState = "Error";
            entry[0].highlight = "Error";
            entry[0].valueStateText = oData.__batchResponses[0].__changeResponses[i].data.ErrorMsg;
            oMessages.push(new sap.ui.core.message.Message({
             message: oData.__batchResponses[0].__changeResponses[i].data.ErrorMsg,
             description: oData.__batchResponses[0].__changeResponses[i].data.ErrorMsg,
             type: sap.ui.core.MessageType.Error,
             processor: that.getOwnerComponent().oMessageProcessor,
             additionalText: parseInt(oData.__batchResponses[0].__changeResponses[i].data.RecRowNo),
             code: "TimeData"
            }));
           }

          } else {
           if (entry.length > 0) {
            entry[0].valueState = "Success";
            entry[0].highlight = "Success";
           }
          }
         }
        }
        sap.ui.getCore().getMessageManager().addMessages(
         oMessages
        );
        that.getModel('TimeData').updateBindings();
        // that.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");
        if (!error) {
         var toastMsg = that.oBundle.getText("timeEntriesSaved");
         sap.m.MessageToast.show(toastMsg, {
          duration: 1000
         });

         that.getTimeEntries(new Date(that.minDate), new Date(that.maxDate));
         that.getToDoList();
         sap.ui.getCore().getMessageManager().removeAllMessages();
         var data = [];
         var oModel = new JSONModel();
         oModel.setData(data);
         that.setModel(oModel, 'deleteRecords');
         that.setModel(oModel, 'changedRecords');
         that.setModel(oModel, 'newRecords');
         if (that.oReadOnlyTemplate) {
          that.rebindTableWithTemplate(that.oTable, "TimeData>/", that.oReadOnlyTemplate, "Navigation");
         }
         oControl.setProperty("/overviewEdit", true);
         oControl.setProperty("/overviewCancel", false);
         oControl.setProperty("/submitDraft", false);
         oControl.setProperty("/sendForApproval", false);
         oControl.setProperty("/duplicateVisibility", false);
         oControl.setProperty("/showFooter", false);
         oControl.setProperty("/duplicateWeekVisibility", false);
         oControl.setProperty("/onEdit", "None");
         oControl.setProperty('/overviewDataChanged', false);
         oControl.setProperty("/isOverviewChanged", false);
         that.setModel(oControl, "controls");
         that.calculateChangeCount();
        }
        that.hideBusy(true);
       },
       error: function (oError) {
        that.hideBusy(true);
        that.oErrorHandler.processError(oError);
       }
      });

     }, true);
   oModel.attachBatchRequestCompleted(this.onSubmissionSuccess.bind(this));
   oModel.attachBatchRequestFailed(function () {
    that.handleMessagePopover(new sap.m.Button());
   });
   // mParameters = {
   //  groupId: "TimeEntry",
   //  changeSetId: "TimeEntry"
   // };
   // mParameters.success = function(oData, res) {
   //  that.responses = oData.__batchResponses[0].__changeResponses;
   //  if (that.batches.length !== that.responses.length) {
   //   return;
   //  }
   //  var toastMsg = that.oBundle.getText("timeEntriesSaved");
   //  sap.m.MessageToast.show(toastMsg, {
   //   duration: 1000
   //  });
   //  that.getTimeEntries(new Date(that.dateFrom), new Date(that.dateTo));
   //  if (that.oReadOnlyTemplate) {
   //   that.rebindTableWithTemplate(that.oTable, "TimeData>/", that.oReadOnlyTemplate, "Navigation");
   //  }
   //  oControl.setProperty("/overviewEdit", true);
   //  oControl.setProperty("/overviewCancel", false);
   //  oControl.setProperty("/duplicateVisibility", false);
   //  that.setModel(oControl, "controls");
   // };
   // mParameters.error = function(oError) {
   //  var toastMsg = that.oBundle.getText("error");
   //  sap.m.MessageToast.show(toastMsg, {
   //   duration: 1000
   //  });
   // };
   // for (var i = 0; i < submitEntries.length; i++) {
   //  data = submitEntries[i];
   //  oModel.create("/TimeEntryCollection", data, mParameters);
   // }

  },
  onSubmitDraft: function () {
   var that = this;
   var submitEntries = this.fetchRecords(false);
   var selectedItems;
   var oModel = $.extend(true, {}, this.oDataModel);
   var oControl = this.getModel("controls");
   this.batches = submitEntries;
   oModel.setChangeBatchGroups({
    "*": {
     groupId: "TimeEntry",
     changeSetId: "TimeEntry",
     single: false
    }
   });
   oModel.setDeferredGroups(["TimeEntry"]);
   oModel
    .refreshSecurityToken(
     function (oData) {
      for (var i = 0; i < submitEntries.length; i++) {
       var obj = {
        properties: submitEntries[i],
        changeSetId: "TimeEntry",
        groupId: "TimeEntry"
       };
       oModel
        .createEntry(
         "/TimeEntryCollection",
         obj);
      }
      oModel.submitChanges({
       groupId: "TimeEntry",
       changeSetId: "TimeEntry",
       success: function (oData, res) {
        if (!oData.__batchResponses[0].__changeResponses) {
         // for (var i=0; i<that.batches.length;i++){
         //  that.batches[i].TimeEntryDataFields.WORKDATE = new Date(that.batches[i].TimeEntryDataFields.WORKDATE);
         // }
         return;
        }
        var toastMsg = that.oBundle.getText("timeEntriesSaved");
        sap.m.MessageToast.show(toastMsg, {
         duration: 1000
        });
        that.getTimeEntries(new Date(that.dateFrom), new Date(that.dateTo));
        sap.ui.getCore().getMessageManager().removeAllMessages();
        var data = [];
        var oModel = new JSONModel();
        oModel.setData(data);
        that.setModel(oModel, 'deleteRecords');
        that.setModel(oModel, 'changedRecords');
        that.setModel(oModel, 'newRecords');
        if (that.oReadOnlyTemplate) {
         that.rebindTableWithTemplate(that.oTable, "TimeData>/", that.oReadOnlyTemplate, "Navigation");
        }
        oControl.setProperty("/overviewEdit", true);
        oControl.setProperty("/overviewCancel", false);
        oControl.setProperty("/submitDraft", false);
        oControl.setProperty("/showFooter", false);
        oControl.setProperty("/sendForApproval", false);
        oControl.setProperty("/duplicateVisibility", false);
        oControl.setProperty("/duplicateWeekVisibility", false);
        oControl.setProperty("/onEdit", "None");
        that.setModel(oControl, "controls");
       },
       error: function (oError) {
        that.oErrorHandler.processError(oError);
       }
      });

     }, true);
   oModel.attachBatchRequestCompleted(this.onSubmissionSuccess.bind(this));
  },

  onSubmissionSuccess: function () {
   // this.getTimeEntries(new Date(this.dateFrom), new Date(this.dateTo));
  },

  fetchRecords: function (oRelease) {
   var timeEntries = [];
   var deleteRecords = this.getModel('deleteRecords').getData();
   // var entries = $.extend(true, [], this.getModel('TimeData').getData());
   var entries = this.getModel('TimeData').getData();
   var newRecords = $.grep(entries, function (element, index) {
    return element.TimeEntryOperation == 'C';
   });
   var changedRecords = $.grep(entries, function (element, index) {
    return element.TimeEntryOperation == 'U';
   });
   var selectedRecords = $.grep(entries, function (element, index) {
    return element.TimeEntryOperation == 'R';
   });

   // for (var i = 0; i < selectedRecords.length; i++) {
   // delete selectedRecords[i].target;
   // delete selectedRecords[i].totalHours;
   // delete selectedRecords[i].addButton;
   // delete selectedRecords[i].addButtonEnable;
   // delete selectedRecords[i].deleteButtonEnable;
   // delete selectedRecords[i].deleteButton;
   // delete selectedRecords[i].TimeEntryDataFields.ERSDA;
   // delete selectedRecords[i].TimeEntryDataFields.LAEDA;
   // delete selectedRecords[i].TimeEntryDataFields.LAETM;
   // delete selectedRecords[i].TimeEntryDataFields.ERSTM;
   // delete selectedRecords[i].TimeEntryDataFields.APDAT;
   // delete selectedRecords[i].HeaderData;
   // delete selectedRecords[i].highlight;
   // delete selectedRecords[i].SetDraft;
   // if (selectedRecords[i].Counter && selectedRecords[i].Counter !== "") {
   //  selectedRecords[i].TimeEntryOperation = 'U';
   // } else {
   //  selectedRecords[i].TimeEntryOperation = 'C';
   // }
   // selectedRecords[i].TimeEntryDataFields.WORKDATE = this.formatter.formatToBackendString(selectedRecords[i].TimeEntryDataFields.WORKDATE) +
   // "T00:00:00";
   // if (oRelease) {
   //  selectedRecords[i].AllowRelease = 'X';
   // }
   // if (selectedRecords[i].SetDraft) {
   //  selectedRecords[i].AllowRelease = '';
   //  // delete selectedRecords[i].SetDraft;
   // } else {
   //  selectedRecords[i].AllowRelease = 'X';
   //  // delete selectedRecords[i].SetDraft;
   // }
   // }
   // if (selectedRecords.length >= 1) {
   //  for (var i = 0; i < selectedRecords.length; i++) {
   //   timeEntries.push(selectedRecords[i]);
   //  }
   // } else {

   for (var i = 0; i < changedRecords.length; i++) {
    // delete changedRecords[i].target;
    // delete changedRecords[i].totalHours;
    // delete changedRecords[i].addButton;
    // delete changedRecords[i].addButtonEnable;
    // delete changedRecords[i].deleteButtonEnable;
    // delete changedRecords[i].deleteButton;
    // delete changedRecords[i].TimeEntryDataFields.ERSDA;
    // delete changedRecords[i].TimeEntryDataFields.LAEDA;
    // delete changedRecords[i].TimeEntryDataFields.LAETM;
    // delete changedRecords[i].TimeEntryDataFields.ERSTM;
    // delete changedRecords[i].TimeEntryDataFields.APDAT;
    // delete changedRecords[i].HeaderData;
    // delete changedRecords[i].highlight;
    // delete changedRecords[i].SetDraft;
    changedRecords[i].TimeEntryOperation = 'U';
    // changedRecords[i].TimeEntryDataFields.WORKDATE = this.formatter.formatToBackendString(changedRecords[i].TimeEntryDataFields.WORKDATE) +
    //  "T00:00:00";
    // if (oRelease) {
    //  changedRecords[i].AllowRelease = 'X';
    // }
    if (changedRecords[i].SetDraft) {
     changedRecords[i].AllowRelease = '';
     // delete changedRecords[i].SetDraft;
    } else {
     changedRecords[i].AllowRelease = 'X';
     // delete changedRecords[i].SetDraft;
    }
   }
   for (var i = 0; i < newRecords.length; i++) {
    // delete newRecords[i].target;
    // delete newRecords[i].totalHours;
    // delete newRecords[i].addButton;
    // delete newRecords[i].addButtonEnable;
    // delete newRecords[i].deleteButtonEnable;
    // delete newRecords[i].deleteButton;
    // delete newRecords[i].TimeEntryDataFields.ERSDA;
    // delete newRecords[i].TimeEntryDataFields.LAEDA;
    // delete newRecords[i].TimeEntryDataFields.LAETM;
    // delete newRecords[i].TimeEntryDataFields.ERSTM;
    // delete newRecords[i].TimeEntryDataFields.APDAT;
    // delete newRecords[i].HeaderData;
    // delete newRecords[i].highlight;
    // delete newRecords[i].SetDraft;
    newRecords[i].TimeEntryOperation = 'C';
    // newRecords[i].TimeEntryDataFields.WORKDATE = this.formatter.formatToBackendString(newRecords[i].TimeEntryDataFields.WORKDATE) +
    //  "T00:00:00";
    // if (oRelease) {
    //  newRecords[i].AllowRelease = 'X';
    // }
    if (newRecords[i].SetDraft) {
     newRecords[i].AllowRelease = '';
     // delete newRecords[i].SetDraft;
    } else {
     newRecords[i].AllowRelease = 'X';
     // delete newRecords[i].SetDraft;
    }
   }
   for (var i = 0; i < deleteRecords.length; i++) {
    // delete deleteRecords[i].target;
    // delete deleteRecords[i].totalHours;
    // delete deleteRecords[i].addButton;
    // delete deleteRecords[i].addButtonEnable;
    // delete deleteRecords[i].deleteButtonEnable;
    // delete deleteRecords[i].deleteButton;
    // delete deleteRecords[i].TimeEntryDataFields.ERSDA;
    // delete deleteRecords[i].TimeEntryDataFields.LAEDA;
    // delete deleteRecords[i].TimeEntryDataFields.LAETM;
    // delete deleteRecords[i].TimeEntryDataFields.ERSTM;
    // delete deleteRecords[i].TimeEntryDataFields.APDAT;
    // delete deleteRecords[i].HeaderData;
    // delete deleteRecords[i].highlight;
    // delete deleteRecords[i].SetDraft;
    deleteRecords[i].TimeEntryOperation = 'D';
    // deleteRecords[i].TimeEntryDataFields.WORKDATE = this.formatter.formatToBackendString(deleteRecords[i].TimeEntryDataFields.WORKDATE) +
    //  "T00:00:00";
    // if (oRelease) {
    //  deleteRecords[i].AllowRelease = 'X';
    // }
    if (deleteRecords[i].SetDraft) {
     deleteRecords[i].AllowRelease = '';
     // delete deleteRecords[i].SetDraft;
    } else {
     deleteRecords[i].AllowRelease = 'X';
     // delete deleteRecords[i].SetDraft;
    }
   }
   if (deleteRecords.length > 0) {
    for (var i = 0; i < deleteRecords.length; i++) {
     timeEntries.push(deleteRecords[i]);
    }

   }
   if (changedRecords.length > 0) {
    for (var i = 0; i < changedRecords.length; i++) {
     timeEntries.push(changedRecords[i]);
    }
   }
   if (newRecords.length > 0) {
    for (var i = 0; i < newRecords.length; i++) {
     timeEntries.push(newRecords[i]);
    }
   }
   // }
   for (var i = 0; i < timeEntries.length; i++) {
    timeEntries[i].RecRowNo = (i + 1).toString();
    if (timeEntries[i].TimeEntryDataFields.CATSHOURS === "") {
     timeEntries[i].TimeEntryDataFields.CATSHOURS = "0.00";
    }
   }
   var copiedEntries = $.extend(true, [], timeEntries);
   for (var i = 0; i < copiedEntries.length; i++) {
    delete copiedEntries[i].target;
    delete copiedEntries[i].totalHours;
    delete copiedEntries[i].addButton;
    delete copiedEntries[i].addButtonEnable;
    delete copiedEntries[i].deleteButtonEnable;
    delete copiedEntries[i].deleteButton;
    delete copiedEntries[i].TimeEntryDataFields.ERSDA;
    delete copiedEntries[i].TimeEntryDataFields.LAEDA;
    delete copiedEntries[i].TimeEntryDataFields.LAETM;
    delete copiedEntries[i].TimeEntryDataFields.ERSTM;
    delete copiedEntries[i].TimeEntryDataFields.APDAT;
    delete copiedEntries[i].HeaderData;
    delete copiedEntries[i].highlight;
    delete copiedEntries[i].SetDraft;
    delete copiedEntries[i].valueStateText;
    delete copiedEntries[i].valueState;
    copiedEntries[i].TimeEntryDataFields.WORKDATE = this.formatter.formatToBackendString(copiedEntries[i].TimeEntryDataFields.WORKDATE) +
     "T00:00:00";
    copiedEntries[i].TimeEntryDataFields.CATSHOURS = parseFloat(copiedEntries[i].TimeEntryDataFields.CATSHOURS).toFixed(2);
   }
   return copiedEntries;
  },
  fetchToDoRecords: function () {
   var timeEntries = [];
   // var deleteRecords = this.getModel('deleteRecords').getData();
   var entries = this.getModel('TodoList').getData();
   var newRecords = $.grep(entries, function (element, index) {
    return element.TimeEntryOperation == 'C';
   });
   var changedRecords = $.grep(entries, function (element, index) {
    return element.TimeEntryOperation == 'U';
   });
   for (var i = 0; i < changedRecords.length; i++) {
    // delete changedRecords[i].target;
    // delete changedRecords[i].missing;
    // delete changedRecords[i].currentMissing;
    // delete changedRecords[i].sendButton;
    // delete changedRecords[i].total;
    // delete changedRecords[i].addButton;
    // delete changedRecords[i].addButtonEnable;
    // delete changedRecords[i].deleteButtonEnable;
    // delete changedRecords[i].SetDraft;
    // delete changedRecords[i].highlight;
    changedRecords[i].TimeEntryOperation = 'U';
    changedRecords[i].AllowRelease = 'X';
   }
   for (var i = 0; i < newRecords.length; i++) {
    // delete newRecords[i].target;
    // delete newRecords[i].missing;
    // delete newRecords[i].currentMissing;
    // delete newRecords[i].sendButton;
    // delete newRecords[i].total;
    // delete newRecords[i].addButton;
    // delete newRecords[i].addButtonEnable;
    // delete newRecords[i].deleteButtonEnable;
    // delete newRecords[i].SetDraft;
    // delete newRecords[i].highlight;
    newRecords[i].TimeEntryOperation = 'C';
    newRecords[i].AllowRelease = 'X';
   }
   if (changedRecords.length > 0) {
    for (var i = 0; i < changedRecords.length; i++) {
     timeEntries.push(changedRecords[i]);
    }
   }
   if (newRecords.length > 0) {
    for (var i = 0; i < newRecords.length; i++) {
     timeEntries.push(newRecords[i]);
    }
   }
   for (var i = 0; i < timeEntries.length; i++) {
    timeEntries[i].RecRowNo = (i + 1).toString();
    if (timeEntries[i].TimeEntryDataFields.CATSHOURS === "") {
     timeEntries[i].TimeEntryDataFields.CATSHOURS = "0.00";
    }
   }
   var copiedEntries = $.extend(true, [], timeEntries);
   for (var i = 0; i < copiedEntries.length; i++) {
    delete copiedEntries[i].target;
    delete copiedEntries[i].total;
    delete copiedEntries[i].addButton;
    delete copiedEntries[i].addButtonEnable;
    delete copiedEntries[i].deleteButtonEnable;
    delete copiedEntries[i].deleteButton;
    delete copiedEntries[i].TimeEntryDataFields.ERSDA;
    delete copiedEntries[i].TimeEntryDataFields.LAEDA;
    delete copiedEntries[i].TimeEntryDataFields.LAETM;
    delete copiedEntries[i].TimeEntryDataFields.ERSTM;
    delete copiedEntries[i].TimeEntryDataFields.APDAT;
    delete copiedEntries[i].HeaderData;
    delete copiedEntries[i].highlight;
    delete copiedEntries[i].SetDraft;
    delete copiedEntries[i].valueStateText;
    delete copiedEntries[i].valueState;
    delete copiedEntries[i].missing;
    delete copiedEntries[i].currentMissing;
    delete copiedEntries[i].sendButton;
    delete copiedEntries[i].total;
    copiedEntries[i].TimeEntryDataFields.WORKDATE = this.formatter.formatToBackendString(copiedEntries[i].TimeEntryDataFields.WORKDATE) +
     "T00:00:00";
    copiedEntries[i].TimeEntryDataFields.CATSHOURS = parseFloat(copiedEntries[i].TimeEntryDataFields.CATSHOURS).toFixed(2);
   }
   return copiedEntries;
  },
  /**
   * Event handler when the share in JAM button has been clicked
   * @public
   */
  onShareInJamPress: function () {
   // var oViewModel = this.getModel("worklistView"),
   //  oShareDialog = sap.ui.getCore().createComponent({
   //   name: "sap.collaboration.components.fiori.sharing.dialog",
   //   settings: {
   //    object:{
   //     id: location.href,
   //     share: oViewModel.getProperty("/shareOnJamTitle")
   //    }
   //   }
   //  });
   // oShareDialog.open();
  },

  onSearch: function (oEvent) {
   // if (oEvent.getParameters().refreshButtonPressed) {
   //  // Search field's 'refresh' button has been pressed.
   //  // This is visible if you select any master list item.
   //  // In this case no new search is triggered, we only
   //  // refresh the list binding.
   //  this.onRefresh();
   // } else {
   //  var oTableSearchState = [];
   //  var sQuery = oEvent.getParameter("query");

   //  if (sQuery && sQuery.length > 0) {
   //   oTableSearchState = [new Filter("ActionModify", FilterOperator.Contains, sQuery)];
   //  }
   //  this._applySearch(oTableSearchState);
   // }

  },

  /**
   * Event handler for refresh event. Keeps filter, sort
   * and group settings and refreshes the list binding.
   * @public
   */
  onRefresh: function () {
   // var oTable = this.byId("table");
   // oTable.getBinding("items").refresh();
  },

  /* =========================================================== */
  /* internal methods                                            */
  /* =========================================================== */

  /**
   * Shows the selected item on the object page
   * On phones a additional history entry is created
   * @param {sap.m.ObjectListItem} oItem selected Item
   * @private
   */
  _showObject: function (oItem) {
   // this.getRouter().navTo("object", {
   //  objectId: oItem.getBindingContext().getProperty("EmployeeID")
   // });
  },
  onAssignmentsLoaded: function (oEvent) {
   var that = this;
   this.empID = oEvent.getParameter('defaultAssignment');

   // this.setModel(oEvent.getSource().getModel("commonModel"),"libCommon");
   this.setPernr(this.empID);
   this.initPernr(this.empID);
   this.showBusy();
   this.getFieldTexts("UNIT");
   this.getEmployeeDetails(this.empID);
   new Promise(
    function (fnResolve, fnReject) {
     that.getProfileFields(that.empID);
     that.getWorklistFields(that.empID);
     fnResolve(that.getTasks(true));
     fnReject();
    }
   );
   this.getTimeEntries(that.dateFrom, that.dateTo);
   this.getToDoList();
   // this.getProfileFields(this.empID);
  },
  onAssignmentSwitch: function (oEvent) {
   var that = this;
   this.empID = oEvent.getParameter('selectedAssignment');
   this.setPernr(this.empID);
   this.initPernr(this.empID);
   this.getTimeEntries(this.dateFrom, this.dateTo);
   this.getEmployeeDetails(this.empID);
   // this.getTasks();
   this.getToDoList();
   // this.getProfileFields(this.empID);
   new Promise(
    function (fnResolve, fnReject) {
     that.getProfileFields(that.empID);
     that.getWorklistFields(that.empID);
     fnResolve(that.getTasks(true));
     fnReject();
    }
   );

  },
  getEmployeeDetails: function (empID) {
   var that = this;
   var oModel = new JSONModel();
   var f = [];
   var c = new sap.ui.model.Filter({
    path: "EmployeeNumber",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   f.push(c);
   this.oCEModel.createKey("EmployeeDetailSet", {
    EmployeeNumber: empID,
    ApplicationId: 'CATS'
   });
   var mParameters = {
    filters: f,
    success: function (oData, oResponse) {
     oModel.setData(oData.results[0]);
     that.setModel(oModel, "libCommon");
    },
    error: function (oError) {
     that.oErrorHandler.processError(oError);
    }
   };
   this.oCEModel.read('/EmployeeDetailSet', mParameters);
  },

  onTaskAll: function (oEvent) {
   var oFilter = [];
   this.oTaskTable.getBinding('items').filter(oFilter);
  },
  onTaskActive: function (oEvent) {
   var oFilter = [];
   var selectedKey = true;
   oFilter.push(new Filter("AssignmentStatus", FilterOperator.EQ, selectedKey));

   this.oTaskTable.getBinding('items').filter(oFilter);
  },
  onTaskInactive: function (oEvent) {
   var oFilter = [];
   var selectedKey = false;
   oFilter.push(new Filter("AssignmentStatus", FilterOperator.EQ, selectedKey));
   this.oTaskTable.getBinding('items').filter(oFilter);
  },
  worklistRouteMatched: function (oEvent) {
   var oModel = this.getGlobalModel("TaskReload");
   var oControls = this.getGlobalModel("controls");
   // this.onInit();
   // var oControl = this.getModel("controls");
   // if (oControl) {
   //  this.setModel(oControl, "controls");
   // }
   if (oModel) {
    var oTasks = oModel.getData();
    if (oTasks.reloadTasks) {
     var toastMsg = this.oBundle.getText("taskSaved");
     this.getTasks(false);
     sap.m.MessageToast.show(toastMsg, {
      duration: 5000
     });
     oTasks.reloadTasks = false;
    }
   }
   if (oControls && oControls.getProperty('/groupReload') === true) {
    var toastMsg = this.oBundle.getText("performGroup");
    this.getTasks(false);
    sap.m.MessageToast.show(toastMsg, {
     duration: 5000
    });
    oControls.setProperty('/groupReload', false);
   }
   // this.getToDoList();
  },
  onMenuAction: function (oEvent) {
   if (oEvent.getParameter("item").getKey() === "selectFromWorklist") {
    this.onImportWorklist();
   } else if (oEvent.getParameter("item").getKey() === "selectFromAdminlist") {
    this.onImportAdminlist();
   } else if (oEvent.getParameter("item").getKey() === "selectFromAssignment") {
    this.onTaskCreate(oEvent);
   } else if (oEvent.getParameter("item").getKey() === "selectFromGroups") {
    this.onCreateGroup(oEvent);
   }
  },
  onImportWorklist: function (oEvent) {
   var that = this;
   this.showBusy();
   var oModel = new JSONModel();
   var worklist = {};
   var worklistEntry = [];
   var data;
   var mParameters = {
    success: function (oData, oResponse) {
     oModel.setData(oData.results);
     // that.setModel(oModel, "Worklist");
     data = oData.results;
     var worklistProfileFields = that.getModel("WorklistProfileFields").getData();
     for (var j = 0; j < data.length; j++) {
      for (var i = 0; i < worklistProfileFields.length; i++) {
       if (data[j].WorkListDataFields[worklistProfileFields[i].FieldName] !== undefined) {
        worklist[worklistProfileFields[i].FieldName] = data[j].WorkListDataFields[worklistProfileFields[i].FieldName];
       } else {
        worklist[worklistProfileFields[i].FieldName] = "";
       }
      }
      var finaltask = $.extend(true, {}, worklist);
      worklistEntry.push(finaltask);
      oModel.setData(worklistEntry);
      that.setModel(oModel, "WorklistFields");
     }
     that.worklistPopover();
     that.hideBusy(true);
    },
    error: function (oError) {
     that.hideBusy(true);
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/WorkListCollection', mParameters);
  },
  onImportAdminlist: function (oEvent) {
   var that = this;
   this.showBusy();
   var oModel = new sap.ui.model.json.JSONModel();
   var AdminTaskModel = new sap.ui.model.json.JSONModel();
   // var oControl;
   var obj;
   var AdminTaskFields = [];
   var adminTask = {};
   var a = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   var b = new sap.ui.model.Filter({
    path: "ValidityStartDate",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: new Date()
   });
   var c = new sap.ui.model.Filter({
    path: "ValidityEndDate",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: new Date()
   });
   var d = new sap.ui.model.Filter({
    path: "AdminAssignmentFlag",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: "X"
   });
   var f = [];
   f.push(b);
   f.push(c);
   f.push(a);
   f.push(d);
   var mParameters = {
    filters: f,
    success: function (oData, oResponse) {
     that.adminTasks = oData.results;
     oModel.setData(that.adminTasks);
     that.setModel(oModel, "AdminTasks");
     if (that.adminTasks.length === 0) {
      that.noAssignmentsDialog();
     }
     for (var j = 0; j < that.adminTasks.length; j++) {
      for (var i = 0; i < that.profileFields.length; i++) {
       if (that.profileFields[i].FieldName === "APPROVER" || that.profileFields[i].FieldName === "AssignmentStatus" || that.profileFields[
         i].FieldName === "AssignmentName" || that.profileFields[i].FieldName === "ValidityStartDate" || that.profileFields[i].FieldName ===
        "ValidityEndDate") {
        if (that.profileFields[i].FieldName === "AssignmentStatus") {
         adminTask[that.profileFields[i].FieldName] = that.adminTasks[j][that.profileFields[i].FieldName] === "1" ? true : false;
        } else if (that.profileFields[i].FieldName === "ValidityStartDate") {
         adminTask[that.profileFields[i].FieldName] = that.formatter.dateStringFormat2(that.adminTasks[j][that.profileFields[i].FieldName]);
        } else if (that.profileFields[i].FieldName === "ValidityEndDate") {
         adminTask[that.profileFields[i].FieldName] = that.formatter.dateStringFormat2(that.adminTasks[j][that.profileFields[i].FieldName]);
        } else if (that.profileFields[i].FieldName === "APPROVER") {
         adminTask["APPROVER"] = that.adminTasks[j].ApproverName;
        } else {
         adminTask[that.profileFields[i].FieldName] = that.adminTasks[j][that.profileFields[i].FieldName];
        }
       } else {
        adminTask[that.profileFields[i].FieldName] = that.adminTasks[j].AssignmentFields[that.profileFields[i].FieldName];
        that.getFieldTexts(that.profileFields[i].FieldName);
       }

      }
      var finaltask = $.extend(true, {}, adminTask);
      AdminTaskFields.push(finaltask);
     }
     // obj = $.grep(AdminTaskFields, function (element, ind) {
     //  return element.AssignmentStatus === true;
     // });
     AdminTaskModel.setData(AdminTaskFields);
     that.setModel(AdminTaskModel, "AdminTaskFields");
     that.adminlistPopover();
     that.hideBusy(true);
    },
    error: function (oError) {
     that.hideBusy(true);
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/AssignmentCollection', mParameters);
  },
  getWorklistFields: function (oPernr) {
   var that = this;
   var oModel = new sap.ui.model.json.JSONModel();
   var a = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: oPernr
   });
   var b = new sap.ui.model.Filter({
    path: "SelWorkList",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: "X"
   });
   var f = [];
   f.push(a);
   f.push(b);
   var mParameters = {
    filters: f,
    success: function (oData, oResponse) {
     var worklistFields = $.extend(true, [], oData.results);
     that.readOnlyTemplate();

     //add Name Field to WorklistFields
     var nameField = [];
     nameField.FieldName = "NAME";
     nameField.FieldLength = 30;
     nameField.FieldType = "C";
     nameField.IsReadOnly = "FALSE";
     nameField.SelWorkList = "X";
     nameField.FieldLabel = that.oBundle.getText("name");
     worklistFields.splice(0, 0, nameField);

     //add Range Field to WorklistFields
     var rangeField = [];
     rangeField.FieldName = "RANGE";
     rangeField.FieldLabel = that.oBundle.getText("validPeriod");
     rangeField.IsReadOnly = "FALSE";
     rangeField.SelWorkList = "X";
     worklistFields.splice(1, 0, rangeField);

     oModel.setData(worklistFields);
     that.worklistFields = worklistFields;
     that.setModel(oModel, "WorklistProfileFields");
     // that.setGlobalModel(oModel, "WorklistFields");
    },
    error: function (oError) {
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/ProfileFieldCollection', mParameters);
  },
  worklistPopover: function () {
   // create popover
   var that = this;
   var oDialogController = {
    handleClose: function (event) {
     that._oPopover.close();
     that._oPopover.destroy();
    },
    handleConfirm: function (event) {
     var TaskData = {
      ApproverId: "",
      ApproverName: "",
      AssignmentFields: {
       AENAM: "",
       ALLDF: "",
       APDAT: null,
       APNAM: "",
       ARBID: "",
       ARBPL: "",
       AUERU: "",
       AUFKZ: "",
       AUTYP: "",
       AWART: "",
       BEGUZ: "",
       BELNR: "",
       BEMOT: "",
       BUDGET_PD: "",
       BUKRS: "",
       BWGRL: "0.0",
       CATSAMOUNT: "0.0",
       CATSHOURS: "0.00",
       CATSQUANTITY: "0.0",
       CPR_EXTID: "",
       CPR_GUID: "",
       CPR_OBJGEXTID: "",
       CPR_OBJGUID: "",
       CPR_OBJTYPE: "",
       ENDUZ: "",
       ERNAM: "",
       ERSDA: null,
       ERSTM: "",
       ERUZU: "",
       EXTAPPLICATION: "",
       EXTDOCUMENTNO: "",
       EXTSYSTEM: "",
       FUNC_AREA: "",
       FUND: "",
       GRANT_NBR: "",
       HRBUDGET_PD: "",
       HRCOSTASG: "",
       HRFUNC_AREA: "",
       HRFUND: "",
       HRGRANT_NBR: "",
       HRKOSTL: "",
       HRLSTAR: "",
       KAPAR: "",
       KAPID: "",
       KOKRS: "",
       LAEDA: null,
       LAETM: "",
       LGART: "",
       LOGSYS: "",
       LONGTEXT: "",
       LONGTEXT_DATA: "",
       LSTAR: "",
       LSTNR: "",
       LTXA1: "",
       MEINH: "",
       OFMNW: "0.0",
       OTYPE: "",
       PAOBJNR: "",
       PEDD: null,
       PERNR: "",
       PLANS: "",
       POSID: "",
       PRAKN: "",
       PRAKZ: "",
       PRICE: "0.0",
       RAPLZL: "",
       RAUFNR: "",
       RAUFPL: "",
       REASON: "",
       REFCOUNTER: "",
       REINR: "",
       RKDAUF: "",
       RKDPOS: "",
       RKOSTL: "",
       RKSTR: "",
       RNPLNR: "",
       RPROJ: "",
       RPRZNR: "",
       SBUDGET_PD: "",
       SEBELN: "",
       SEBELP: "",
       SKOSTL: "",
       SPLIT: 0,
       SPRZNR: "",
       STATKEYFIG: "",
       STATUS: "",
       S_FUNC_AREA: "",
       S_FUND: "",
       S_GRANT_NBR: "",
       TASKCOMPONENT: "",
       TASKCOUNTER: "",
       TASKLEVEL: "",
       TASKTYPE: "",
       TCURR: "",
       TRFGR: "",
       TRFST: "",
       UNIT: "",
       UVORN: "",
       VERSL: "",
       VORNR: "",
       VTKEN: "",
       WABLNR: "",
       WAERS: "",
       WERKS: "",
       WORKDATE: null,
       WORKITEMID: "",
       WTART: ""
      },
      AssignmentId: "",
      AssignmentName: "",
      AssignmentOperation: "C",
      AssignmentStatus: "",
      Counter: "",
      Pernr: that.empID,
      ProfileId: "",
      ValidityStartDate: "",
      ValidityEndDate: ""
     };
     var selectedItems = [];
     var selectedItemsCount = 0;
     var worklistTable = that.byId("worklistTableId");
     var oItems = worklistTable.getItems();
     var checkFlag = "";
     for (var i = 0; i < oItems.length; i++) {
      if (oItems[i].getProperty("selected") == true) {
       selectedItemsCount++;
       for (var j = 0; j < that.worklistFields.length; j++) {
        if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "NAME") {
         if (oItems[i].getCells()[j].getValue() === "") {
          oItems[i].getCells()[j].setValueState(sap.ui.core.ValueState.Error);
          //Set a flag for avoiding incorrect Import
          checkFlag = "X";
         }
         TaskData["AssignmentName"] = oItems[i].getCells()[j].getValue();
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "APPROVER") {
         TaskData["ApproverName"] = oItems[i].getCells()[j].getValue();
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "AssignmentStatus") {
         TaskData["AssignmentStatus"] = oItems[i].getCells()[j].getValue() ? "1" : "";
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "RANGE") {
         TaskData["ValidityStartDate"] = that.formatter.formatToBackendString(oItems[i].getCells()[j].getDateValue()) +
          "T00:00:00";
         TaskData["ValidityEndDate"] = that.formatter.formatToBackendString(oItems[i].getCells()[j].getSecondDateValue()) +
          "T00:00:00";
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "CPR_TEXT") {
         //Do nothing - Continue
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "CPR_OBJTEXT") {
         //Do nothing - Continue
        } else {
         TaskData.AssignmentFields[oItems[i].getCells()[j].getCustomData()[0].getValue()] =
          oItems[i].getCells()[j].getText();
        }
        // var data = $.extend(true, {}, selected);
        // selectedItems.push(data);
        if (TaskData.AssignmentFields.BWGRL === "") {
         TaskData.AssignmentFields.BWGRL = "0.00";
        }
        if (TaskData.AssignmentFields.PRICE === "") {
         TaskData.AssignmentFields.PRICE = "0.00";
        }
        if (TaskData.AssignmentFields.OFMNW === "") {
         TaskData.AssignmentFields.OFMNW = "0.00";
        }
        if (TaskData.AssignmentFields.PEDD !== null) {
         TaskData.AssignmentFields.PEDD = this.formatter.formatToBackendString(new Date(TaskData.AssignmentFields.PEDD)) +
          "T00:00:00";
        }
       }
       var data = $.extend(true, {}, TaskData);
       selectedItems.push(data);
      }
     }
     if (selectedItemsCount < 1) {
      var toastMsg = that.oBundle.getText("noSelectionMade");
      sap.m.MessageToast.show(toastMsg, {
       duration: 3000
      });
     } else if (checkFlag === "X") {
      var toastMsg1 = that.oBundle.getText("fillRequiredEntries");
      sap.m.MessageToast.show(toastMsg1, {
       duration: 3000
      });
     } else {
      that.performImportAssignments(selectedItems);
      that._oPopover.close();
      that._oPopover.destroy();
     }
    },
    onNavBack: function (event) {
     var oNavCon = Fragment.byId(that.getView().getId(), "NavC");
     oNavCon.back();
    },
    onValueHelp: this.onValueHelp.bind(this),
    switchState: this.formatter.switchState.bind(this),
    dynamicBindingColumnsWorklist: this.dynamicBindingColumnsWorklist.bind(this),
    dynamicBindingRowsWorklist: this.dynamicBindingRowsWorklist.bind(this)
   };
   // if (!this._oPopover) {
   this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.WorklistPopover",
    oDialogController);
   this.getView().addDependent(this._oPopover);
   // }

   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   jQuery.sap.delayedCall(0, this, function () {
    this._oPopover.open();
   });
  },
  adminlistPopover: function () {
   // create popover
   var that = this;
   var oDialogController = {
    handleClose: function (event) {
     that._oAdminlistPopover.close();
     that._oAdminlistPopover.destroy();
    },
    handleConfirm: function (event) {
     var TaskData = {
      ApproverId: "",
      ApproverName: "",
      AssignmentFields: {
       AENAM: "",
       ALLDF: "",
       APDAT: null,
       APNAM: "",
       ARBID: "",
       ARBPL: "",
       AUERU: "",
       AUFKZ: "",
       AUTYP: "",
       AWART: "",
       BEGUZ: "",
       BELNR: "",
       BEMOT: "",
       BUDGET_PD: "",
       BUKRS: "",
       BWGRL: "0.0",
       CATSAMOUNT: "0.0",
       CATSHOURS: "0.00",
       CATSQUANTITY: "0.0",
       CPR_EXTID: "",
       CPR_GUID: "",
       CPR_OBJGEXTID: "",
       CPR_OBJGUID: "",
       CPR_OBJTYPE: "",
       ENDUZ: "",
       ERNAM: "",
       ERSDA: null,
       ERSTM: "",
       ERUZU: "",
       EXTAPPLICATION: "",
       EXTDOCUMENTNO: "",
       EXTSYSTEM: "",
       FUNC_AREA: "",
       FUND: "",
       GRANT_NBR: "",
       HRBUDGET_PD: "",
       HRCOSTASG: "",
       HRFUNC_AREA: "",
       HRFUND: "",
       HRGRANT_NBR: "",
       HRKOSTL: "",
       HRLSTAR: "",
       KAPAR: "",
       KAPID: "",
       KOKRS: "",
       LAEDA: null,
       LAETM: "",
       LGART: "",
       LOGSYS: "",
       LONGTEXT: "",
       LONGTEXT_DATA: "",
       LSTAR: "",
       LSTNR: "",
       LTXA1: "",
       MEINH: "",
       OFMNW: "0.0",
       OTYPE: "",
       PAOBJNR: "",
       PEDD: null,
       PERNR: "",
       PLANS: "",
       POSID: "",
       PRAKN: "",
       PRAKZ: "",
       PRICE: "0.0",
       RAPLZL: "",
       RAUFNR: "",
       RAUFPL: "",
       REASON: "",
       REFCOUNTER: "",
       REINR: "",
       RKDAUF: "",
       RKDPOS: "",
       RKOSTL: "",
       RKSTR: "",
       RNPLNR: "",
       RPROJ: "",
       RPRZNR: "",
       SBUDGET_PD: "",
       SEBELN: "",
       SEBELP: "",
       SKOSTL: "",
       SPLIT: 0,
       SPRZNR: "",
       STATKEYFIG: "",
       STATUS: "",
       S_FUNC_AREA: "",
       S_FUND: "",
       S_GRANT_NBR: "",
       TASKCOMPONENT: "",
       TASKCOUNTER: "",
       TASKLEVEL: "",
       TASKTYPE: "",
       TCURR: "",
       TRFGR: "",
       TRFST: "",
       UNIT: "",
       UVORN: "",
       VERSL: "",
       VORNR: "",
       VTKEN: "",
       WABLNR: "",
       WAERS: "",
       WERKS: "",
       WORKDATE: null,
       WORKITEMID: "",
       WTART: ""
      },
      AssignmentId: "",
      AssignmentName: "",
      AssignmentOperation: "C",
      AssignmentStatus: "",
      Counter: "",
      Pernr: that.empID,
      ProfileId: "",
      ValidityStartDate: "",
      ValidityEndDate: ""
     };
     var selectedItemsCount = 0;
     var selectedItems = [];
     //Fetch the selected assignments
     var adminlistTable = that.byId("adminlistTableId");
     var oItems = adminlistTable.getItems();
     for (var i = 0; i < oItems.length; i++) {
      if (oItems[i].getProperty("selected") == true) {
       selectedItemsCount++;
       for (var j = 0; j < that.profileFields.length; j++) {
        if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "AssignmentName") {
         TaskData["AssignmentName"] = oItems[i].getCells()[j].getText();
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "APPROVER") {
         TaskData["ApproverName"] = oItems[i].getCells()[j].getText();
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "AssignmentStatus") {
         TaskData["AssignmentStatus"] = (oItems[i].getCells()[j].getText() === "Active") ? "1" : "";
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "ValidityStartDate") {
         TaskData["ValidityStartDate"] = that.formatter.formatToBackendString(oItems[i].getCells()[j].getText()) +
          "T00:00:00";
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "ValidityEndDate") {
         TaskData["ValidityEndDate"] = that.formatter.formatToBackendString(oItems[i].getCells()[j].getText()) +
          "T00:00:00";
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "CPR_TEXT") {
         //Do nothing - Continue
        } else if (oItems[i].getCells()[j].getCustomData()[0].getValue() == "CPR_OBJTEXT") {
         //Do nothing - Continue
        } else {
         if (oItems[i].getCells()[j].getCustomData()[2]) {
          TaskData.AssignmentFields[oItems[i].getCells()[j].getCustomData()[0].getValue()] =
           oItems[i].getCells()[j].getCustomData()[2].getValue();
         } else {
          TaskData.AssignmentFields[oItems[i].getCells()[j].getCustomData()[0].getValue()] =
           oItems[i].getCells()[j].getText();
         }
        }
        if (TaskData.AssignmentFields.BWGRL === "") {
         TaskData.AssignmentFields.BWGRL = "0.00";
        }
        if (TaskData.AssignmentFields.PRICE === "") {
         TaskData.AssignmentFields.PRICE = "0.00";
        }
        if (TaskData.AssignmentFields.OFMNW === "") {
         TaskData.AssignmentFields.OFMNW = "0.00";
        }
        if (TaskData.AssignmentFields.PEDD !== null) {
         TaskData.AssignmentFields.PEDD = this.formatter.formatToBackendString(new Date(TaskData.AssignmentFields.PEDD)) +
          "T00:00:00";
        }
       }
       var data = $.extend(true, {}, TaskData);
       selectedItems.push(data);
      }
     }
     if (selectedItemsCount < 1) {
      var toastMsg = that.oBundle.getText("noSelectionMade");
      sap.m.MessageToast.show(toastMsg, {
       duration: 3000
      });
     } else {
      that.performImportAssignments(selectedItems);
      that._oAdminlistPopover.close();
      that._oAdminlistPopover.destroy();
     }
    },
    onNavBack: function (event) {
     var oNavCon = Fragment.byId(that.getView().getId(), "NavC");
     oNavCon.back();
    },
    dynamicBindingColumnsAdminlist: this.dynamicBindingColumnsAdminlist.bind(this),
    dynamicBindingRowsAdminlist: this.dynamicBindingRowsAdminlist.bind(this)
   };
   // if (!this._oPopover) {
   this._oAdminlistPopover = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.AdminlistPopover",
    oDialogController);
   this.getView().addDependent(this._oAdminlistPopover);
   // }

   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   jQuery.sap.delayedCall(0, this, function () {
    this._oAdminlistPopover.open();
   });
  },
  clockTimesPopOver: function (oEvent) {
   // create popover
   var that = this;
   var oDialogController = {
    handleClose: function (event) {
     that._oPopover.close();
     that._oPopover.destroy();
    },
    handleOk: function (event) {
     var index = oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1];
     var data = that.getModel('TimeData').getData();
     if (that.clockTimeChange) {
      data[index].TimeEntryDataFields.BEGUZ = that.formatter.convertTime(oEvent.getSource().getParent().getAggregation('content')[
        0]
       .getAggregation('content')[0].getDateValue());
      data[index].TimeEntryDataFields.ENDUZ = that.formatter.convertTime(oEvent.getSource().getParent().getAggregation('content')[
        0]
       .getAggregation('content')[1].getDateValue());
      if (data[index].Counter !== "") {
       data[index].TimeEntryOperation = 'U';
      } else {
       data[index].TimeEntryOperation = 'C';
      }
      var oModel = new JSONModel(data);
      that.setModel(oModel, "TimeData");
     }
     that._oPopover.close();
     that._oPopover.destroy();
    },
    handleChange: function (oEvent) {
     that.clockTimeChange = true;
    },
    formatTime: this.formatter.formatTime.bind(this)
   };
   var data = $.extend(true, [], this.getModel('TimeData').getData());
   var oModel = new JSONModel(data);
   this.setModel(oModel, "oldModel");
   // if (!this._oPopover) {
   this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.ClockTimesPopOver",
    oDialogController);
   this._oPopover.bindElement('TimeData>' + oEvent.getSource().getBindingContext('TimeData').getPath());
   this.getView().addDependent(this._oPopover);

   // }

   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   jQuery.sap.delayedCall(0, this, function () {
    this._oPopover.open(oEvent.getSource());
   });
  },
  readOnlyTemplate: function () {
   // this.oReadOnlyTemplate = this.oTable.removeItem(0);
   this.oReadOnlyTemplate = new sap.m.ColumnListItem({
    cells: [
     // new sap.ui.layout.VerticalLayout({
     //  content:[
     //  new sap.m.Text({
     //  // text: "{path: 'TimeData>TimeEntryDataFields/WORKDATE', type: 'sap.ui.model.type.Date', formatOptions: { pattern: 'EEE, MMM d' }}"
     //  text: "{path: 'TimeData>TimeEntryDataFields/WORKDATE', type: 'sap.ui.model.type.Date', formatOptions: { pattern: 'EEEE, MMMM d' }}"
     // }),
     // new sap.m.ObjectStatus({
     //  text: {
     //   parts: [{
     //    path: 'TimeData>totalHours'
     //   }, {
     //    path: 'TimeData>target'
     //   }],
     //   formatter: formatter.concatStrings
     //  },
     //  state: {
     //   parts: [{
     //    path: 'TimeData>totalHours'
     //   }, {
     //    path: 'TimeData>target'
     //   }],
     //   formatter: formatter.hoursValidation
     //  }
     // }),
     // ]
     // }),
     // new sap.m.Text({
     //  text: "{path: 'TimeData>TimeEntryDataFields/WORKDATE', type: 'sap.ui.model.type.Date', formatOptions: { pattern: 'EEE, MMM d' }}"
     // }),
     new sap.m.ObjectStatus({
      text: {
       parts: [{
        path: 'TimeData>totalHours',
        type: 'sap.ui.model.odata.type.Decimal',
        formatOptions: {
         parseAsString: true,
         decimals: 2,
         maxFractionDigits: 2,
         minFractionDigits: 0
        },
        constraints: {
         precision: 4,
         scale: 2,
         minimum: '0',
         maximum: '10000'
        }
       }, {
        path: 'TimeData>target',
        type: 'sap.ui.model.odata.type.Decimal',
        formatOptions: {
         parseAsString: true,
         decimals: 2,
         maxFractionDigits: 2,
         minFractionDigits: 0
        },
        constraints: {
         precision: 4,
         scale: 2,
         minimum: '0',
         maximum: '10000'
        }
       }],
       formatter: formatter.concatStrings
      },
      visible: sap.ui.Device.system.phone ? false : true
     }),
     new sap.m.Link({
      text: {
       parts: [{
        path: 'TimeData>AssignmentName'
       }, {
        path: 'TimeData>AssignmentId'
       }, {
        path: 'TimeData>Counter'
       }],
       formatter: this.formatter.assignmentName.bind(this)
      },
      press: this.onAssignmentQuickView.bind(this)
     }),

     // new sap.ui.layout.HorizontalLayout({
     //  content: [
     // new sap.m.ObjectIdentifier({
     //  title: "{TimeData>TimeEntryDataFields/CATSHOURS}",
     //  text: {
     //   parts: [{
     //    path: 'TimeData>TimeEntryDataFields/BEGUZ'
     //   }, {
     //    path: 'TimeData>TimeEntryDataFields/ENDUZ'
     //   }],
     //   formatter: this.formatter.concatTimeStrings
     //  },
     //  visible: this.clockTimeVisible === true ? true : false
     // }),
     // new sap.m.ObjectNumber({
     //  number: {
     //   path: 'TimeData>TimeEntryDataFields/CATSHOURS',
     //   type: 'sap.ui.model.odata.type.Decimal',
     //   formatOptions: {
     //    parseAsString: true,
     //    decimals: 2,
     //    maxFractionDigits: 2,
     //    minFractionDigits: 0
     //   },
     //   constraints: {
     //    precision: 4,
     //    scale: 2,
     //    minimum: '0',
     //    maximum: '10000'
     //   }
     //  },
     //  unit: {
     //   parts: [{
     //    path: 'TimeData>TimeEntryDataFields/UNIT'
     //   }, {
     //    path: 'TimeData>TimeEntryDataFields/CATSHOURS'
     //   }],
     //   formatter: formatter.getUnitTexts.bind(this)
     //  }
     // }),
     new sap.m.ObjectNumber({
      number: {
       parts: [{
        path: 'TimeData>TimeEntryDataFields/CATSHOURS'
       }, {
        path: 'TimeData>TimeEntryDataFields/CATSQUANTITY'
       }, {
        path: 'TimeData>TimeEntryDataFields/CATSAMOUNT'
       }],
       formatter: formatter.calHoursQuanAmount.bind(this)
      },
      unit: {
       parts: [{
        path: 'TimeData>TimeEntryDataFields/UNIT'
       }, {
        path: 'TimeData>TimeEntryDataFields/CATSHOURS'
       }],
       formatter: formatter.getUnitTexts.bind(this)
      }
     }),
     new sap.m.CheckBox({
      editable: false,
      visible: this.draftStatus,
      selected: "{TimeData>SetDraft}"
     }),
     // new sap.m.ObjectIdentifier({
     //  title: {
     //   parts: [{
     //    path: 'TimeData>TimeEntryDataFields/UNIT'
     //   }, {
     //    path: 'TimeData>TimeEntryDataFields/CATSHOURS'
     //   }],
     //   formatter: formatter.getUnitTexts.bind(this)
     //  }
     // })
     //  ]
     // }),
     // new sap.m.ObjectIdentifier({
     //  text: {
     //   parts: [{
     //    path: 'TimeData>TimeEntryDataFields/BEGUZ'
     //   }, {
     //    path: 'TimeData>TimeEntryDataFields/ENDUZ'
     //   }],
     //   formatter: this.formatter.concatTimeStrings
     //  },
     //  visible: this.clockTimeVisible === true ? true : false
     // }),
     new sap.m.ObjectIdentifier({
      text: {
       path: 'TimeData>TimeEntryDataFields/BEGUZ',
       formatter: this.formatter.formatTime.bind(this)
      },
      visible: this.clockTimeVisible
     }),
     new sap.m.ObjectIdentifier({
      text: {
       path: 'TimeData>TimeEntryDataFields/ENDUZ',
       formatter: this.formatter.formatTime.bind(this)
      },
      visible: this.clockTimeVisible
     }),
     new sap.m.ObjectStatus({
      text: {
       path: 'TimeData>TimeEntryDataFields/STATUS',
       formatter: formatter.status
      },
      state: {
       path: 'TimeData>TimeEntryDataFields/STATUS',
       formatter: formatter.state
      }
     }),
     new sap.m.Button({
      icon: "sap-icon://notification-2",
      type: sap.m.ButtonType.Transparent,
      press: this.displaylongtextPopover.bind(this),
      visible: {
       path: 'TimeData>TimeEntryDataFields/LONGTEXT',
       formatter: formatter.visibility
      }
     })

    ],
    customData: [new sap.ui.core.CustomData({
     key: "counter",
     value: "{TimeData>Counter}"
    })]
   });
   // if (sap.ui.Device.system.phone === true) {
   //  this.oTable.bindItems({
   //   path: 'TimeData>/',
   //   sorter: new sap.ui.model.Sorter("TimeEntryDataFields/WORKDATE", false, true),
   //   template: this.oReadOnlyTemplate,
   //   templateShareable: true,
   //   groupHeaderFactory: this.getGroupHeader
   //  });
   // } else {
   this.oTable.bindItems({
    path: 'TimeData>/',
    sorter: [new sap.ui.model.Sorter("HeaderData", false, true, this.compareRows)
     // , new sap.ui.model.Sorter(
     //  "TimeEntryDataFields/CATSHOURS", true, false)
    ],
    template: this.oReadOnlyTemplate,
    templateShareable: true,
    groupHeaderFactory: this.getGroupHeader.bind(this)
   });
   // }
  },
  clockTimesToDoPopOver: function (oEvent) {
   // create popover
   var that = this;
   var oDialogController = {
    handleClose: function (event) {
     that._oPopover.close();
     that._oPopover.destroy();
    },
    handleOk: function (event) {
     var index = oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1];
     var data = that.getModel('TodoList').getData();
     if (that.clockTimeChange) {
      data[index].TimeEntryDataFields.BEGUZ = that.formatter.convertTime(oEvent.getSource().getParent().getAggregation('content')[
        0]
       .getAggregation('content')[0].getDateValue());
      data[index].TimeEntryDataFields.ENDUZ = that.formatter.convertTime(oEvent.getSource().getParent().getAggregation('content')[
        0]
       .getAggregation('content')[1].getDateValue());
      if (data[index].Counter !== "") {
       data[index].TimeEntryOperation = 'U';
      } else {
       data[index].TimeEntryOperation = 'C';
      }
      var oModel = new JSONModel(data);
      that.setModel(oModel, "TodoList");
     }
     that._oPopover.close();
     that._oPopover.destroy();
    },
    handleChange: function (oEvent) {
     that.clockTimeChange = true;
    },
    formatTime: this.formatter.formatTime.bind(this)
   };
   var data = $.extend(true, [], this.getModel('TodoList').getData());
   var oModel = new JSONModel(data);
   this.setModel(oModel, "oldModel");
   // if (!this._oPopover) {
   this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.ClockTimesPopOver",
    oDialogController);
   this._oPopover.bindElement('TodoList>' + oEvent.getSource().getBindingContext('TodoList').getPath());
   this.getView().addDependent(this._oPopover);

   // }

   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   jQuery.sap.delayedCall(0, this, function () {
    this._oPopover.open(oEvent.getSource());
   });
  },
  clockTimeChange: function (oEvent) {
   this.clockTimeChange = true;
  },
  showBusy: function () {
   this._nCounter++;
   if (this._nCounter === 1) {
    this.busyDialog.open();
   }
  },
  hideBusy: function (forceHide) {
   if (this._nCounter === 0) {
    return;
   }
   this._nCounter = forceHide ? 0 : Math.max(0,
    this._nCounter - 1);
   if (this._nCounter > 0) {
    return;
   }
   this.busyDialog.close();
  },
  onAssignmentPress: function (oEvent) {
   // if (sap.ui.Device.system.phone === true) {
   var that = this;
   var oView = this.getView();
   var oTable = this.byId('idTasks');
   oTable.setBusy(true);
   var oModel = new JSONModel();
   var data = this.getModel('ProfileFields').getData();
   var tasks = this.getModel('Tasks').getData();
   var index = parseInt(oEvent.getSource().getBindingContext('TaskFields').getPath().split('/')[1]);
   var oControl = this.getModel("controls");
   var formElements = [];
   var formContainers = [];
   var form = {
    name: null,
    status: false,
    containers: null
   };
   var oAssignmentModel = new JSONModel();
   oAssignmentModel.setData(tasks[index]);
   this.setGlobalModel(oAssignmentModel, "selectedAssignment");
   oControl.setProperty('/createAssignment', false);
   oControl.setProperty('/editAssignment', false);
   oControl.setProperty('/displayAssignment', true);
   oControl.setProperty('/copyAssignment', false);
   oControl.setProperty('/assignmentTitle', this.oBundle.getText("displayAssignment"));
   this.setGlobalModel(oControl, "controls");
   var selectedTask = oEvent.getSource().getAggregation('cells');
   var profileFields = $.extend(true, [], this.getModel('ProfileFields').getData());
   for (var i = 0; i < selectedTask.length; i++) {
    var obj = $.grep(profileFields, function (element, index) {
     return element.FieldName == selectedTask[i].getCustomData('FieldName')[0].getValue();
    });
    if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentStatus" && selectedTask[i].getCustomData(
      'FieldName')[
      0].getValue() !== "AssignmentName" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityStartDate" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityEndDate" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "APPROVER") {
     if (tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()] !== undefined) {
      obj[0].FieldValue = tasks[index].AssignmentFields[selectedTask[i].getCustomData('FieldName')[0].getValue()];
     }
     obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
    } else {
     if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentStatus") {
      obj[0].FieldValue = selectedTask[i].getAggregation('customData')[2].getValue();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentName") {
      obj[0].FieldValue = selectedTask[i].getText();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityStartDate") {
      obj[0].FieldValue = selectedTask[i].getText();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityEndDate") {
      obj[0].FieldValue = selectedTask[i].getText();
      obj[0].AssignmentId = selectedTask[i].getAggregation('customData')[1].getValue();
     } else if (selectedTask[i].getCustomData('FieldName')[
       0].getValue() === "APPROVER") {
      obj[0].FieldValue = tasks[index].ApproverId;
     }
    }
    if (selectedTask[i].getCustomData('FieldName')[0].getValue() !== "AssignmentName" && selectedTask[i].getCustomData('FieldName')[
      0]
     .getValue() !== "AssignmentStatus" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityStartDate" && selectedTask[i].getCustomData('FieldName')[
      0].getValue() !== "ValidityEndDate") {
     formElements.push(obj[0]);
    } else {
     if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentName") {
      form.name = obj[0].FieldValue;
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "AssignmentStatus") {
      form.status = obj[0].FieldValue;
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityStartDate") {
      form.validFrom = new Date(obj[0].FieldValue);
     } else if (selectedTask[i].getCustomData('FieldName')[0].getValue() === "ValidityEndDate") {
      form.validTo = new Date(obj[0].FieldValue);
     }
    }
    if (((formElements.length + 1) % 5) === 0 || i === (selectedTask.length - 1)) {
     formContainers.push({
      form: $.extend(true, [], formElements)
     });
     formElements = [];
    }
   }
   // for (var i = 0; i < profileFields.length; i++) {
   //  if (profileFields[i].FieldName !== "AssignmentStatus") {
   //   if (tasks[index][profileFields[i].FieldName]) {
   //    profileFields[i].FieldValue = tasks[index][profileFields[i].FieldName];
   //   }
   //  }
   //  if (profileFields[i].FieldName !== "AssignmentName" && profileFields[i].FieldName !== "AssignmentStatus") {
   //   formElements.push(profileFields[i]);
   //  } else {
   //   if (profileFields[i].FieldName === "AssignmentName") {
   //    form.name = profileFields[i].FieldValue;
   //   } else {
   //    form.status = profileFields[i].FieldValue;
   //   }
   //  }
   //  if (((i + 1) % 5) === 0 || i === (selectedTask.length - 1)) {
   //   formContainers.push({
   //    form:  $.extend(true, [], formElements)
   //   });
   //   formElements = [];
   //  }
   // }
   form.containers = formContainers;
   oModel.setData(form);
   this.setGlobalModel(oModel, "EditedTask");

   // this.oRouter.navTo("createAssignment", {}, false);
   oTable.setBusy(false);
   this.oRouter.navTo("editAssignment", {}, false);
   // }
  },
  onAssignmentWorklistPress: function (oEvent) {
   var that = this;
   var oCtx = oEvent.getSource().getBindingContext();
   // var obj = oEvent.getSource().getBindingContext().getObject();
   var data = this.getModel('WorklistFields').getData();
   var oControl = this.getModel("controls");
   var index = oEvent.getSource().getBindingContext("WorklistFields").getPath().split('/')[1];
   var oModel = new JSONModel();
   var data = this.getModel('ProfileFields').getData();
   var tasks = this.getModel('WorklistFields').getData();
   var formElements = [];
   var formContainers = [];
   var form = {
    name: null,
    status: false,
    containers: null
   };
   var oControl = this.getModel("controls");
   this.setGlobalModel(oControl, "controls");
   var selectedTask = oEvent.getSource().getAggregation('cells');
   var profileFields = $.extend(true, [], this.getModel('ProfileFields').getData());
   for (var i = 0; i < profileFields.length; i++) {
    if (profileFields[i].FieldName !== "AssignmentStatus") {
     if (tasks[index][profileFields[i].FieldName]) {
      profileFields[i].FieldValue = tasks[index][profileFields[i].FieldName];
     }
    }
    if (profileFields[i].FieldName !== "AssignmentName" && profileFields[i].FieldName !== "AssignmentStatus") {
     formElements.push(profileFields[i]);
    } else {
     if (profileFields[i].FieldName === "AssignmentName") {
      form.name = profileFields[i].FieldValue;
     } else {
      form.status = profileFields[i].FieldValue;
     }
    }
    if (((i + 1) % 5) === 0 || i === (selectedTask.length - 1)) {
     formContainers.push({
      form: $.extend(true, [], formElements)
     });
     formElements = [];
    }
   }
   form.containers = formContainers;
   oModel.setData(form);
   // oModel.setData(data);
   oControl.setProperty('/createAssignment', false);
   oControl.setProperty('/editAssignment', false);
   oControl.setProperty('/displayAssignment', false);
   oControl.setProperty('/copyAssignment', false);
   oControl.setProperty('/importAssignment', true);
   oControl.setProperty('/assignmentTitle', this.oBundle.getText("displayAssignment"));
   this.setGlobalModel(oControl, "controls");
   this.setGlobalModel(oModel, "EditedTask");
   this.getRouter().navTo("editAssignment", {}, false);
  },
  onExit: function () {
   sap.ui.getCore().getMessageManager().removeAllMessages();
   // The personalization table must be destroyed by the app. If not, when the app is restarted another personalization
   // table is created with the same ID and thus the app can't be started.
   if (this.oTablePersoController) {
    this.oTablePersoController.destroy();
    delete this.oTablePersoController;
   }
   if (this.oTableTodoPersoController) {
    this.oTableTodoPersoController.destroy();
    delete this.oTableTodoPersoController;
   }
   if (this.oTableTaskPersoController) {
    this.oTableTaskPersoController.destroy();
    delete this.oTableTaskPersoController;
   }
  },
  recordTemplate: function () {
   var that = this;
   var recordTemplate = {
    AllowEdit: "",
    AllowRelease: "",
    AssignmentId: "",
    AssignmentName: "",
    CatsDocNo: "",
    Counter: "",
    Pernr: that.empID,
    RefCounter: "",
    RejReason: "",
    Status: "",
    target: "",
    TimeEntryDataFields: {
     AENAM: "",
     ALLDF: "",
     APDAT: null,
     APNAM: "",
     ARBID: "00000000",
     ARBPL: "",
     AUERU: "",
     AUFKZ: "",
     AUTYP: "00",
     AWART: "",
     BEGUZ: "000000",
     BELNR: "",
     BEMOT: "",
     BUDGET_PD: "",
     BUKRS: "",
     BWGRL: "0.0",
     CATSAMOUNT: "0.0",
     CATSHOURS: "0.00",
     CATSQUANTITY: "0.0",
     CPR_EXTID: "",
     CPR_GUID: "",
     CPR_OBJGEXTID: "",
     CPR_OBJGUID: "",
     CPR_OBJTYPE: "",
     ENDUZ: "000000",
     ERNAM: "",
     ERSDA: null,
     ERSTM: null,
     ERUZU: "",
     EXTAPPLICATION: "",
     EXTDOCUMENTNO: "",
     EXTSYSTEM: "",
     FUNC_AREA: "",
     FUND: "",
     GRANT_NBR: "",
     HRBUDGET_PD: "",
     HRCOSTASG: "0",
     HRFUNC_AREA: "",
     HRFUND: "",
     HRGRANT_NBR: "",
     HRKOSTL: "",
     HRLSTAR: "",
     KAPAR: "",
     KAPID: "00000000",
     KOKRS: "",
     LAEDA: null,
     LAETM: null,
     LGART: "",
     LOGSYS: "",
     LONGTEXT: "",
     LONGTEXT_DATA: "",
     LSTAR: "",
     LSTNR: "",
     LTXA1: "",
     MEINH: "",
     OFMNW: "0.0",
     OTYPE: "",
     PAOBJNR: "0000000000",
     PEDD: null,
     PERNR: "00000000",
     PLANS: "00000000",
     POSID: "",
     PRAKN: "",
     PRAKZ: "0000",
     PRICE: "0.0",
     RAPLZL: "00000000",
     RAUFNR: "",
     RAUFPL: "0000000000",
     REASON: "",
     REFCOUNTER: "000000000000",
     REINR: "0000000000",
     RKDAUF: "",
     RKDPOS: "000000",
     RKOSTL: "",
     RKSTR: "",
     RNPLNR: "",
     RPROJ: "00000000",
     RPRZNR: "",
     SBUDGET_PD: "",
     SEBELN: "",
     SEBELP: "00000",
     SKOSTL: "",
     SPLIT: 0,
     SPRZNR: "",
     STATKEYFIG: "",
     STATUS: "",
     S_FUNC_AREA: "",
     S_FUND: "",
     S_GRANT_NBR: "",
     TASKCOMPONENT: "",
     TASKCOUNTER: "",
     TASKLEVEL: "",
     TASKTYPE: "",
     TCURR: "",
     TRFGR: "",
     TRFST: "",
     UNIT: "",
     UVORN: "",
     VERSL: "",
     VORNR: "",
     VTKEN: "",
     WABLNR: "",
     WAERS: "",
     WERKS: "",
     WORKDATE: "",
     WORKITEMID: "000000000000",
     WTART: ""
    },
    TimeEntryOperation: ""
   };
   return recordTemplate;
  },
  onEditTodoListMobile: function (oEvent) {
   var that = this;
   var index = oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1];
   var todolist = this.getModel('TodoList').getData();
   var oModel = new JSONModel(todolist[index]);
   this.setGlobalModel(oModel, "EditTodo");
   this.getRouter().navTo("editToDo", {}, false);
  },
  getFieldTexts: function (oFieldName) {
   var that = this;
   var texts;
   var oModel = new sap.ui.model.json.JSONModel();
   var f = [];
   var c = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   var d = new sap.ui.model.Filter({
    path: "FieldName",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: oFieldName
   });
   f.push(c);
   f.push(d);
   var mParameters = {
    urlParameters: '$expand=ValueHelpHits',
    filters: f,
    success: function (oData, oResponse) {
     texts = oData.results[0].ValueHelpHits.results;
     oModel.setData(texts);
     that.setModel(oModel, oFieldName);
     that.setGlobalModel(oModel, oFieldName);
     that.oTaskTable.bindItems({
      path: 'TaskFields>/',
      factory: that.dynamicBindingRows.bind(that)
     });
    },
    error: function (oError) {
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/ValueHelpCollection', mParameters);

  },
  startTimeChange: function (oEvent) {
   var that = this;
   var data = this.getModel("TimeData").getData();
   var index = oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1];
   data[index].TimeEntryDataFields.BEGUZ = that.formatter.convertTime(oEvent.getSource().getDateValue());
   // data[index].TimeEntryDataFields.ENDUZ = that.formatter.convertTime(oEvent.getSource().getDateValue());
   if (data[index].Counter !== "") {
    data[index].TimeEntryOperation = 'U';
   } else {
    data[index].TimeEntryOperation = 'C';
   }
   var oModel = new JSONModel(data);
   that.setModel(oModel, "TimeData");
   this.getModel("controls").setProperty("/isOverviewChanged", true);
   this.getModel("controls").setProperty("/overviewDataChanged", true);
  },
  endTimeChange: function (oEvent) {
   var that = this;
   var data = this.getModel("TimeData").getData();
   var oControl = this.getModel("controls");
   var index = oEvent.getSource().getParent().getBindingContext('TimeData').getPath().split('/')[1];
   data[index].TimeEntryDataFields.ENDUZ = that.formatter.convertTime(oEvent.getSource().getDateValue());
   if (data[index].Counter !== "") {
    data[index].TimeEntryOperation = 'U';
   } else {
    data[index].TimeEntryOperation = 'C';
   }
   var oModel = new JSONModel(data);
   that.setModel(oModel, "TimeData");
   this.getModel("controls").setProperty("/isOverviewChanged", true);
   this.getModel("controls").setProperty("/overviewDataChanged", true);
  },
  startTimeToDoChange: function (oEvent) {
   var that = this;
   var data = this.getModel("TodoList").getData();
   var index = oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1];
   data[index].TimeEntryDataFields.BEGUZ = that.formatter.convertTime(oEvent.getSource().getDateValue());
   if (data[index].Counter !== "") {
    data[index].TimeEntryOperation = 'U';
   } else {
    data[index].TimeEntryOperation = 'C';
   }
   var oModel = new JSONModel(data);
   that.setModel(oModel, "TodoList");
  },

  stopTimeToDoChange: function (oEvent) {
   var that = this;
   var data = this.getModel("TodoList").getData();
   var index = oEvent.getSource().getParent().getBindingContext('TodoList').getPath().split('/')[1];
   data[index].TimeEntryDataFields.ENDUZ = that.formatter.convertTime(oEvent.getSource().getDateValue());
   if (data[index].Counter !== "") {
    data[index].TimeEntryOperation = 'U';
   } else {
    data[index].TimeEntryOperation = 'C';
   }
   var oModel = new JSONModel(data);
   that.setModel(oModel, "TodoList");
  },
  noAssignmentsDialog: function () {
   var that = this;
   // var dialog = new Dialog({
   //  title: this.oBundle.getText("welcomeTimesheet"),
   //  type: 'Message',
   //  content: new Text({
   //   text: this.oBundle.getText("noAssignments")
   //  }),
   //  beginButton: new sap.m.Button({
   //   text: this.oBundle.getText("ok"),
   //   press: function () {
   //    that.byId("idIconTabBarNoIcons").setSelectedKey("tasks");
   //    dialog.close();
   //   }
   //  }),
   //  afterClose: function () {
   //   dialog.destroy();
   //  }
   // });

   // dialog.open();
  },
  handleConfirmationDiscard: function (oEvent) {
   this._confirmationFunction();
  },
  showConfirmBox: function (oEvent, ok) {
   var that = this;
   var oDialogController = {
    handleClose: function (oEvent) {
     that._oDialog.destroy();
    },
    handleConfirmationDiscard: function (oEvent) {
     ok();
     that._oDialog.destroy();
    }
   };
   // if (!this._oDialog) {
   this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.CancelConfirmationPopOver",
    oDialogController);
   this.getView().addDependent(this._oDialog);
   // }
   this._oDialog.openBy(oEvent.getSource());
   // this._confirmationFunction = ok;
  },
  onCancelConfirm: function (oEvent) {
   var oControls = this.getModel("controls");
   if (oControls.getProperty("/isOverviewChanged") === true) {
    this.showConfirmBox(oEvent, this.onCancel.bind(this));
    oControls.setProperty("/isOverviewChanged", false);
   } else {
    this.onCancel();
    oControls.setProperty("/isOverviewChanged", false);
   }
   oControls.setProperty("/overviewDataChanged", false);
   sap.ui.getCore().getMessageManager().removeAllMessages();

  },
  onTodoCancelConfirm: function (oEvent) {
   var oControls = this.getModel("controls");
   if (oControls.getProperty("/isToDoChanged") === true) {
    this.showConfirmBox(oEvent, this.onTodoCancel.bind(this));
    oControls.setProperty("/isToDoChanged", false);
   } else {
    this.onTodoCancel();
    oControls.setProperty("/isToDoChanged", false);
   }
   oControls.setProperty("/todoDataChanged", false);
   sap.ui.getCore().getMessageManager().removeAllMessages();
  },
  onCreateGroup: function (oEvent) {
   var oSelectedItems = this.byId("idTasks").getSelectedContexts();
   var oAssignments = this.getModel("Tasks").getData();
   var group = {
    "groupId": null,
    "groupName": "",
    "count": 0,
    "Assignments": [],
   };
   this.byId("idTasks").setBusy(true);
   for (var i = 0; i < oSelectedItems.length; i++) {
    var index = oSelectedItems[i].sPath.split('/')[1];
    group.Assignments.push({
     "AssignmentId": oAssignments[index].AssignmentId,
     "AssignmentName": oAssignments[index].AssignmentName,
     "ValidityStartDate": oAssignments[index].ValidityStartDate,
     "ValidityEndDate": oAssignments[index].ValidityEndDate
    });
   }
   var oControls = this.getModel("controls");
   oControls.setProperty('/displayGroup', false);
   oControls.setProperty('/GroupCancel', true);
   oControls.setProperty('/createGroup', true);
   oControls.setProperty('/displayGroupCancel', false);
   oControls.setProperty('/GroupCancel', true);
   this.setGlobalModel(oControls, "controls");
   this.setGlobalModel(new JSONModel(group), "createGroup");
   this.byId("idTasks").setBusy(false);
   this.getRouter().navTo("createGroup", {}, false);
  },
  getAssignmentGroups: function () {
   this.oTaskTable.setBusy(true);
   var that = this;
   // var oModel = new sap.ui.model.json.JSONModel();
   // var TaskModel = new sap.ui.model.json.JSONModel();
   // var oControl;
   // var obj;
   // var TaskFields = [];
   // var task = {};
   var a = new sap.ui.model.Filter({
    path: "Pernr",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   var f = [];
   f.push(a);

   var mParameters = {
    filters: f,
    urlParameters: '$expand=ToGrps',
    success: function (oData, oResponse) {
     that.tasks = oData.results;
     // oModel.setData(that.tasks);
     // if (that.tasks.length === 0 && initLoad) {
     //  that.noAssignmentsDialog();
     // }
     // oControl = that.getModel("controls");
     // that.setModel(oModel, "Tasks");
     // that.setGlobalModel(oModel, "Tasks");
     // for (var j = 0; j < that.tasks.length; j++) {
     //  task["AssignmentName"] = that.tasks[j].AssignmentName;
     //  for (var i = 0; i < that.profileFields.length; i++) {
     //   if (that.profileFields[i].FieldName === "ApproverName" || that.profileFields[i].FieldName === "AssignmentStatus" || that.profileFields[
     //     i].FieldName === "AssignmentName") {
     //    if (that.profileFields[i].FieldName === "AssignmentStatus") {
     //     task[that.profileFields[i].FieldName] = that.tasks[j][that.profileFields[i].FieldName] === "1" ? true : false;
     //    } else {
     //     task[that.profileFields[i].FieldName] = that.tasks[j][that.profileFields[i].FieldName];
     //    }
     //   } else {
     //    task[that.profileFields[i].FieldName] = that.tasks[j].AssignmentFields[that.profileFields[i].FieldName];
     //    that.getFieldTexts(that.profileFields[i].FieldName);
     //   }

     //  }
     //  var finaltask = $.extend(true, {}, task);
     //  TaskFields.push(finaltask);
     // }
     // obj = $.grep(TaskFields, function (element, ind) {
     //  return element.AssignmentStatus === true;
     // });
     // oControl.setProperty('/tasksActiveLength', obj.length);
     // obj = $.grep(TaskFields, function (element, ind) {
     //  return element.AssignmentStatus === false;
     // });
     // oControl.setProperty('/tasksInactiveLength', obj.length);
     // oControl.setProperty('/taskEdit', false);
     // oControl.setProperty('/taskDelete', false);
     // oControl.setProperty('/taskCopy', false);
     // TaskModel.setData(TaskFields);
     // that.setModel(TaskModel, "TaskFields");
     // that.initPersonalization();
     // that.oTaskTable.setBusy(false);
    },
    error: function (oError) {
     that.oTaskTable.setBusy(false);
     that.oErrorHandler.processError(oError);
    }
   };
   this.oDataModel.read('/AssignmentCollection', mParameters);

  },
  onDisplayGroup: function (oEvent) {
   var that = this;
   var oControls = this.getModel("controls");
   oControls.setProperty('/displayGroup', true);
   oControls.setProperty('/createGroup', false);
   oControls.setProperty('/editGroup', false);
   oControls.setProperty('/displayGroupCancel', false);
   oControls.setProperty('/GroupCancel', false);
   this.setGlobalModel(oControls, "controls");
   var Assignments = this.getModel('AssignmentGroups').getData();
   var index = parseInt(oEvent.getSource().getBindingContext('AssignmentGroups').getPath().split('/')[1]);
   this.setGlobalModel(new JSONModel(Assignments[index]), "createGroup");
   this.getRouter().navTo("createGroup", {}, false);
  },
  onEditGroup: function (oEvent) {
   var that = this;
   var oControls = this.getModel("controls");
   oControls.setProperty('/displayGroup', false);
   oControls.setProperty('/editGroup', true);
   oControls.setProperty('/displayGroupCancel', false);
   oControls.setProperty('/GroupCancel', true);
   this.setGlobalModel(oControls, "controls");
   var Assignments = this.getModel('AssignmentGroups').getData();
   var index = parseInt(this.byId('idGroups').getSelectedItem().getBindingContext('AssignmentGroups').getPath().split("/")[1]);
   this.setGlobalModel(new JSONModel(Assignments[index]), "createGroup");
   this.getRouter().navTo("createGroup", {}, false);
  },
  handleDateChange: function (oEvent) {
   var that = this;
   var oDialogController = {
    handleConfirm: function (oEvent) {
     var dateFrom = oDateRange.getDateValue();
     var dateTo = oDateRange.getSecondDateValue();
     that.getTasks(false, dateFrom, dateTo);
     that.filterAppliedFlag = "X";
     if (oDialog) {
      oDialog.destroy();
     }
    },
    handleCancel: function (oEvent) {
     if (oDialog) {
      oDialog.destroy();
     }
    }
   };
   // if (!this._oDialog) {
   var oDialog = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.mytimesheet.view.fragments.FilterAssignment",
    oDialogController);
   // Set initial and reset value for Slider in custom control
   var oDateRange = oDialog.getFilterItems()[0].getCustomControl();
   // this.byId('idCustomFilterItem').setText(this.oBundle.getText('validPeriod'));
   // oSlider.setValue(this.filterResetValue);
   // }

   // this._oDialog.setModel(this.getView().getModel());
   this.getView().addDependent(oDialog);
   // toggle compact style
   jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oDialog);
   oDialog.open();

  },

  onGroupSelection: function (oEvent) {
   var oControl = this.getModel("controls");
   var oSelectedItems = oEvent.getParameter("selectedContexts");
   if (oEvent.getParameters().listItem.getSelected() === true && this.byId("idGroups").getSelectedItems().length == 1) {
    oControl.setProperty("/EditGroup", true);
    oControl.setProperty("/DeleteGroup", true);
    oControl.setProperty("/createGroupButton", true);
   } else if (this.oTaskTable.getSelectedItems().length == 1) {
    oControl.setProperty("/EditGroup", true);
    oControl.setProperty("/DeleteGroup", true);
    oControl.setProperty("/createGroupButton", true);
   } else {
    oControl.setProperty("/EditGroup", false);
    if (this.byId("idGroups").getSelectedItems().length === 0) {
     oControl.setProperty("/DeleteGroup", false);
    } else {
     oControl.setProperty("/DeleteGroup", true);
    }
    oControl.setProperty("/createGroupButton", true);
   }
  },
  onGroupDelete: function (oEvent) {
   var that = this;
   var oGroupData = [];
   var oDelGroup = this.getModel('AssignmentGroups').getData();
   var oSelectedItems = this.byId('idGroups').getSelectedItems();
   for (var k = 0; k < oSelectedItems.length; k++) {
    var index = parseInt(oSelectedItems[k].getBindingContext('AssignmentGroups').getPath().split("/")[1]);
    if (oDelGroup[index].Assignments) {
     for (var i = 0; i < oDelGroup[index].Assignments.length; i++) {
      var data = {
       GrpId: oDelGroup[index].groupId,
       GrpName: oDelGroup[index].groupName,
       AssignmentId: oDelGroup[index].Assignments[i].AssignmentId,
       GrpOperation: 'D'
      };
      oGroupData.push(data);
     }
    }
   }
   this.SubmitGroup(oGroupData);
   // this.setGlobalModel(new JSONModel(Assignments[index]), "createGroup");
   // this.getRouter().navTo("createGroup", {}, false);
  },
  SubmitGroup: function (GroupData) {
   var that = this;
   var oModel = $.extend(true, {}, this.oDataModel);
   oModel.setChangeBatchGroups({
    "*": {
     groupId: "TimeGroup",
     changeSetId: "TimeGroup",
     single: false
    }
   });
   oModel.setDeferredGroups(["TimeGroup"]);
   oModel
    .refreshSecurityToken(
     function (oData) {
      for (var i = 0; i < GroupData.length; i++) {
       var obj = {
        properties: GroupData[i],
        changeSetId: "TimeGroup",
        groupId: "TimeGroup"
       };
       oModel
        .createEntry(
         "/AssignmentGrpsSet",
         obj);
      }
      oModel.submitChanges({
       groupId: "TimeGroup",
       changeSetId: "TimeGroup",
       success: function (oData, res) {
        // if (!oData.__batchResponses[0].__changeResponses) {
        // for (var i=0; i<that.batches.length;i++){
        //  that.batches[i].TimeEntryDataFields.WORKDATE = new Date(that.batches[i].TimeEntryDataFields.WORKDATE);
        // }
        var toastMsg = that.oBundle.getText("deleteGroup");
        sap.m.MessageToast.show(toastMsg, {
         duration: 3000
        });
        // that.getTasks();
        // var data = {
        //  reloadTasks: true
        // };
        that.getTasks(false);
        // var oControls = that.getGlobalModel("controls");
        // oControls.setProperty('/groupReload', true);
        // that.setGlobalModel(oControls, "controls");
        // that.setModel(new JSONModel({}), "AddAssignments");
        // that.setModel(new JSONModel({}), "DeleteAssignments");
        // // that.oRouter.navTo("worklist", {}, true);
        // that.getRouter().navTo("worklist", {}, true);
        // return;

        // }
       },
       error: function (oError) {
        that.oErrorHandler.processError(oError);
       }
      });

     }, true);
  },
  handleSearchAssignments: function (oEvent) {
   var that = this;
   var oFilter = [];
   var search = oEvent.getSource().getValue();
   if (search !== "") {
    oFilter.push(new Filter("AssignmentName", FilterOperator.Contains, search));
    var oRef = this.byId('idTasks').getBinding('items').filter(oFilter);
   } else {
    // oFilter.push(new Filter("AssignmentName", FilterOperator.Contains, search));
    var oRef = this.byId('idTasks').getBinding('items').filter(oFilter);
   }
  },
  handleSearchGroups: function (oEvent) {
   var that = this;
   var oFilter = [];
   var search = oEvent.getSource().getValue();
   if (search !== "") {
    oFilter.push(new Filter("groupName", FilterOperator.Contains, search));
    var oRef = this.byId('idGroups').getBinding('items').filter(oFilter);
   } else {
    var oRef = this.byId('idGroups').getBinding('items').filter(oFilter);
   }
  },
  navigateToTasks: function () {
   // this.byId("idIconTabBarNoIcons").setSelectedKey("tasks");
   var that = this;
   var oControl = this.getModel("controls");
   var messageHeader = that.oBundle.getText("confirmationSwitchTab");
   var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
   if ((oControl.getProperty("/isOverviewChanged") || oControl.getProperty("/overviewDataChanged"))) {
    sap.m.MessageBox.warning(
     that.oBundle.getText("confirmationSwitchTabGeneral"), {
      title: that.oBundle.getText("confirm"),
      actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
      styleClass: bCompact ? "sapUiSizeCompact" : "",
      onClose: function (sAction) {
       if (sAction === "CANCEL") {
        // that.byId("ObjectPageLayout").setSelectedSection("application-MyTimesheet-display-component---worklist--tasks");
        that.byId("ObjectPageLayout").setSelectedSection(that.byId("ObjectPageLayout").getSections()[0].getId());
        return;
       } else {
        that.onCancel();
        sap.ui.getCore().getMessageManager().removeAllMessages();
        that.iconTabSelectionProcessing(that.byId("ObjectPageLayout").getSections()[2].getId());
        that.byId("ObjectPageLayout").setSelectedSection(that.byId("ObjectPageLayout").getSections()[2].getId());
       }
      }
     }

    );
   } else if (!(oControl.getProperty("/isOverviewChanged") || oControl.getProperty("/overviewDataChanged"))) {
    that.onCancel();
    if (oControl.getProperty("/isToDoChanged") || oControl.getProperty("/todoDataChanged")) {
     oControl.setProperty("/showFooter", true);
    }
    // this.iconTabSelectionProcessing(oEvent.getParameter('section').getId().split("worklist--")[1]);
    that.iconTabSelectionProcessing(that.byId("ObjectPageLayout").getSections()[2].getId());
    this.byId("ObjectPageLayout").setSelectedSection(this.byId("ObjectPageLayout").getSections()[2].getId());
   }

  },
  onShowOverviewMessage: function (oEvent) {
   var that = this;
   var oControl = this.getModel("controls");
   oControl.setProperty("/showOverviewMessage", true);
  },
  onCloseOverviewMessage: function (oEvent) {
   var that = this;
   var oControl = this.getModel("controls");
   oControl.setProperty("/showOverviewMessage", false);
  },
  onShowAssignmentsMessage: function (oEvent) {
   var that = this;
   var oControl = this.getModel("controls");
   oControl.setProperty("/showAssignmentsMessage", true);
  },
  onCloseAssignmentsMessage: function (oEvent) {
   var that = this;
   var oControl = this.getModel("controls");
   oControl.setProperty("/showAssignmentsMessage", false);
  },
  onShowGroupMessage: function (oEvent) {
   var that = this;
   var oControl = this.getModel("controls");
   oControl.setProperty("/showGroupMessage", true);
  },
  onCloseGroupMessage: function (oEvent) {
   var that = this;
   var oControl = this.getModel("controls");
   oControl.setProperty("/showGroupMessage", false);
  },
  // activeTasks: function(index, context) {
  //  var obj = context.getObject();
  //  if (obj.AssignmentStatus === "1") {
  //   return new sap.ui.core.Item({
  //    key: obj.AssignmentId,
  //    text: obj.AssignmentName
  //   });
  //  }else{
  //   return new sap.ui.core.Item({
  //   });
  //  }
  // },
  /**
   * Internal helper method to apply both filter and search state together on the list binding
   * @param {object} oTableSearchState an array of filters for the search
   * @private
   */
  // _applySearch: function(oTableSearchState) {
  // var oTable = this.byId("table"),
  // oViewModel = this.getModel("worklistView");
  // oTable.getBinding("items").filter(oTableSearchState, "Application");
  // changes the noDataText of the list in case there are no filter results
  // if (oTableSearchState.length !== 0) {
  // oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
  // }
  // }

 });
});