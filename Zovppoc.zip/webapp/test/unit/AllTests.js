sap.ui.define([
	"com/newtiles/Znewtilesovp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});